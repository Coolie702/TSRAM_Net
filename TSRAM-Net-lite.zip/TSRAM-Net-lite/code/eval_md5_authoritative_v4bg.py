# -*- coding: utf-8 -*-
"""md5v4bg 权威评估（对应 eval_md5_authoritative_v3.py）：
严格 BN=eval 部署口径 + 合成验证集阈值校准 + raw/renorm 丰度 + 分层 + 金刚石。
复用 train_md5_v4_bg.py 的数据准备与模型定义（含 BackgroundNet），按行切片 exec。"""
import os
import io, sys, traceback
import numpy as np
import pandas as pd
from scipy.signal import savgol_filter
from scipy.interpolate import interp1d
from sklearn.metrics import f1_score
import torch

path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'train_md5_v4_bg.py')
lines = io.open(path, encoding='utf-8').read().split('\n')
ns = {}
exec(compile('\n'.join(lines[:486]), path, 'exec'), ns)

DEVICE = ns['DEVICE']
# 注入 model（与训练脚本 Step 3 相同的构造），加载 best 权重
model = ns['TwoStreamRetrievalModelV2'](
    ns['N_MINERALS'], ns['FEATURE_DIM'], ns['TEMPERATURE_INIT'],
    ns['TEMPERATURE_INIT'] * 0.75, scatter_coeffs=ns['SCATTER_COEFFS']).to(DEVICE)
model.load_state_dict(torch.load(ns['OUT_PREFIX'] + '_best_model.pth', map_location=DEVICE))
model.eval()
with torch.no_grad():
    model.update_ref_features(ns['reference_tensor'].to(DEVICE))
model.eval()   # 关键：update_ref_features 结尾 self.train()，强制回 eval（部署口径）

X_real = ns['X_real']; y_pres_real = ns['y_pres_real']; y_abun_real = ns['y_abun_real']
bin_idx = np.where((ns['abund_pct'].values > 0).sum(1) >= 2)[0]

# ---- 合成验证集上（BN eval）校准 presence 阈值 ----
val_probs, val_labels = [], []
with torch.no_grad():
    for xb, ybp, _ in ns['val_loader']:
        pl, _, _, _ = model.predict(xb.to(DEVICE))
        val_probs.append(torch.sigmoid(pl).cpu().numpy()); val_labels.append(ybp.numpy())
val_probs = np.concatenate(val_probs); val_labels = np.concatenate(val_labels)
best_th, best_f1_th = 0.5, 0.0
for th in np.arange(0.1, 0.95, 0.05):
    f1 = f1_score(val_labels, (val_probs > th).astype(float), average='samples', zero_division=0)
    if f1 > best_f1_th:
        best_f1_th, best_th = f1, th
print(f'合成验证集阈值: {best_th:.2f} (val F1={best_f1_th:.4f})')

with torch.no_grad():
    pl, ab = model(torch.from_numpy(X_real).to(DEVICE))[:2]
prob = torch.sigmoid(pl).cpu().numpy(); ab_raw = ab.cpu().numpy()
pres = (prob > best_th).astype(float)

# 重归一化丰度（检出>=2 端元时在检出集合上归一化）
ab_ren = ab_raw.copy()
for i in np.where(pres.sum(1) >= 2)[0]:
    det = pres[i] > 0.5; mass = ab_ren[i, det]
    if mass.sum() > 1e-8:
        ab_ren[i] = 0.0; ab_ren[i, det] = mass / mass.sum()

pls = pd.read_excel(ns['XLSX_BASELINE'], sheet_name='DM_RMSE-P')
pls_map = dict(zip(pls['Mineral'], pls['RMSE-P']))
common = [m for m in ns['MINERALS'] if m in pls_map]


def metrics(ab):
    dot = (ab * y_abun_real).sum(1)
    den = np.maximum(np.linalg.norm(ab, axis=1) * np.linalg.norm(y_abun_real, axis=1), 1e-10)
    cos = float((dot / den).mean())
    mae = float(np.mean(np.abs(ab - y_abun_real)) * 100)
    rm = {}
    for k, m in enumerate(ns['MINERALS']):
        sel = bin_idx[y_abun_real[bin_idx, k] > 0]
        if len(sel):
            rm[m] = float(np.sqrt(np.mean((ab[sel, k] - y_abun_real[sel, k]) ** 2)) * 100)
    avg18 = float(np.mean([rm[m] for m in common]))
    wins = int(sum(1 for m in common if rm[m] < pls_map[m]))
    return cos, mae, avg18, f'{wins}/18', rm


out = {
    'bn_mode': 'eval (running stats) — deployment/inference protocol',
    'presence_threshold': best_th,
    'presence_F1_sample': float(f1_score(y_pres_real, pres, average='samples', zero_division=0)),
    'presence_F1_micro': float(f1_score(y_pres_real, pres, average='micro', zero_division=0)),
    'presence_F1_macro': float(f1_score(y_pres_real, pres, average='macro', zero_division=0)),
    'TP': float(((pres == 1) & (y_pres_real == 1)).sum(1).mean()),
    'FP': float(((pres == 1) & (y_pres_real == 0)).sum(1).mean()),
    'FN': float(((pres == 0) & (y_pres_real == 1)).sum(1).mean()),
}
for tag, ab in [('raw_no_renorm', ab_raw), ('renorm_on_detected', ab_ren)]:
    cos, mae, avg18, wins, rm = metrics(ab)
    out[tag] = {'cosine': cos, 'MAE_pctpt': mae, 'RMSEP18': avg18, 'wins_vs_PLS': wins}
    print(f'[{tag}] F1(sample)={out["presence_F1_sample"]:.4f} cos={cos:.4f} MAE={mae:.2f}pp RMSEP18={avg18:.2f} wins={wins}')
print(f'F1 micro={out["presence_F1_micro"]:.4f} macro={out["presence_F1_macro"]:.4f} TP/FP/FN={out["TP"]:.2f}/{out["FP"]:.2f}/{out["FN"]:.2f}')

# 分层
minor_frac = np.full(len(X_real), np.nan)
for i in bin_idx:
    v = y_abun_real[i][y_abun_real[i] > 0]; minor_frac[i] = v.min() * 100.0
strata = {}
for r in [5, 20, 50]:
    sel = bin_idx[np.isclose(minor_frac[bin_idx], r)]
    hit = 0; mt, mp = [], []
    for i in sel:
        pair = np.where(y_abun_real[i] > 0)[0]; mk = pair[np.argmin(y_abun_real[i, pair])]
        mt.append(y_abun_real[i, mk]); mp.append(ab_raw[i, mk]); hit += int(pres[i, mk] > 0.5)
    mt, mp = np.array(mt), np.array(mp)
    cos = float(np.mean((ab_raw[sel] * y_abun_real[sel]).sum(1) /
                        np.maximum(np.linalg.norm(ab_raw[sel], axis=1) *
                                   np.linalg.norm(y_abun_real[sel], axis=1), 1e-10)))
    strata[f'{r}pct'] = {'n': int(len(sel)), 'minor_recall': float(hit / len(sel)),
                         'minor_abundance_MAE_pctpt': float(np.mean(np.abs(mp - mt)) * 100),
                         'cosine': cos}
    print(f'  minor {r:2d}% n={len(sel):3d} recall={hit/len(sel):.3f} MAE={np.mean(np.abs(mp-mt))*100:.2f}pp cos={cos:.4f}')
out['strata_by_minor_ratio'] = strata

# 金刚石库外
dia = pd.read_csv(ns['CSV_DIAMOND'])
dcols = [c for c in dia.columns if str(c).replace('.', '').isdigit()]
dwn = sorted(float(c) for c in dcols); dcol = {float(c): c for c in dcols}
m2i = {m: k for k, m in enumerate(ns['MINERALS'])}
Xdia = np.zeros((len(dia), ns['N_WAVENUMBER_POINTS']), np.float32)
for i, (_, row) in enumerate(dia.iterrows()):
    Xdia[i] = ns['preprocess_raw'](dwn, np.array([row[dcol[w]] for w in dwn], float))
with torch.no_grad():
    _, abd, _, _ = model.predict(torch.from_numpy(Xdia).to(DEVICE)); abd = abd.cpu().numpy()
dia_pred = [abd[i, m2i[row['Mineral']]] for i, (_, row) in enumerate(dia.iterrows())]
out['diamond_OOL'] = {'n': int(len(dia)), 'target_mass': 0.95,
                      'mean_pred_target_mass': float(np.mean(dia_pred))}
print(f'  diamond OOL: mean predicted target mass {np.mean(dia_pred)*100:.1f}% (target 95%)')

with open('md5v4bg_authoritative.json', 'w', encoding='utf-8') as f:
    import json; json.dump(out, f, ensure_ascii=False, indent=2)
print('saved md5v4bg_authoritative.json')
