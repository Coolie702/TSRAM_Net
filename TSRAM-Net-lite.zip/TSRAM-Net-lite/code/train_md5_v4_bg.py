"""
MD5 真实物理混合训练 —— 改进版 v2
================================================================================
在 retrieval_md5_real.py 基础上的关键改进：

1. 散射系数随机化：训练时每个样本随机扰动 s_i (±50%)，迫使模型从强度反推重量比，
   而不是记住固定的散射系数映射。
2. 模型解耦散射系数：丰度头输出后除以可学习的散射系数 log_scatter，
   让注意力权重反映光谱强度比例，输出丰度反映重量百分比。
3. 低丰度加权损失：丰度 MSE 按 1/sqrt(abundance) 加权，解决 5% 丰度召回差。
4. 排序一致性损失：保证主要组分预测丰度 > 次要组分，减少主次颠倒。
5. 更丰富的数据增强：强度缩放、波数微小偏移、峰宽随机变化、随机消峰。
6. 学习率 warmup + 更长训练 (200 epoch)。

输出前缀: md5v2_  (不覆盖原 md5retrieval_* 结果)
"""

import os, json, warnings
import numpy as np
import pandas as pd
from scipy.interpolate import interp1d
from scipy.signal import savgol_filter
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, TensorDataset
from sklearn.metrics import f1_score
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

warnings.filterwarnings('ignore')

# ============================================================
# 配置
# ============================================================
MD5_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'md5')
XLSX_SPECTRA = os.path.join(MD5_DIR, 'Raman_Spectra_Mineral_Mixtures.xlsx')
CSV_DIAMOND = os.path.join(MD5_DIR, 'Raman_Spectra_Diamond_Mixtures.csv')
XLSX_BASELINE = os.path.join(MD5_DIR, 'Quantitative_Models_Predictions.xlsx')
OUT_PREFIX = 'md5v4bg'

SEED = 42
np.random.seed(SEED)
torch.manual_seed(SEED)

WAVENUMBER_MIN = 300.0
WAVENUMBER_MAX = 1500.0
N_WAVENUMBER_POINTS = 1024
COMMON_WAVENUMBER = np.linspace(WAVENUMBER_MIN, WAVENUMBER_MAX, N_WAVENUMBER_POINTS)

FEATURE_DIM = 1024
TEMPERATURE_INIT = 4.0
TEMPERATURE_MIN = 0.3
SPARSITY_LAMBDA = 0.003
LAMBDA_RECON = 0.15

BATCH_SIZE = 512
N_EPOCHS = 200
LEARNING_RATE = 8e-4
WARMUP_EPOCHS = 10
N_TRAIN_SAMPLES = 32000
N_VAL_SAMPLES = 4000
PURE_PROB = 0.12

# 改进: 散射系数随机化强度
SCATTER_RANDOM_STD = 0.4   # log-normal 扰动标准差，0.4 ≈ ±50%
# 改进: 低丰度损失权重
LOW_ABUNDANCE_WEIGHT = 3.0
# 改进: 排序损失权重
RANK_LOSS_WEIGHT = 0.5
LAMBDA_BG = 0.5        # 背景重建损失权重
LAMBDA_TV = 0.1        # 背景平滑(一阶差分)正则权重

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Device: {DEVICE} | Window: {WAVENUMBER_MIN:.0f}-{WAVENUMBER_MAX:.0f} cm-1")
print("=" * 70)
print("  MD5 改进版训练 v2 —— 散射随机化 + 解耦 + 低丰度加权")
print("=" * 70)


# ============================================================
# Step 1: 加载 MD5 真实数据
# ============================================================
def preprocess_raw(wavenums, intensities):
    wavenums = np.asarray(wavenums, dtype=np.float64)
    intensities = np.asarray(intensities, dtype=np.float64)
    mask = (wavenums >= WAVENUMBER_MIN) & (wavenums <= WAVENUMBER_MAX)
    if mask.sum() < 50:
        return None
    w, i = wavenums[mask], intensities[mask]
    order = np.argsort(w)
    w, i = w[order], i[order]
    uw, uidx = np.unique(w, return_inverse=True)
    ui = np.array([i[uidx == k].mean() for k in range(len(uw))])
    interp = interp1d(uw, ui, kind='linear', bounds_error=False, fill_value=0.0)
    spec = interp(COMMON_WAVENUMBER)
    spec = savgol_filter(spec, window_length=15, polyorder=2)
    smin, smax = spec.min(), spec.max()
    if smax - smin < 1e-8:
        return None
    return ((spec - smin) / (smax - smin)).astype(np.float32)


print("\n[Step 1] 加载 MD5 实测谱...")
xl = pd.ExcelFile(XLSX_SPECTRA)
MINERALS = xl.sheet_names
N_MINERALS = len(MINERALS)
mineral_to_idx = {m: k for k, m in enumerate(MINERALS)}

rows_by_pkey = {}
for sheet in MINERALS:
    df_sheet = pd.read_excel(xl, sheet_name=sheet)
    for _, row in df_sheet.iterrows():
        rows_by_pkey[row['pkey']] = row
data = pd.DataFrame(list(rows_by_pkey.values())).reset_index(drop=True)

spec_cols = [c for c in data.columns if isinstance(c, (int, np.integer))]
raw_wn = np.array(sorted(int(c) for c in spec_cols), dtype=np.float64)
col_by_wn = {int(c): c for c in spec_cols}
ordered_spec_cols = [col_by_wn[int(w)] for w in raw_wn]

abund_pct = data[MINERALS].apply(pd.to_numeric, errors='coerce').fillna(0.0)

X_real = np.zeros((len(data), N_WAVENUMBER_POINTS), dtype=np.float32)
valid = np.ones(len(data), dtype=bool)
for i, (_, row) in enumerate(data.iterrows()):
    raw_int = row[ordered_spec_cols].values.astype(np.float64)
    sp = preprocess_raw(raw_wn, raw_int)
    if sp is None:
        valid[i] = False
    else:
        X_real[i] = sp
data = data[valid].reset_index(drop=True)
X_real = X_real[valid]
abund_pct = abund_pct[valid].reset_index(drop=True)
print(f"  去重后真实样本: {len(data)}")

endmember_idx = []
for m in MINERALS:
    hit = data.index[(abund_pct[m] == 100.0) & (abund_pct.sum(axis=1) == 100.0)].tolist()
    endmember_idx.append(hit[0])
reference_spectra = X_real[endmember_idx].copy()
print(f"  参考库: {reference_spectra.shape}（{N_MINERALS} 条真实纯端元）")

n_comp = (abund_pct.values > 0).sum(axis=1)
is_pure = n_comp == 1
minor_frac = np.full(len(data), np.nan)
for i in np.where(~is_pure)[0]:
    v = abund_pct.values[i][abund_pct.values[i] > 0]
    minor_frac[i] = v.min()

y_pres_real = (abund_pct.values > 0).astype(np.float32)
y_abun_real = (abund_pct.values / 100.0).astype(np.float32)
print(f"  纯端元 {is_pure.sum()} 条 | 二元混合 {(~is_pure).sum()} 条")

reference_tensor = torch.from_numpy(reference_spectra)
np.save(f'{OUT_PREFIX}_ref_spectra.npy', reference_spectra)

# —— 散射系数 NNLS 拟合 ——
from scipy.optimize import nnls
print("\n  [散射系数] 从真实二元混合反推 s_i...")
n_mix = sum(1 for idx in range(len(data)) if (y_abun_real[idx] > 0).sum() >= 2)
big_A = np.zeros((n_mix * N_WAVENUMBER_POINTS, N_MINERALS), dtype=np.float32)
big_b = np.zeros(n_mix * N_WAVENUMBER_POINTS, dtype=np.float32)
row = 0
for idx in range(len(data)):
    a = y_abun_real[idx]
    active = a > 0
    if active.sum() < 2:
        continue
    for k in np.where(active)[0]:
        big_A[row:row+N_WAVENUMBER_POINTS, k] = a[k] * reference_spectra[k]
    big_b[row:row+N_WAVENUMBER_POINTS] = X_real[idx]
    row += N_WAVENUMBER_POINTS
s_fit, res = nnls(big_A, big_b)
s_fit = s_fit / (s_fit.max() + 1e-12)
SCATTER_COEFFS = s_fit.astype(np.float32)
print(f"    NNLS 残差: {res:.4f} | 范围: {SCATTER_COEFFS.min():.4f} ~ {SCATTER_COEFFS.max():.4f}")
np.save(f'{OUT_PREFIX}_scatter_coeffs.npy', SCATTER_COEFFS)

scatter_weighted_spectra = (SCATTER_COEFFS[:, None] * reference_spectra).astype(np.float32)
scatter_weighted_tensor = torch.from_numpy(scatter_weighted_spectra)

# —— 真实基线提取 ——
print("\n  [基线提取] 从真实混合谱提取残差基线...")
real_baselines = []
for idx in range(len(data)):
    a = y_abun_real[idx]
    active = a > 0
    if active.sum() < 2:
        continue
    linear_part = np.zeros(N_WAVENUMBER_POINTS, dtype=np.float32)
    for k in np.where(active)[0]:
        linear_part += a[k] * SCATTER_COEFFS[k] * reference_spectra[k]
    lo, hi = linear_part.min(), linear_part.max()
    if hi - lo < 1e-8:
        continue
    linear_norm = (linear_part - lo) / (hi - lo)
    residual = X_real[idx] - linear_norm
    residual_smooth = savgol_filter(residual, window_length=51, polyorder=2)
    real_baselines.append(residual_smooth.astype(np.float32))
REAL_BASELINES = np.array(real_baselines) if real_baselines else None
print(f"    提取到 {len(REAL_BASELINES)} 条真实基线")


# ============================================================
# Step 2: 改进版数据生成（散射随机化 + 丰富增强）
# ============================================================
def random_baseline():
    if REAL_BASELINES is not None and np.random.rand() < 0.8:
        base = REAL_BASELINES[np.random.randint(len(REAL_BASELINES))].copy()
        base = base * np.random.uniform(0.5, 1.5) + np.random.uniform(-0.03, 0.03)
        return base.astype(np.float32)
    else:
        n_anchor = np.random.randint(4, 7)
        anchors_x = np.linspace(0, 1, n_anchor)
        amp = np.random.uniform(0.02, 0.15)
        anchors_y = np.random.randn(n_anchor) * amp
        f = interp1d(anchors_x, anchors_y, kind='linear', fill_value='extrapolate')
        base = f(np.linspace(0, 1, N_WAVENUMBER_POINTS))
        base += np.random.uniform(-0.05, 0.05) * np.linspace(0, 1, N_WAVENUMBER_POINTS)
        return base.astype(np.float32)


def augment_spectrum(spec):
    """改进: 丰富的数据增强"""
    # 1. 随机强度缩放 (0.8 ~ 1.2)
    spec = spec * np.random.uniform(0.8, 1.2)
    # 2. 随机整体偏移
    spec = spec + np.random.uniform(-0.05, 0.05)
    # 3. 波数微小偏移 (模拟仪器校准差异, ±3 个点)
    shift = np.random.randint(-3, 4)
    if shift != 0:
        spec = np.roll(spec, shift)
        if shift > 0:
            spec[:shift] = spec[shift]
        else:
            spec[shift:] = spec[shift - 1]
    # 4. 额外高斯噪声（v3：约15%样本不加额外噪声，保证覆盖干净输入，避免BN分布偏移）
    if np.random.rand() >= 0.15:
        spec = spec + np.random.uniform(0.005, 0.025) * np.random.randn(N_WAVENUMBER_POINTS).astype(np.float32)
    return spec


def generate_mixture(ref):
    """改进版: 散射系数随机化"""
    if np.random.rand() < PURE_PROB:
        chosen = np.array([np.random.randint(N_MINERALS)])
        ratios = np.array([1.0])
    else:
        chosen = np.random.choice(N_MINERALS, size=2, replace=False)
        ratios = np.random.dirichlet(np.ones(2)).astype(np.float32)

    # 改进: 散射系数随机扰动 (log-normal)
    scatter_perturbed = SCATTER_COEFFS.copy()
    for idx in chosen:
        scatter_perturbed[idx] *= np.exp(np.random.randn() * SCATTER_RANDOM_STD)
    scatter_perturbed = scatter_perturbed / (scatter_perturbed.max() + 1e-12)

    # 物理模型: real ∝ Σ s_i * w_i * ref_i
    mixed = np.zeros(N_WAVENUMBER_POINTS, dtype=np.float32)
    for idx, r in zip(chosen, ratios):
        mixed += r * scatter_perturbed[idx] * ref[idx]

    # 域增强
    mixed = mixed + random_baseline()
    mixed = augment_spectrum(mixed)
    mixed = savgol_filter(mixed, window_length=15, polyorder=2)
    lo, hi = mixed.min(), mixed.max()
    mixed = (mixed - lo) / (hi - lo + 1e-12)

    presence = np.zeros(N_MINERALS, dtype=np.float32)
    abundance = np.zeros(N_MINERALS, dtype=np.float32)
    presence[chosen] = 1.0
    abundance[chosen] = ratios  # 标签始终是重量百分比，不是强度比例
    # v4: 纯线性部分（无基线/噪声）min-max 归一化 —— 背景重建监督目标
    lin = np.zeros(N_WAVENUMBER_POINTS, dtype=np.float32)
    for idx, r in zip(chosen, ratios):
        lin += r * scatter_perturbed[idx] * ref[idx]
    lin = savgol_filter(lin, window_length=15, polyorder=2)
    lo_, hi_ = lin.min(), lin.max()
    lin = (lin - lo_) / (hi_ - lo_ + 1e-12)
    return mixed.astype(np.float32), presence, abundance, lin.astype(np.float32)


def make_synth(n, ref):
    X = np.zeros((n, N_WAVENUMBER_POINTS), dtype=np.float32)
    yp = np.zeros((n, N_MINERALS), dtype=np.float32)
    ya = np.zeros((n, N_MINERALS), dtype=np.float32)
    Xl = np.zeros((n, N_WAVENUMBER_POINTS), dtype=np.float32)
    for i in range(n):
        X[i], yp[i], ya[i], Xl[i] = generate_mixture(ref)
    return X, yp, ya, Xl


print("\n[Step 2] 生成改进版训练数据（散射随机化 + 丰富增强）...")
X_train, yp_train, ya_train, Xl_train = make_synth(N_TRAIN_SAMPLES, reference_spectra)
X_val, yp_val, ya_val, Xl_val = make_synth(N_VAL_SAMPLES, reference_spectra)
print(f"  train {X_train.shape} | val {X_val.shape}")

train_loader = DataLoader(TensorDataset(torch.from_numpy(X_train), torch.from_numpy(yp_train),
                                        torch.from_numpy(ya_train), torch.from_numpy(Xl_train)),
                          batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(TensorDataset(torch.from_numpy(X_val), torch.from_numpy(yp_val),
                                      torch.from_numpy(ya_val)),
                        batch_size=BATCH_SIZE, shuffle=False)
real_loader = DataLoader(TensorDataset(torch.from_numpy(X_real), torch.from_numpy(y_pres_real),
                                       torch.from_numpy(y_abun_real)),
                         batch_size=BATCH_SIZE, shuffle=False)


# ============================================================
# Step 3: 改进版模型（散射系数解耦）
# ============================================================
class SpectralEncoder(nn.Module):
    def __init__(self, input_dim=1024, feature_dim=1024):
        super().__init__()
        self.fc1 = nn.Sequential(nn.Linear(input_dim, feature_dim), nn.BatchNorm1d(feature_dim), nn.ReLU())
        self.fc2 = nn.Sequential(nn.Linear(feature_dim, feature_dim), nn.BatchNorm1d(feature_dim), nn.ReLU())
        self.fc3 = nn.Linear(feature_dim, feature_dim)

    def forward(self, x):
        h = self.fc1(x)
        h = self.fc2(h) + h
        h = self.fc3(h) + h
        return F.normalize(h, p=2, dim=-1)


def sparsemax(logits, dim=-1):
    if dim < 0:
        dim = logits.ndim + dim
    z = logits - logits.max(dim=dim, keepdim=True)[0]
    z_sorted, _ = torch.sort(z, dim=dim, descending=True)
    z_cumsum = torch.cumsum(z_sorted, dim=dim)
    k = torch.arange(1, z.shape[dim] + 1, device=logits.device, dtype=logits.dtype)
    k = k.view(*[1 if i != dim else -1 for i in range(z.ndim)])
    cond = 1 + k * z_sorted > z_cumsum
    k_max = cond.float().sum(dim=dim, keepdim=True).long() - 1
    k_max = k_max.clamp(min=0)
    # v3 修复：标准 sparsemax 投影阈值 tau 可为负，禁止 clamp(min=0)（Martins & Astudillo 2016）
    tau = (z_cumsum.gather(dim, k_max) - 1) / (k_max.float() + 1)
    return (z - tau).clamp(min=0)


class BackgroundNet(nn.Module):
    """端到端背景估计：输入归一化混合谱，输出平滑荧光/散射背景（LayerNorm 保证单样本一致）"""
    def __init__(self, dim=N_WAVENUMBER_POINTS):
        super().__init__()
        self.fc1 = nn.Linear(dim, 512); self.ln1 = nn.LayerNorm(512)
        self.fc2 = nn.Linear(512, 256); self.ln2 = nn.LayerNorm(256)
        self.fc3 = nn.Linear(256, dim)
        k = 15; xk = np.arange(k) - k // 2
        g = np.exp(-(xk ** 2) / (2 * (2.0 ** 2))); g = g / g.sum()
        self.register_buffer('smooth_w', torch.tensor(g, dtype=torch.float32).view(1, 1, -1))
    def forward(self, x):
        h = F.relu(self.ln1(self.fc1(x)))
        h = F.relu(self.ln2(self.fc2(h)))
        b = self.fc3(h)
        b = F.conv1d(b.unsqueeze(1), self.smooth_w, padding=7).squeeze(1)  # 高斯平滑 → 强制荧光低频
        return torch.sigmoid(b) * 0.5   # 归一化空间中背景幅度上限 0.5


class TwoStreamRetrievalModelV2(nn.Module):
    """改进版: 加入可学习散射系数解耦"""
    def __init__(self, n_minerals, feature_dim=1024, temperature_p=4.0, temperature_a=3.0,
                 scatter_coeffs=None):
        super().__init__()
        self.encoder = SpectralEncoder(N_WAVENUMBER_POINTS, feature_dim)
        self.n_minerals = n_minerals
        self.register_buffer('ref_features', torch.zeros(n_minerals, feature_dim))

        self.log_T_p = nn.Parameter(torch.tensor(np.log(temperature_p)))
        self.presence_head = nn.Sequential(
            nn.Linear(feature_dim * 2, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(256, n_minerals))

        self.log_T_a = nn.Parameter(torch.tensor(np.log(temperature_a)))
        self.log_sim_scale = nn.Parameter(torch.tensor(np.log(5.0)))
        self.refiner = nn.Sequential(
            nn.Linear(feature_dim * 3, feature_dim), nn.BatchNorm1d(feature_dim), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(feature_dim, feature_dim // 2), nn.BatchNorm1d(feature_dim // 2), nn.ReLU(), nn.Dropout(0.1),
            nn.Linear(feature_dim // 2, n_minerals))

        # 改进: 可学习散射系数对数 (初始化为NNLS拟合值)
        if scatter_coeffs is not None:
            self.log_scatter = nn.Parameter(torch.log(torch.from_numpy(scatter_coeffs).float() + 1e-8))
        else:
            self.log_scatter = nn.Parameter(torch.zeros(n_minerals))

        # 改进 v4: 端到端背景估计网络（荧光/散射背景由模型学习）
        self.bg_net = BackgroundNet()

    @torch.no_grad()
    def update_ref_features(self, ref_spectra):
        self.eval()
        ref_c = ref_spectra - self.bg_net(ref_spectra)   # 参考谱同样做背景校正（纯端元背景≈0）
        for i in range(0, self.n_minerals, 512):
            self.ref_features[i:i+512] = self.encoder(ref_c[i:i+512].to(self.ref_features.device))
        self.train()

    def _streams(self, x, infer=False):
        Q = self.encoder(x - self.bg_net(x))   # v4: 端到端背景校正
        sim = torch.matmul(Q, self.ref_features.T)
        T_p = torch.exp(self.log_T_p).clamp(min=0.1)
        T_a = torch.exp(self.log_T_a).clamp(min=0.1)
        sim_scale = torch.exp(self.log_sim_scale)

        # Presence stream
        A_p = F.softmax(sim / T_p, dim=-1)
        weighted_p = torch.matmul(A_p, self.ref_features)
        presence_logits = self.presence_head(torch.cat([Q, weighted_p], dim=-1))

        # Abundance stream
        A_init = sparsemax(sim / T_a, dim=-1)
        weighted_init = torch.matmul(A_init, self.ref_features)
        abundance_logits = self.refiner(torch.cat([Q, weighted_init, Q - weighted_init], dim=-1))
        combined = sim * sim_scale + abundance_logits

        # 改进: 散射系数解耦 —— 注意力反映强度比例，减去散射对数得到重量比 logits
        combined_decoupled = combined - self.log_scatter.unsqueeze(0)

        # v3：最终丰度统一用标准 sparsemax（训练/推理一致，输出精确零权重、和为1）
        abundance = sparsemax(combined_decoupled / T_a, dim=-1)
        A_a = abundance
        return presence_logits, abundance, A_p, A_a

    def forward(self, x):
        return self._streams(x, infer=False)

    def predict(self, x):
        return self._streams(x, infer=True)


class MultiLabelContrastiveLoss(nn.Module):
    def __init__(self, temperature=0.40):
        super().__init__()
        self.temperature = temperature

    def forward(self, sim, targets):
        sim_s = sim - sim.max(dim=-1, keepdim=True)[0].detach()
        exp_sim = torch.exp(sim_s / self.temperature)
        Z = exp_sim.sum(dim=-1, keepdim=True).clamp(min=1e-8)
        log_prob = sim_s / self.temperature - torch.log(Z)
        n_pos = targets.sum(dim=-1).clamp(min=1)
        return (-(targets * log_prob).sum(dim=-1) / n_pos).mean()


def low_abundance_weighted_mse(pred, target, weight_factor=LOW_ABUNDANCE_WEIGHT):
    """改进: 低丰度加权MSE，让5%丰度样本得到更多关注"""
    eps = 1e-6
    # 权重: 1 + factor * (1 - target)，低丰度样本权重高
    weights = 1.0 + weight_factor * (1.0 - target.clamp(min=0, max=1))
    # 只在正样本上计算
    pos_mask = (target > eps).float()
    weights = weights * pos_mask
    loss = ((pred - target) ** 2 * weights).sum(dim=-1) / weights.sum(dim=-1).clamp(min=1)
    return loss.mean()


def ranking_loss(pred, target):
    """改进: 排序一致性损失，保证主要组分 > 次要组分"""
    # 对每个样本，找出正样本对，比较预测丰度排序是否和真实一致
    loss = torch.tensor(0.0, device=pred.device)
    count = 0
    B = pred.shape[0]
    for i in range(B):
        pos_idx = torch.where(target[i] > 1e-6)[0]
        if len(pos_idx) < 2:
            continue
        # 取真实丰度最高和最低的两个正样本
        sorted_idx = pos_idx[torch.argsort(target[i, pos_idx], descending=True)]
        major, minor = sorted_idx[0], sorted_idx[-1]
        # 希望 pred[major] > pred[minor]，margin = 0.05
        loss = loss + F.relu(0.05 + pred[i, minor] - pred[i, major])
        count += 1
    return loss / max(count, 1)


# ============================================================
# Step 4: 训练（warmup + 改进损失）
# ============================================================
print(f"\n[Step 3] 训练（{N_EPOCHS} epochs, warmup={WARMUP_EPOCHS}）...")
ref_for_init = reference_tensor.to(DEVICE)
ref_scatter_dev = scatter_weighted_tensor.to(DEVICE)
scatter_coeffs_tensor = torch.from_numpy(SCATTER_COEFFS).to(DEVICE)

model = TwoStreamRetrievalModelV2(N_MINERALS, FEATURE_DIM,
                                  TEMPERATURE_INIT, TEMPERATURE_INIT * 0.75,
                                  scatter_coeffs=SCATTER_COEFFS).to(DEVICE)
model.update_ref_features(ref_for_init)
print(f"  参数量: {sum(p.numel() for p in model.parameters()):,}")

presence_criterion = MultiLabelContrastiveLoss(0.40)
optimizer = optim.AdamW(model.parameters(), lr=LEARNING_RATE, weight_decay=1e-4)

# warmup + cosine decay
def lr_lambda(epoch):
    if epoch < WARMUP_EPOCHS:
        return (epoch + 1) / WARMUP_EPOCHS
    progress = (epoch - WARMUP_EPOCHS) / (N_EPOCHS - WARMUP_EPOCHS)
    return 0.5 * (1 + np.cos(np.pi * progress))
scheduler = optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)

REG_WARMUP = 30
train_losses, val_losses, val_f1_hist, val_mse_hist = [], [], [], []
best_val_f1 = 0.0


def temp_schedule(epoch):
    r = epoch / N_EPOCHS
    return TEMPERATURE_INIT * (TEMPERATURE_MIN / TEMPERATURE_INIT) ** r


for epoch in range(N_EPOCHS):
    model.update_ref_features(ref_for_init)
    # v3：温度 T_p/T_a/sim_scale 自由可学习（不再强制退火到0.3），与 RRUFF 主模型一致
    phys_decay = 0.3 + 0.7 * (1 - epoch / N_EPOCHS)

    model.train()
    ep_loss = 0.0
    for xb, ybp, yba, xl in train_loader:
        xb, ybp, yba, xl = xb.to(DEVICE), ybp.to(DEVICE), yba.to(DEVICE), xl.to(DEVICE)
        presence_logits, abun_pred, A_p, A_a = model(xb)

        loss_p = presence_criterion(presence_logits, ybp)
        # 改进: 低丰度加权MSE
        loss_a = low_abundance_weighted_mse(abun_pred, yba)
        # 改进: 排序一致性损失
        loss_rank = ranking_loss(abun_pred, yba) * RANK_LOSS_WEIGHT

        # v3：移除熵正则（sparsemax 已天然产生精确零权重，无需额外稀疏惩罚）
        # 重构损失用散射加权基矩阵
        recon = torch.matmul(A_a, ref_scatter_dev)
        r_min = recon.min(dim=-1, keepdim=True)[0]
        r_max = recon.max(dim=-1, keepdim=True)[0]
        recon = (recon - r_min) / (r_max - r_min + 1e-8)
        loss_recon = F.mse_loss(recon, xb)

        # v4: 背景重建损失 —— x - bg 逼近纯线性谱（荧光被 bg 吸收）+ 平滑正则
        bg = model.bg_net(xb)
        loss_bg = LAMBDA_BG * F.mse_loss(xb - bg, xl) + LAMBDA_TV * F.mse_loss(bg[:, 1:], bg[:, :-1])

        loss = loss_p + loss_a + loss_rank + phys_decay * LAMBDA_RECON * loss_recon + loss_bg
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        ep_loss += loss.item()
    scheduler.step()
    train_losses.append(ep_loss / len(train_loader))

    model.eval()
    vp, vt, ap, at = [], [], [], []
    vloss = 0.0
    with torch.no_grad():
        for xb, ybp, yba in val_loader:
            xb, ybp_d, yba_d = xb.to(DEVICE), ybp.to(DEVICE), yba.to(DEVICE)
            pl, ab, _, _ = model(xb)
            vloss += (presence_criterion(pl, ybp_d) + F.mse_loss(ab, yba_d)).item()
            vp.append((torch.sigmoid(pl) > 0.5).float().cpu().numpy())
            vt.append(ybp.numpy()); ap.append(ab.cpu().numpy()); at.append(yba.numpy())
    val_losses.append(vloss / len(val_loader))
    vp, vt = np.concatenate(vp), np.concatenate(vt)
    ap, at = np.concatenate(ap), np.concatenate(at)
    f1v = f1_score(vt, vp, average='samples', zero_division=0)
    msev = float(np.mean((ap - at) ** 2))
    val_f1_hist.append(f1v); val_mse_hist.append(msev)

    if f1v > best_val_f1:
        best_val_f1 = f1v
        torch.save(model.state_dict(), f'{OUT_PREFIX}_best_model.pth')
    if (epoch + 1) % 10 == 0 or epoch == 0:
        print(f"  Epoch {epoch+1:3d}/{N_EPOCHS} | train {train_losses[-1]:.4f} | "
              f"val {val_losses[-1]:.4f} | F1 {f1v:.4f} | MSE {msev:.5f} | "
              f"lr {scheduler.get_last_lr()[0]:.2e} | Tp {float(torch.exp(model.log_T_p)):.2f} "
              f"Ta {float(torch.exp(model.log_T_a)):.2f}")

print(f"  最佳合成验证 F1 = {best_val_f1:.4f}")


# ============================================================
# Step 5: 真实物理混合测试
# ============================================================
print("\n[Step 4] 真实物理混合样本评估...")
model.load_state_dict(torch.load(f'{OUT_PREFIX}_best_model.pth', map_location=DEVICE))
model.update_ref_features(ref_for_init)
model.eval()

# 阈值在合成验证集上确定
val_probs, val_labels = [], []
with torch.no_grad():
    for xb, ybp, _ in val_loader:
        pl, _, _, _ = model(xb.to(DEVICE))
        val_probs.append(torch.sigmoid(pl).cpu().numpy()); val_labels.append(ybp.numpy())
val_probs = np.concatenate(val_probs); val_labels = np.concatenate(val_labels)
best_th, best_f1_th = 0.5, 0.0
for th in np.arange(0.1, 0.95, 0.05):
    f1 = f1_score(val_labels, (val_probs > th).astype(float), average='samples', zero_division=0)
    if f1 > best_f1_th:
        best_f1_th, best_th = f1, th
print(f"  合成验证集确定 presence 阈值: {best_th:.2f} (val F1={best_f1_th:.4f})")

real_probs, real_abun, real_Aa = [], [], []
with torch.no_grad():
    for xb, _, _ in real_loader:
        pl, ab, _, Aa = model.predict(xb.to(DEVICE))
        real_probs.append(torch.sigmoid(pl).cpu().numpy())
        real_abun.append(ab.cpu().numpy()); real_Aa.append(Aa.cpu().numpy())
real_probs = np.concatenate(real_probs)
real_abun = np.concatenate(real_abun)
real_Aa = np.concatenate(real_Aa)
real_pres = (real_probs > best_th).astype(float)

# 丰度后处理: 检出端元上重归一化
real_abun_raw = real_abun.copy()
n_detected = real_pres.sum(axis=1)
real_abun = real_abun_raw.copy()
n_renormed = 0
for i in np.where(n_detected >= 2)[0]:
    det = real_pres[i] > 0.5
    mass = real_abun_raw[i, det]
    if mass.sum() > 1e-8:
        real_abun[i] = 0.0
        real_abun[i, det] = mass / mass.sum()
        n_renormed += 1
print(f"  丰度重归一化样本: {n_renormed}/{len(real_abun)}")

# 整体指标
metrics = {}
metrics['n_real_samples'] = int(len(data))
metrics['n_pure'] = int(is_pure.sum()); metrics['n_binary'] = int((~is_pure).sum())
metrics['presence_threshold'] = float(best_th)
metrics['F1_sample'] = float(f1_score(y_pres_real, real_pres, average='samples', zero_division=0))
metrics['F1_micro'] = float(f1_score(y_pres_real, real_pres, average='micro', zero_division=0))
metrics['F1_macro'] = float(f1_score(y_pres_real, real_pres, average='macro', zero_division=0))
metrics['MSE_frac'] = float(np.mean((real_abun - y_abun_real) ** 2))
metrics['MAE_frac'] = float(np.mean(np.abs(real_abun - y_abun_real)))
metrics['MSE_pctpt'] = metrics['MSE_frac'] * 1e4
metrics['MAE_pctpt'] = metrics['MAE_frac'] * 100
dot = (real_abun * y_abun_real).sum(1)
den = np.maximum(np.linalg.norm(real_abun, axis=1) * np.linalg.norm(y_abun_real, axis=1), 1e-10)
metrics['cosine_sim'] = float((dot / den).mean())
metrics['avg_effective_support_gt1e-2'] = float((real_abun > 1e-2).sum(1).mean())
metrics['avg_effective_support_gt1e-3'] = float((real_abun > 1e-3).sum(1).mean())
metrics['TP'] = float(((real_pres == 1) & (y_pres_real == 1)).sum(1).mean())
metrics['FP'] = float(((real_pres == 1) & (y_pres_real == 0)).sum(1).mean())
metrics['FN'] = float(((real_pres == 0) & (y_pres_real == 1)).sum(1).mean())

# 逐矿物 RMSE-P
bin_idx = np.where(~is_pure)[0]
per_mineral = []
for k, m in enumerate(MINERALS):
    sel = bin_idx[y_abun_real[bin_idx, k] > 0]
    if len(sel) == 0:
        per_mineral.append((m, 0, np.nan, np.nan)); continue
    true_pct = y_abun_real[sel, k] * 100
    pred_pct = real_abun[sel, k] * 100
    rmse_p = float(np.sqrt(np.mean((pred_pct - true_pct) ** 2)))
    mae_p = float(np.mean(np.abs(pred_pct - true_pct)))
    per_mineral.append((m, len(sel), rmse_p, mae_p))

# vs PLS
pls_tbl = pd.read_excel(XLSX_BASELINE, sheet_name='DM_RMSE-P')
pls_map = dict(zip(pls_tbl['Mineral'], pls_tbl['RMSE-P']))
ours_map = {m: rm for m, _, rm, _ in per_mineral}
common = [m for m in MINERALS if m in pls_map]
cmp_rows = [(m, ours_map[m], float(pls_map[m]), ours_map[m] - float(pls_map[m])) for m in common]
cmp_df = pd.DataFrame(cmp_rows, columns=['mineral', 'ours_RMSE_P', 'PLS_RMSE_P', 'delta'])
metrics['mean_ours_RMSEP_common18'] = float(cmp_df['ours_RMSE_P'].mean())
metrics['mean_PLS_RMSEP_common18'] = float(cmp_df['PLS_RMSE_P'].mean())
wins = int((cmp_df['delta'] < 0).sum())
metrics['minerals_we_beat_PLS'] = f"{wins}/18"

# 分层
strata_ratio = {}
for r in [5, 20, 50]:
    sel = bin_idx[np.isclose(minor_frac[bin_idx], r)]
    if len(sel) == 0:
        continue
    minor_true, minor_pred, minor_hit = [], [], 0
    for i in sel:
        true_pair = np.where(y_abun_real[i] > 0)[0]
        minor_k = true_pair[np.argmin(y_abun_real[i, true_pair])]
        minor_true.append(y_abun_real[i, minor_k]); minor_pred.append(real_abun[i, minor_k])
        minor_hit += int(real_pres[i, minor_k] > 0.5)
    strata_ratio[f'{r:02d}_pct'] = {
        'n': int(len(sel)),
        'minor_abundance_MAE_pctpt': float(np.mean(np.abs(np.array(minor_pred) - np.array(minor_true))) * 100),
        'minor_presence_recall': float(minor_hit / len(sel)),
        'cosine': float(np.mean((real_abun[sel] * y_abun_real[sel]).sum(1) /
                                np.maximum(np.linalg.norm(real_abun[sel], axis=1) *
                                           np.linalg.norm(y_abun_real[sel], axis=1), 1e-10))),
    }

# 金刚石压力测试
dia = pd.read_csv(CSV_DIAMOND)
dia_spec_cols = [c for c in dia.columns if str(c).replace('.', '').isdigit()]
dia_wn = np.array(sorted(float(c) for c in dia_spec_cols))
dia_col = {float(c): c for c in dia_spec_cols}
X_dia = np.zeros((len(dia), N_WAVENUMBER_POINTS), dtype=np.float32)
for i, (_, row) in enumerate(dia.iterrows()):
    raw = np.array([row[dia_col[w]] for w in dia_wn], dtype=np.float64)
    X_dia[i] = preprocess_raw(dia_wn, raw)
with torch.no_grad():
    _, ab_dia, _, _ = model.predict(torch.from_numpy(X_dia).to(DEVICE))
    ab_dia = ab_dia.cpu().numpy()
dia_mass_err = []
for i, (_, row) in enumerate(dia.iterrows()):
    k = mineral_to_idx[row['Mineral']]
    dia_mass_err.append(abs(ab_dia[i, k] - 0.95) * 100)
diamond_strata = {
    'n': int(len(dia)),
    'target_mineral_mass': 0.95,
    'mean_pred_target_mass': float(np.mean([ab_dia[i, mineral_to_idx[row['Mineral']]]
                                            for i, (_, row) in enumerate(dia.iterrows())])),
    'MAE_pctpt_on_library_mineral': float(np.mean(dia_mass_err)),
}

results = {'overall': metrics,
           'per_mineral_RMSEP': [{'mineral': m, 'n_mixtures': n, 'RMSE_P_pctpt': rm, 'MAE_P_pctpt': ma}
                                 for m, n, rm, ma in per_mineral],
           'vs_PLS_RMSEP': cmp_df.to_dict(orient='records'),
           'strata_by_minor_ratio': strata_ratio,
           'diamond_out_of_library': diamond_strata}
with open(f'{OUT_PREFIX}_metrics.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)

# 预测落盘
pred_df = data[['pkey', 'vial_name', 'gr_size']].copy()
pred_df['type'] = np.where(is_pure, 'pure', 'binary')
pred_df['minor_pct'] = minor_frac
for k, m in enumerate(MINERALS):
    pred_df[f'true__{m}'] = y_abun_real[:, k]
for k, m in enumerate(MINERALS):
    pred_df[f'pred__{m}'] = real_abun[:, k]
for k, m in enumerate(MINERALS):
    pred_df[f'presprob__{m}'] = real_probs[:, k]
pred_df.to_csv(f'{OUT_PREFIX}_predictions.csv', index=False)

# 打印
print(f"\n{'='*66}")
print(f"  真实物理混合测试结果（{len(data)} 样本）")
print(f"{'='*66}")
print(f"  Presence  F1 = {metrics['F1_sample']:.4f} (阈值 {best_th:.2f})")
print(f"            TP/FP/FN = {metrics['TP']:.2f}/{metrics['FP']:.2f}/{metrics['FN']:.2f}")
print(f"  Abundance MAE = {metrics['MAE_pctpt']:.2f} pp | Cosine = {metrics['cosine_sim']:.4f}")
print(f"\n  逐矿物 RMSE-P vs PLS:")
print(f"  {'mineral':16s} {'n':>3s} {'ours':>7s} {'PLS':>7s} {'delta':>7s}")
for m, n, rm, ma in per_mineral:
    pls = pls_map.get(m, None)
    tag = f"{pls:7.1f} {rm - pls:+7.1f}" if pls is not None else "   --      --"
    print(f"  {m:16s} {n:3d} {rm:7.2f} {tag}")
print(f"  18矿平均 RMSE-P: ours {metrics['mean_ours_RMSEP_common18']:.2f} vs "
      f"PLS {metrics['mean_PLS_RMSEP_common18']:.2f} | 赢 PLS: {metrics['minerals_we_beat_PLS']}")
print(f"\n  按次要组分配比分层:")
for k_, v in strata_ratio.items():
    print(f"    minor {k_}: n={v['n']:3d} | MAE {v['minor_abundance_MAE_pctpt']:5.2f} pp | "
          f"召回 {v['minor_presence_recall']:.3f} | cos {v['cosine']:.4f}")
print(f"  金刚石压力测试: 预测均值 {diamond_strata['mean_pred_target_mass']*100:.1f}% (目标95%), "
      f"MAE {diamond_strata['MAE_pctpt_on_library_mineral']:.2f} pp")
print(f"{'='*66}")


# ============================================================
# Step 6: 可视化
# ============================================================
print("\n[Step 5] 可视化...")
fig, axes = plt.subplots(2, 3, figsize=(20, 11))

ax = axes[0, 0]
ax.plot(train_losses, label='train', alpha=.8); ax.plot(val_losses, label='syn-val', alpha=.8)
ax.set_xlabel('epoch'); ax.set_ylabel('loss'); ax.set_title('Loss'); ax.legend(); ax.grid(alpha=.3)

ax = axes[0, 1]
ax.plot(val_f1_hist, c='g'); ax.set_xlabel('epoch'); ax.set_ylabel('F1 sample')
ax.set_title('Synthetic-val Presence F1'); ax.grid(alpha=.3)

ax = axes[0, 2]
ax.plot(val_mse_hist, c='orange'); ax.set_xlabel('epoch'); ax.set_ylabel('MSE')
ax.set_title('Synthetic-val Abundance MSE'); ax.grid(alpha=.3)

ax = axes[1, 0]
order = np.argsort([ours_map[m] for m in common])
m_sorted = [common[i] for i in order]
xpos = np.arange(len(m_sorted))
ax.bar(xpos - .2, [ours_map[m] for m in m_sorted], .4, label='ours v2', color='coral', alpha=.85)
ax.bar(xpos + .2, [pls_map[m] for m in m_sorted], .4, label='PLS', color='steelblue', alpha=.85)
ax.set_xticks(xpos); ax.set_xticklabels([m[:10] for m in m_sorted], rotation=45, ha='right', fontsize=7)
ax.set_ylabel('RMSE-P (pp)'); ax.set_title('Per-mineral RMSE-P (v2 vs PLS)')
ax.legend(); ax.grid(alpha=.3, axis='y')

ax = axes[1, 1]
colors = {5: 'tab:red', 20: 'tab:orange', 50: 'tab:green'}
for r, c in colors.items():
    sel = bin_idx[np.isclose(minor_frac[bin_idx], r)]
    tt, pp = [], []
    for i in sel:
        pair = np.where(y_abun_real[i] > 0)[0]
        for k in pair:
            tt.append(y_abun_real[i, k] * 100); pp.append(real_abun[i, k] * 100)
    ax.scatter(tt, pp, s=18, alpha=.5, c=c, label=f'minor={r}% (n={len(sel)})')
ax.plot([0, 100], [0, 100], 'k--', lw=1)
ax.set_xlabel('true (%)'); ax.set_ylabel('pred (%)')
ax.set_title('True vs Predicted abundance'); ax.legend(fontsize=8); ax.grid(alpha=.3)

ax = axes[1, 2]
show_i = [bin_idx[np.where(np.isclose(minor_frac[bin_idx], 5))[0][0]],
          bin_idx[np.where(np.isclose(minor_frac[bin_idx], 20))[0][0]],
          bin_idx[np.where(np.isclose(minor_frac[bin_idx], 50))[0][0]]]
for off, i in enumerate(show_i):
    recon = (real_abun[i][:, None] * scatter_weighted_spectra).sum(0)
    rlo, rhi = recon.min(), recon.max()
    recon = (recon - rlo) / (rhi - rlo + 1e-12)
    pair = np.where(y_abun_real[i] > 0)[0]
    tag = '+'.join(f"{MINERALS[k][:6]} {y_abun_real[i,k]*100:.0f}%" for k in pair)
    ax.plot(COMMON_WAVENUMBER, X_real[i] + off * 1.6, color='k', lw=1)
    ax.plot(COMMON_WAVENUMBER, recon + off * 1.6, color='r', ls='--', lw=1)
    ax.text(WAVENUMBER_MIN + 5, off * 1.6 + 1.25, tag, fontsize=8)
ax.set_xlabel('Raman shift (cm-1)'); ax.set_ylabel('intensity (offset)')
ax.set_title('Real (black) vs reconstruction (red)'); ax.grid(alpha=.3)

plt.tight_layout()
plt.savefig(f'{OUT_PREFIX}_results.png', dpi=150, bbox_inches='tight')
plt.close()
print(f"  已保存 {OUT_PREFIX}_results.png")
print(f"  落盘: {OUT_PREFIX}_metrics.json / {OUT_PREFIX}_predictions.csv / {OUT_PREFIX}_best_model.pth")
print("\n训练完成！")
