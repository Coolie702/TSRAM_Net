# -*- coding: utf-8 -*-
"""
Fig 6 (weak-component detection limit) for the OE manuscript.
Presence recall of the true minor component as a function of its fraction.
  - RRUFF K=1000 main model (red, controlled fixed-fraction mixtures, 1% noise)
  - RRUFF K=1000 gentle minority fine-tuning (grey)
  - real MD5 K=20 five-fold label-efficient (blue, mean +/- std)
All numbers are read directly from the result JSONs; nothing is hand-coded.
"""
import os
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams

# Arial / scientific style, consistent with Fig.2/Fig.3 (plot_revision_figs.py).
rcParams["font.family"] = "Arial"
rcParams["pdf.fonttype"] = 42
rcParams["ps.fonttype"] = 42
rcParams["font.size"] = 7
rcParams["axes.linewidth"] = 0.6
rcParams["xtick.major.width"] = 0.6
rcParams["ytick.major.width"] = 0.6
rcParams["legend.fontsize"] = 6.4
rcParams["axes.labelsize"] = 7.5

C_TSRAM = "#d62728"   # red
C_FINE  = "#7f7f7f"   # grey
C_K20   = "#1f77b4"   # blue

b1 = json.load(open("rruff_weakmin_b1.json", encoding="utf-8"))
b1b = json.load(open("rruff_weakmin_b1b.json", encoding="utf-8"))
md5 = json.load(open("md5_weakmin_5fold_scratch_summary.json", encoding="utf-8"))

bins = ["5pct", "10pct", "20pct", "35pct", "50pct"]
frac = [5, 10, 20, 35, 50]
xpos = list(range(len(frac)))
base = [b1["baseline"]["fixed_bins_1pct"][b]["minor_recall"] for b in bins]
fine = [b1b["b1b_finetune"]["fixed_bins_1pct"][b]["minor_recall"] for b in bins]

# MD5 five-fold only reports the 5/20/50% minor bins.
md5_frac = [5, 20, 50]
md5_x = [frac.index(v) for v in md5_frac]
mr = md5["minor_recall"]
md5_y = [mr[str(v)]["mean"] for v in md5_frac]
md5_e = [mr[str(v)]["std"] for v in md5_frac]

fig, ax = plt.subplots(figsize=(5.16, 3.54))

# K=1000 floor band (recall essentially zero in the 0-5% region).
ax.axhspan(0.0, 0.05, color=C_TSRAM, alpha=0.06, zorder=0)

ax.plot(xpos, base, "-o", color=C_TSRAM, lw=1.4, ms=4.2, zorder=3,
        label="TSRAM-Net, $K=1000$ (main model)")
ax.plot(xpos, fine, "--s", color=C_FINE, lw=1.2, ms=3.8, zorder=3,
        label="gentle fine-tuning, $K=1000$")
ax.errorbar(md5_x, md5_y, yerr=md5_e, fmt="-^", color=C_K20, lw=1.3, ms=4.4,
            capsize=2.2, elinewidth=0.9, zorder=3,
            label="TSRAM-Net, $K=20$ (real MD5, 5-fold)")

# Double-headed arrow contrasting 5% recall at K=1000 vs K=20.
ax.annotate("", xy=(0, base[0]), xytext=(0, md5_y[0]),
            arrowprops=dict(arrowstyle="<->", color="black", lw=0.8,
                            shrinkA=2, shrinkB=2), zorder=4)


ax.set_xticks(xpos)
ax.set_xticklabels([str(v) for v in frac])
ax.set_xlabel("True minor-component fraction (%)")
ax.set_ylabel("Presence recall of the minor component")
ax.set_ylim(-0.03, 1.07)
ax.set_xlim(-0.3, 4.3)
ax.grid(True, ls=":", lw=0.45, alpha=0.55, zorder=0)
ax.legend(loc="lower right", frameon=True, framealpha=0.95)

fig.subplots_adjust(left=0.155, right=0.985, bottom=0.135, top=0.982)
fig.savefig("fig_weakmin_final.pdf")
fig.savefig("fig_weakmin_final.png", dpi=600)
plt.close()
print("base K=1000     :", base)
print("fine K=1000     :", fine)
print("MD5 K=20 5/20/50:", md5_y, "+/-", md5_e)
print("saved fig_weakmin_final.pdf/.png")
