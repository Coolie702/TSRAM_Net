# -*- coding: utf-8 -*-
"""
Redraw Fig.2 (K-scaling) and Fig.3 (noise) at their FINAL printed size.

The old versions were drawn on an 11.5 x 4.3 in canvas with 11 pt type and then
scaled to 0.68\textwidth (4.87 in), i.e. by 0.42x -- so the labels landed at
4.7 pt on paper while the new Fig.1 sits at 7.0 pt.  Here the canvas IS the
printed size and every element is sized for it, so the whole set of figures
carries one type scale.

Numbers are read from the same JSONs as before; nothing is recomputed.
"""
import os
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams

rcParams.update({
    "font.family": "Arial",
    "font.size": 8.0,
    "axes.linewidth": 0.7,
    "xtick.major.width": 0.7,
    "ytick.major.width": 0.7,
    "xtick.major.size": 2.8,
    "ytick.major.size": 2.8,
    "xtick.labelsize": 7.5,
    "ytick.labelsize": 7.5,
    "legend.fontsize": 7.5,
    "axes.labelsize": 8.0,
    "axes.titlesize": 8.5,
    "mathtext.fontset": "dejavusans",
    "pdf.fonttype": 42,
    "svg.fonttype": "none",
})

C_TSRAM = "#d62728"
C_MLP = "#7f7f7f"
C_SUN = "#2ca02c"
C_FCLS = "#1f77b4"

W, H = 7.16, 1.50          # == \textwidth, the width it is included at (8 pt type)
STY = dict(lw=1.05, ms=3.2, mew=0.0)


def frame():
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(W, H))
    fig.subplots_adjust(left=0.062, right=0.995, bottom=0.225, top=0.895, wspace=0.20)
    return fig, a1, a2


def finish(fig, name):
    fig.savefig(name + ".pdf")
    fig.savefig(name + ".png", dpi=600)
    plt.close(fig)
    print("saved", name)


# ---------------------------------------------------------------- Fig.2 K-scale
kconv = json.load(open("baseline_sunsal_kscale.json", encoding="utf-8"))
klearn = json.load(open("kscale_v4_results.json", encoding="utf-8"))

Ks = [20, 50, 100, 200, 500, 1000, 1500, 1900]
x = list(range(len(Ks)))


def learned(metric, model):
    return [klearn[str(k)][model]["noise_0.01"][metric] for k in Ks]


fig, a1, a2 = frame()
a1.plot(x, learned("F1", "TSRAM"), "-o", color=C_TSRAM, label="TSRAM-Net (learned)", **STY)
a1.plot(x, learned("F1", "MLP"), "--s", color=C_MLP, label="Dense MLP (learned)", **STY)
a1.plot(x, [kconv[str(k)]["sunsal"]["F1"] for k in Ks], "-^", color=C_SUN,
        label="SUnSAL (convex)", **STY)
a1.plot(x, [kconv[str(k)]["fcls"]["F1"] for k in Ks], "--D", color=C_FCLS,
        label="FCLS (convex)", **STY)
a1.set_xticks(x)
a1.set_xticklabels([str(k) for k in Ks])
a1.set_xlabel("Reference library size $K$", labelpad=1.5)
a1.set_ylabel("Presence-detection F1", labelpad=1.5)
a1.set_title("(a) Detection F1", pad=2.5)
a1.set_ylim(0.70, 1.005)
a1.grid(True, ls=":", lw=0.5, alpha=0.6)
a1.legend(loc="lower left", frameon=True, framealpha=0.92, borderpad=0.3,
          labelspacing=0.22, handlelength=1.5, handletextpad=0.4)

a2.plot(x, learned("cos", "TSRAM"), "-o", color=C_TSRAM, label="TSRAM-Net (learned)", **STY)
a2.plot(x, learned("cos", "MLP"), "--s", color=C_MLP, label="Dense MLP (learned)", **STY)
a2.plot(x, [kconv[str(k)]["sunsal"]["cosine"] for k in Ks], "-^", color=C_SUN,
        label="SUnSAL (convex)", **STY)
a2.plot(x, [kconv[str(k)]["fcls"]["cosine"] for k in Ks], "--D", color=C_FCLS,
        label="FCLS (convex)", **STY)
a2.set_xticks(x)
a2.set_xticklabels([str(k) for k in Ks])
a2.set_xlabel("Reference library size $K$", labelpad=1.5)
a2.set_ylabel("Abundance cosine", labelpad=1.5)
a2.set_title("(b) Abundance cosine", pad=2.5)
a2.set_ylim(0.85, 1.005)
a2.grid(True, ls=":", lw=0.5, alpha=0.6)
a2.legend(loc="lower left", frameon=True, framealpha=0.92, borderpad=0.3,
          labelspacing=0.22, handlelength=1.5, handletextpad=0.4)
finish(fig, "fig_kscale_final")

# ---------------------------------------------------------------- Fig.3 noise
nz = json.load(open("noise_v3_three_methods.json", encoding="utf-8"))
x = list(range(len(nz["std"])))
xl = nz["labels"]

fig, a1, a2 = frame()
a1.plot(x, nz["fcls_f1"], "--D", color=C_FCLS, label="FCLS", **STY)
a1.plot(x, nz["sunsal_f1"], "-^", color=C_SUN, label="SUnSAL", **STY)
a1.plot(x, nz["tsram_f1"], "-o", color=C_TSRAM, label="TSRAM-Net", **STY)
a1.set_xlabel("Gaussian noise level (%)", labelpad=1.5)
a1.set_ylabel("Presence-detection F1", labelpad=1.5)
a1.set_title("(a) Detection F1", pad=2.5)
a1.set_xticks(x)
a1.set_xticklabels(xl)
a1.set_ylim(0.2, 1.02)
a1.grid(True, ls=":", lw=0.5, alpha=0.6)
a1.legend(loc="lower left", frameon=True, framealpha=0.92, borderpad=0.3,
          labelspacing=0.22, handlelength=1.5, handletextpad=0.4)

a2.plot(x, nz["fcls_cos"], "--D", color=C_FCLS, label="FCLS", **STY)
a2.plot(x, nz["sunsal_cos"], "-^", color=C_SUN, label="SUnSAL", **STY)
a2.plot(x, nz["tsram_cos"], "-o", color=C_TSRAM, label="TSRAM-Net", **STY)
a2.set_xlabel("Gaussian noise level (%)", labelpad=1.5)
a2.set_ylabel("Abundance cosine", labelpad=1.5)
a2.set_title("(b) Abundance cosine", pad=2.5)
a2.set_xticks(x)
a2.set_xticklabels(xl)
a2.set_ylim(0.2, 1.02)
a2.grid(True, ls=":", lw=0.5, alpha=0.6)
a2.legend(loc="lower left", frameon=True, framealpha=0.92, borderpad=0.3,
          labelspacing=0.22, handlelength=1.5, handletextpad=0.4)
finish(fig, "fig_noise_final")
