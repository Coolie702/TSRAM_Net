# -*- coding: utf-8 -*-
"""
Follow-up to diag_pres_head.py: three presence heads, one frozen encoder, one protocol.

  A_pooled     the paper's presence branch: [Q, softmax(Q ref^T / Tp) @ ref] -> MLP -> K
  B_retrieval  per-candidate inner product: (Q W) . ref_k
  D_dense_bce  the same MLP shape as A but fed Q only and trained with BCE

A vs D isolates the loss (contrastive vs BCE). A vs B isolates pooled vs per-candidate.
Model selection is uniform: validation F1 at a threshold tuned on the validation split,
so that a head whose logits are offset is not penalised twice.
"""
import os
import io, sys, json, time
import numpy as np
import torch, torch.nn as nn, torch.nn.functional as F, torch.optim as optim
from sklearn.metrics import f1_score

V4 = 'kscale_experiment_v4.py'
CKPT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'checkpoints', '_ckpt_TSRAM_K1000.pt')
K = 1900
MAXEP, PAT, VALEVERY, BATCH, LR = 200, 20, 5, 256, 8e-4


def prelude(path, cutpat):
    lines = io.open(path, encoding='utf-8').read().split('\n')
    cut = next(i for i, l in enumerate(lines) if l.startswith(cutpat))
    ns = {}
    a = sys.argv[:]; sys.argv = [path]
    exec(compile('\n'.join(lines[:cut]), path, 'exec'), ns)
    sys.argv = a
    return ns


print('loading v4 prelude ...', flush=True)
ns = prelude(V4, 'MODELS =')
RALL, gen = ns['RALL'], ns['gen']
MLPEnc, ContrastiveLoss, DIM = ns['MLPEnc'], ns['ContrastiveLoss'], ns['DIM']

ck = torch.load(CKPT, map_location='cpu')
enc = MLPEnc()
enc.load_state_dict({k[len('encoder.'):]: v for k, v in ck.items() if k.startswith('encoder.')})
enc.eval()
for p in enc.parameters():
    p.requires_grad_(False)
Tp = float(torch.exp(ck['log_Tp']))
print('encoder loaded, Tp=%.3f' % Tp, flush=True)


@torch.no_grad()
def feat(X):
    return torch.cat([enc(torch.from_numpy(np.ascontiguousarray(X[j:j + 1024])))
                      for j in range(0, len(X), 1024)])


ref = feat(RALL[:K])
Xtr, yptr, _ = gen(ns['N_TRAIN'], K, 1)
Xva, ypva, _ = gen(ns['N_VAL'], K, 2, aug=False, std=0.01)
Qtr, Qva = feat(Xtr), feat(Xva)
TESTS = []
for ti in range(3):
    Xt, yt, _ = gen(3000, K, 300 + ti, aug=False, std=0.01)
    TESTS.append((feat(Xt), yt))
ytr_t = torch.from_numpy(yptr)
print('features cached  Qtr %s  ref %s' % (tuple(Qtr.shape), tuple(ref.shape)), flush=True)


class Pooled(nn.Module):
    def __init__(s, K, d=DIM):
        super().__init__()
        s.ref, s.Tp = ref, Tp
        s.h = nn.Sequential(nn.Linear(2 * d, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(.3),
                            nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(.2),
                            nn.Linear(256, K))

    def forward(s, q):
        wp = torch.softmax((q @ s.ref.T) / s.Tp, -1) @ s.ref
        return s.h(torch.cat([q, wp], -1))


class Retrieval(nn.Module):
    def __init__(s, ref, d=DIM):
        super().__init__()
        s.ref = ref
        s.W = nn.Linear(d, d, bias=False)
        nn.init.eye_(s.W.weight)
        s.scale = nn.Parameter(torch.tensor(10.0))

    def forward(s, q):
        return (F.normalize(s.W(q), p=2, dim=-1) @ s.ref.T) * s.scale


class DenseBCE(nn.Module):
    def __init__(s, K, d=DIM):
        super().__init__()
        s.h = nn.Sequential(nn.Linear(d, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(.3),
                            nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(.2),
                            nn.Linear(256, K))

    def forward(s, q):
        return s.h(q)


@torch.no_grad()
def probs_of(model, Q):
    model.eval()
    return torch.sigmoid(torch.cat([model(Q[j:j + 1024]) for j in range(0, len(Q), 1024)])).numpy()


def f1_at(prob, y, thr):
    return f1_score(y, prob > thr, average='samples', zero_division=0)


def tune_thr(prob, y, n=3000):
    """Threshold on the validation split; the contrastive loss is shift-invariant, so
    the 0.5 cut is not learned by that objective."""
    p, yy = prob[:n], y[:n]
    flat = p.ravel()
    rs = np.random.RandomState(0)
    idx = rs.choice(len(flat), size=min(2_000_000, len(flat)), replace=False)
    cands = [0.5] + [float(q) for q in np.quantile(flat[idx], np.linspace(0.80, 0.999, 60))]
    best, bt = -1.0, 0.5
    for t in cands:
        v = f1_at(p, yy, t)
        if v > best:
            best, bt = v, t
    return bt


def train(model, tag, kind):
    opt = optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-4)
    sch = optim.lr_scheduler.CosineAnnealingLR(opt, T_max=MAXEP)
    cont, bce = ContrastiveLoss(), nn.BCEWithLogitsLoss()
    best, bs, wait = -1.0, None, 0
    for ep in range(MAXEP):
        model.train()
        perm = torch.randperm(len(Qtr))
        for j in range(0, len(Qtr), BATCH):
            idx = perm[j:j + BATCH]
            if len(idx) < 8:
                continue
            out = model(Qtr[idx])
            loss = cont(out, ytr_t[idx]) if kind == 'contrast' else bce(out, ytr_t[idx])
            opt.zero_grad(); loss.backward(); opt.step()
        sch.step()
        if (ep + 1) % VALEVERY == 0:
            pv = probs_of(model, Qva)
            thr = 0.5 if kind == 'bce' else tune_thr(pv, ypva)
            f1 = f1_at(pv, ypva, thr)
            print('  [%s] ep %3d  valF1 %.4f  thr %.3f  best %.4f  %.0fs'
                  % (tag, ep + 1, f1, thr, best, time.time() - T0), flush=True)
            if f1 > best + 1e-4:
                best, bs, wait = f1, {k: v.clone() for k, v in model.state_dict().items()}, 0
            else:
                wait += 1
                if wait >= PAT // VALEVERY:
                    break
    if bs:
        model.load_state_dict(bs)
    return best


res = {'K': K, 'Tp': Tp, 'val_f1': {}, 'thr': {}, 'test_f1': {}, 'test_f1_sets': {},
       'test_f1_tuned': {}, 'test_f1_tuned_sets': {}}
T0 = time.time()
for name, ctor, kind in [('A_pooled', lambda: Pooled(K), 'contrast'),
                         ('B_retrieval', lambda: Retrieval(ref), 'contrast'),
                         ('D_dense_bce', lambda: DenseBCE(K), 'bce')]:
    t = time.time()
    m = ctor()
    v = train(m, name, kind)
    pv = probs_of(m, Qva)
    thr = 0.5 if kind == 'bce' else tune_thr(pv, ypva)
    fs = [f1_at(probs_of(m, Q), y, 0.5) for Q, y in TESTS]
    fs_t = [f1_at(probs_of(m, Q), y, thr) for Q, y in TESTS]
    res['val_f1'][name] = float(v)
    res['thr'][name] = float(thr)
    res['test_f1'][name] = float(np.mean(fs))
    res['test_f1_sets'][name] = [float(x) for x in fs]
    res['test_f1_tuned'][name] = float(np.mean(fs_t))
    res['test_f1_tuned_sets'][name] = [float(x) for x in fs_t]
    print('%-12s val %.4f | F1@0.5 %.4f | thr %.3f -> %.4f | %s | %.0fs'
          % (name, v, np.mean(fs), thr, np.mean(fs_t), np.round(fs_t, 4), time.time() - t), flush=True)
    torch.save(m.state_dict(), 'diag_%s.pt' % name)

json.dump(res, open('diag_pres_head.json', 'w'), indent=2)
print('saved diag_pres_head.json')
