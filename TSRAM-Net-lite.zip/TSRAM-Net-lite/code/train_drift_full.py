"""
TSRAM-Net 最终主模型（路线 A：方法与代码严格一致）
================================================================================
相对原 train_mlp_50k.py 的改动（最小且经过对照实验验证，见 sparsemax_fix_ablation.json）：
  1. sparsemax 改为 Martins & Astudillo (2016) 标准实现（去掉错误的 tau.clamp(min=0)）；
  2. 最终丰度 ab 也用 sparsemax（精确零权重，天然稀疏到真实端元数）；
  3. 温度保持【自由可学习】（Tp/Ta/ss 均为 nn.Parameter，不做手工退火）；
其余与原主模型完全一致：对比损失(T=0.4) + 丰度MSE、固定阈值0.5、50k样本、600 epoch、
batch 256、AdamW(lr=8e-4,wd=1e-4)、cosine LR、每 epoch 刷新参考库记忆矩阵。
训练后在 5 个独立测试集评估 F1/P/R/cosine（均值±std），并统计 support set 与延迟。
"""
import os, sys, json, time
import numpy as np
from collections import Counter, defaultdict
from scipy.interpolate import interp1d
from scipy.signal import savgol_filter
import torch, torch.nn as nn, torch.nn.functional as F, torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import f1_score, precision_score, recall_score
import warnings; warnings.filterwarnings('ignore')

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'rruff')
# ---- 漂移增强全量对照：base / aug 两个变体，唯一差别是训练时是否做波数轴扰动 ----
MODE = (sys.argv[1] if len(sys.argv) > 1 else 'base').lower()
assert MODE in ('base', 'aug'), MODE
USE_DRIFT_AUG = (MODE == 'aug')
OUT_PREFIX = f'drift600_{MODE}'
SEED = 42
np.random.seed(SEED); torch.manual_seed(SEED)
NWP, WMIN, WMAX, DIM, K = 1024, 100.0, 1500.0, 1024, 1000
CWN = np.linspace(WMIN, WMAX, NWP)
N_EPOCHS, BATCH_SIZE, N_TRAIN, N_VAL, LR = 600, 256, 50000, 10000, 8e-4
N_TEST = 5000
if os.environ.get('SMOKE'):
    N_EPOCHS, N_TRAIN, N_VAL, N_TEST = 2, 3000, 600, 400
DEV = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'Device {DEV} | TSRAM-Net FINAL v2 (standard sparsemax + random noise augmentation) | K={K} | {N_EPOCHS}ep | {N_TRAIN} samples', flush=True)

# ---------- 数据 ----------
def parse_raman(fp):
    name, lines = None, []
    with open(fp,'r',encoding='utf-8',errors='ignore') as f:
        for line in f:
            line=line.strip()
            if line.startswith('##NAMES='): name=line.split('=',1)[1].strip()
            elif line and not line.startswith('#'): lines.append(line)
    if name is None or not lines: return None
    wn,it=[],[]
    for l in lines:
        p=l.split(',')
        if len(p)>=2:
            try: wn.append(float(p[0])); it.append(float(p[1]))
            except: pass
    if len(wn)<50: return None
    return name,np.array(wn,np.float32),np.array(it,np.float32)
def interp_spec(wn,it):
    m=(wn>=WMIN-50)&(wn<=WMAX+50)
    if m.sum()<20: return None
    wn,it=wn[m],it[m]; o=np.argsort(wn); wn,it=wn[o],it[o]
    uw,idx=np.unique(wn,return_inverse=True)
    ui=np.array([it[idx==i].mean() for i in range(len(uw))])
    if len(uw)<20: return None
    try:
        f=interp1d(uw,ui,kind='linear',bounds_error=False,fill_value=0.0); s=f(CWN)
        wl=min(15,len(s)//10); wl+=(wl%2==0)
        if wl>=5: s=savgol_filter(s,wl,2)
        lo,hi=s.min(),s.max()
        if hi-lo<1e-8: return None
        return ((s-lo)/(hi-lo)).astype(np.float32)
    except: return None
print('[1/4] building library...',flush=True)
ms=defaultdict(list)
for fn in os.listdir(DATA_DIR):
    if fn.endswith('.txt') and 'Processed' in fn:
        r=parse_raman(os.path.join(DATA_DIR,fn))
        if r:
            nm,wn,it=r; s=interp_spec(wn,it)
            if s is not None: ms[nm].append(s)
topK=[m for m,_ in Counter({m:len(v) for m,v in ms.items()}).most_common(K)]
R=np.zeros((K,NWP),np.float32)
for i,m in enumerate(topK):
    sp=np.array(ms[m]); ref=np.median(sp,0) if len(sp)>1 else sp[0]
    lo,hi=ref.min(),ref.max(); R[i]=((ref-lo)/(hi-lo+1e-12)).astype(np.float32) if hi-lo>1e-8 else ref
print(f'  library {R.shape}',flush=True)

# ---------- 标准 sparsemax（Martins & Astudillo 2016，不 clamp tau） ----------
def sparsemax(z,dim=-1):
    if dim<0: dim=z.ndim+dim
    z=z-z.max(dim=dim,keepdim=True)[0]
    zs,_=torch.sort(z,dim=dim,descending=True); zc=torch.cumsum(zs,dim=dim)
    k=torch.arange(1,z.shape[dim]+1,device=z.device,dtype=z.dtype).view(*[1 if i!=dim else -1 for i in range(z.ndim)])
    km=(1+k*zs>zc).float().sum(dim=dim,keepdim=True).long()-1; km=km.clamp(min=0)
    tau=(zc.gather(dim,km)-1)/(km.float()+1)          # 阈值可为负，禁止 clamp(min=0)
    return (z-tau).clamp(min=0)

class Enc(nn.Module):
    def __init__(s):
        super().__init__()
        s.fc1=nn.Linear(NWP,DIM); s.bn1=nn.BatchNorm1d(DIM)
        s.fc2=nn.Linear(DIM,DIM); s.bn2=nn.BatchNorm1d(DIM); s.fc3=nn.Linear(DIM,DIM)
    def forward(s,x):
        h=F.relu(s.bn1(s.fc1(x))); h=F.relu(s.bn2(s.fc2(h)))+h; h=s.fc3(h)+h
        return F.normalize(h,p=2,dim=-1)
class TSRAMNet(nn.Module):
    def __init__(s,n=K,dim=DIM):
        super().__init__(); s.n=n
        s.encoder=Enc()
        s.register_buffer('ref_feat',torch.zeros(n,dim))
        s.log_Tp=nn.Parameter(torch.tensor(np.log(4.0)))
        s.pres_head=nn.Sequential(nn.Linear(dim*2,512),nn.BatchNorm1d(512),nn.ReLU(),nn.Dropout(.3),
            nn.Linear(512,256),nn.BatchNorm1d(256),nn.ReLU(),nn.Dropout(.2),nn.Linear(256,n))
        s.log_Ta=nn.Parameter(torch.tensor(np.log(3.0)))
        s.log_ss=nn.Parameter(torch.tensor(np.log(5.0)))
        s.refiner=nn.Sequential(nn.Linear(dim*3,dim),nn.BatchNorm1d(dim),nn.ReLU(),nn.Dropout(.2),
            nn.Linear(dim,dim//2),nn.BatchNorm1d(dim//2),nn.ReLU(),nn.Dropout(.1),nn.Linear(dim//2,n))
    @torch.no_grad()
    def update_ref(s,ref):
        s.eval()
        for i in range(0,s.n,512): s.ref_feat[i:i+512]=s.encoder(ref[i:i+512].to(s.ref_feat.device))
        s.train()
    def forward(s,x):
        Q=s.encoder(x); sim=Q@s.ref_feat.T
        Tp=torch.exp(s.log_Tp).clamp(min=.1); Ta=torch.exp(s.log_Ta).clamp(min=.1); ss=torch.exp(s.log_ss)
        Ap=F.softmax(sim/Tp,-1); wp=Ap@s.ref_feat
        pl=s.pres_head(torch.cat([Q,wp],-1))
        Ai=sparsemax(sim/Ta,-1); wi=Ai@s.ref_feat                      # 粗检索（精确零）
        al=s.refiner(torch.cat([Q,wi,Q-wi],-1)); comb=sim*ss+al
        ab=sparsemax(comb/Ta,-1)                                        # 丰度：精确零稀疏输出
        return pl,ab,Ap,Ai

def gen(n,seed0=0,aug=True,std=0.01):
    # aug=True : 随机噪声增强——约15%干净样本 + 85%噪声std~Uniform(0.002,0.05)，
    #            使BatchNorm统计覆盖 干净→中噪 区间，保证0%真干净输入也能正确推理；
    # aug=False: 固定噪声std（标准测试条件，std=0.01对应训练基准、std=0为真干净）。
    rng=np.random.RandomState(seed0)
    X=np.zeros((n,NWP),np.float32); yp=np.zeros((n,K),np.float32); ya=np.zeros((n,K),np.float32)
    for i in range(n):
        nc=rng.randint(1,3); ch=rng.choice(K,nc,replace=False); ra=rng.dirichlet(np.ones(nc)).astype(np.float32)
        if aug:
            u=rng.rand(); sigma=0.0 if u<0.15 else 0.002+(u-0.15)/0.85*0.048
        else:
            sigma=std
        noise=rng.normal(0,sigma,NWP).astype(np.float32) if sigma>0 else 0.0
        m=(R[ch]*ra[:,None]).sum(0)+noise
        lo,hi=m.min(),m.max(); m=(m-lo)/(hi-lo+1e-12); X[i]=m; yp[i,ch]=1; ya[i,ch]=ra
    return X,yp,ya

# ---------- 波数轴漂移增强（仅 aug 变体使用） ----------
# 动机：实测同矿物 532nm 不同样品对之间的峰位错位 median 1.37 / p75 2.75 / p90 5.49 cm-1，
# 1 bin = (1500-100)/1023 = 1.3685 cm-1。
# 设计：不再用固定 ±4 bins 全量扰动（实测会压垮干净性能），改为
#   (a) 只扰动一半样本，另一半保持干净，保证干净分布仍被覆盖；
#   (b) 平移量直接从 1143 对实测分布里抽，训练分布与实际部署失配一致；
#   (c) 拉伸收窄到 ±0.25%。
# 增强只作用于混合谱，库保持干净——对应"库正确、仪器轴失准"的真实情形。
def _renorm(X):
    lo = X.min(1, keepdims=True); hi = X.max(1, keepdims=True)
    return ((X - lo) / (hi - lo + 1e-12)).astype(np.float32)

def shift_bins(X, bins):
    out = np.zeros_like(X)
    for b in np.unique(bins):
        sel = np.where(bins == b)[0]
        blk = np.roll(X[sel], int(b), axis=1)
        if b > 0:   blk[:, :int(b)] = 0.0
        elif b < 0: blk[:, int(b):] = 0.0
        out[sel] = blk
    return _renorm(out)

def stretch_axis(X, eps):
    out = np.zeros_like(X)
    for e in np.unique(eps):
        sel = eps == e
        pos = np.clip((CWN / (1.0 + e) - WMIN) / (WMAX - WMIN) * (NWP - 1), 0, NWP - 1)
        i0 = np.floor(pos).astype(int); i1 = np.minimum(i0 + 1, NWP - 1)
        w = (pos - i0).astype(np.float32)
        out[sel] = X[sel][:, i0] * (1 - w) + X[sel][:, i1] * w
    return _renorm(out)

_EMP = np.abs(np.load('_scratch/empirical_shift_cm.npy'))
_BIN = float(CWN[1] - CWN[0])

def drift_augment(X, rng):
    """按实测漂移分布扰动一半训练混合谱。
    平移量从 1143 对同矿物实测偏移分布中抽取（随机正负号，取整到 bin），
    拉伸 ±0.25%。只作用于混合谱，库保持干净，符合"库正确、仪器失准"的物理情形。"""
    n = len(X)
    bins = np.zeros(n, np.int64)
    sel = rng.rand(n) < 0.5
    k = int(sel.sum())
    if k:
        d = _EMP[rng.randint(0, len(_EMP), k)]
        bins[sel] = np.round(d / _BIN).astype(np.int64) * rng.choice([-1, 1], k)
    eps = np.zeros(n)
    se = rng.rand(n) < 0.5
    if se.any():
        eps[se] = rng.choice([-0.0025, 0.0, 0.0025], int(se.sum()))
    return stretch_axis(shift_bins(X, bins), eps)

class ContrastiveLoss(nn.Module):
    def __init__(s,T=.4): super().__init__(); s.T=T
    def forward(s,lo,t):
        z=lo-lo.max(-1,keepdim=True)[0].detach(); e=torch.exp(z/s.T); Z=e.sum(-1,keepdim=True).clamp(min=1e-8)
        lp=z/s.T-torch.log(Z); npos=t.sum(-1).clamp(min=1)
        return (-(t*lp).sum(-1)/npos).mean()

print('[2/4] model + data...',flush=True)
model=TSRAMNet().to(DEV)
print(f'  params {sum(p.numel() for p in model.parameters()):,}',flush=True)
ref_t=torch.from_numpy(R).to(DEV)
Xtr,yptr,yatr=gen(N_TRAIN,1); Xva,ypva,_=gen(N_VAL,2)
Xtr_t=torch.from_numpy(Xtr)
tr=DataLoader(TensorDataset(Xtr_t,torch.from_numpy(yptr),torch.from_numpy(yatr)),batch_size=BATCH_SIZE,shuffle=True)
aug_rng=np.random.RandomState(SEED)
va=DataLoader(TensorDataset(torch.from_numpy(Xva),torch.from_numpy(ypva)),batch_size=BATCH_SIZE)
crit=ContrastiveLoss(); opt=optim.AdamW(model.parameters(),lr=LR,weight_decay=1e-4)
sch=optim.lr_scheduler.CosineAnnealingLR(opt,T_max=N_EPOCHS)

print(f'[3/4] training {N_EPOCHS} epochs... mode={MODE} drift_aug={USE_DRIFT_AUG}',flush=True)
best=0; t0=time.time()
for ep in range(N_EPOCHS):
    if USE_DRIFT_AUG:
        Xtr_t.copy_(torch.from_numpy(drift_augment(Xtr, aug_rng)))
    model.update_ref(ref_t); model.train(); tot=0; nb=0
    for xb,pb,ab_ in tr:
        xb,pb,ab_=xb.to(DEV),pb.to(DEV),ab_.to(DEV)
        pl,ab,_,_=model(xb); loss=crit(pl,pb)+F.mse_loss(ab,ab_)
        opt.zero_grad(); loss.backward(); opt.step(); tot+=loss.item(); nb+=1
    sch.step()
    if (ep+1)%10==0 or ep==N_EPOCHS-1:
        model.eval(); P=[]
        with torch.no_grad():
            for xb,pb in va:
                pl,_,_,_=model(xb.to(DEV)); P.append((torch.sigmoid(pl)>.5).float().cpu().numpy())
        f=f1_score(ypva,np.concatenate(P),average='samples',zero_division=0)
        if f>best: best=f; torch.save(model.state_dict(),f'{OUT_PREFIX}_best_model.pth')
        Tp=float(torch.exp(model.log_Tp)); Ta=float(torch.exp(model.log_Ta))
        print(f'  ep{ep+1:3d}/{N_EPOCHS} loss{tot/nb:.4f} valF1 {f:.4f}(best {best:.4f}) Tp{Tp:.1f} Ta{Ta:.2f} {((time.time()-t0)/60):.1f}min',flush=True)

# ---------- 5 测试集评估 ----------
print('[4/4] 5-test-set evaluation...',flush=True)
model.load_state_dict(torch.load(f'{OUT_PREFIX}_best_model.pth',map_location=DEV)); model.update_ref(ref_t); model.eval()
rows=[]; sup=None
for ts_i in range(5):
    Xt,ypt,yat=gen(N_TEST,100+ts_i,aug=False,std=0.01)
    P=[];AB=[];AI=[];AP=[]
    with torch.no_grad():
        for j in range(0,len(Xt),512):
            xb=torch.from_numpy(Xt[j:j+512]).to(DEV)
            pl,ab,ap,ai=model(xb)
            P.append((torch.sigmoid(pl)>.5).float().cpu().numpy()); AB.append(ab.cpu().numpy())
            AI.append((ai>0).sum(-1).cpu().numpy()); AP.append((ap>1.0/K).sum(-1).cpu().numpy())
    P,AB,AI,AP=np.concatenate(P),np.concatenate(AB),np.concatenate(AI),np.concatenate(AP)
    f1=f1_score(ypt,P,average='samples',zero_division=0)
    pr=precision_score(ypt,P,average='samples',zero_division=0); rc=recall_score(ypt,P,average='samples',zero_division=0)
    cos=float(((AB*yat).sum(1)/np.maximum(np.linalg.norm(AB,axis=1)*np.linalg.norm(yat,axis=1),1e-10)).mean())
    rows.append(dict(F1=f1,P=pr,R=rc,cosine=cos))
    if ts_i==0:
        sup={'Ai_init_nonzero':round(float(AI.mean()),1),'final_abundance_nonzero':round(float((AB>1e-4).sum(1).mean()),1),
             'Ap_gt_uniform':round(float(AP.mean()),1)}
# ---------- 漂移鲁棒性评估（与主测试集同分布，seed 100 复现） ----------
print('[4b/4] drift robustness evaluation...',flush=True)
Xd,ypd,yad=gen(N_TEST,100,aug=False,std=0.01)
DRIFT_CONDS=[('clean',Xd),
             ('shift+2',shift_bins(Xd,np.full(len(Xd),2))),
             ('shift+3',shift_bins(Xd,np.full(len(Xd),3))),
             ('shift+5',shift_bins(Xd,np.full(len(Xd),5))),
             ('stretch0.5%',stretch_axis(Xd,np.full(len(Xd),0.005))),
             ('stretch1%',stretch_axis(Xd,np.full(len(Xd),0.010)))]
drift_res={}
for name,Xc in DRIFT_CONDS:
    P=[];AB=[]
    with torch.no_grad():
        for j in range(0,len(Xc),512):
            pl,ab,_,_=model(torch.from_numpy(Xc[j:j+512]).to(DEV))
            P.append((torch.sigmoid(pl)>.5).float().cpu().numpy()); AB.append(ab.cpu().numpy())
    P,AB=np.concatenate(P),np.concatenate(AB)
    f1d=f1_score(ypd,P,average='samples',zero_division=0)
    cosd=float(((AB*yad).sum(1)/np.maximum(np.linalg.norm(AB,axis=1)*np.linalg.norm(yad,axis=1),1e-10)).mean())
    drift_res[name]={'F1':round(float(f1d),4),'cosine':round(float(cosd),4)}
    print(f'  {name:<12s} F1 {f1d:.4f}  cos {cosd:.4f}',flush=True)

# 延迟
x=torch.randn(1,NWP,device=DEV)
with torch.no_grad():
    for _ in range(20): model(x)
if DEV.type=='cuda': torch.cuda.synchronize()
t=time.time()
with torch.no_grad():
    for _ in range(100): model(x)
if DEV.type=='cuda': torch.cuda.synchronize()
lat=(time.time()-t)/100*1000
res={'model':OUT_PREFIX,'mode':MODE,'drift_aug':USE_DRIFT_AUG,'K':K,'n_train':N_TRAIN,'epochs':N_EPOCHS,'best_val_f1':round(best,4),
     'F1_mean':round(float(np.mean([r['F1'] for r in rows])),4),'F1_std':round(float(np.std([r['F1'] for r in rows])),4),
     'P_mean':round(float(np.mean([r['P'] for r in rows])),4),'R_mean':round(float(np.mean([r['R'] for r in rows])),4),
     'cosine_mean':round(float(np.mean([r['cosine'] for r in rows])),4),
     'per_test':[{k:round(v,4) for k,v in r.items()} for r in rows],
     'learned_Tp':round(float(torch.exp(model.log_Tp)),2),'learned_Ta':round(float(torch.exp(model.log_Ta)),3),
     'learned_ss':round(float(torch.exp(model.log_ss)),2),'support':sup,'latency_ms':round(lat,3),
     'drift':drift_res,
     'train_minutes':round((time.time()-t0)/60,1)}
json.dump(res,open(f'{OUT_PREFIX}_results.json','w'),indent=2)
print('\n==== FINAL ====',flush=True)
print(json.dumps(res,indent=2),flush=True)
print(f'SAVED {OUT_PREFIX}_best_model.pth / {OUT_PREFIX}_results.json',flush=True)
