"""
K 缩放实验 v4（Table 3 / Fig. 2 主口径）—— 充分训练 + 验证早停，与主结果同口径
================================================================================
v3 固定 20k/300ep 预算下检索模型欠训（TSRAM K=1000 仅 ~0.75，而充分训练为 0.882），
dense MLP 在短预算下已收敛，造成整条曲线 MLP 领先、与主结果矛盾。v4 改为与主模型一致
的充分训练口径，让每个模型在每个 K 都训练到自身收敛后再比较：
  - 50,000 训练 / 10,000 验证、AdamW 8e-4、cosine 上限 600 epoch、batch256
  - 与 v2 相同的随机噪声增强（15% 干净，否则 sigma~U(0.002,0.05)）
  - 每 5 epoch 在固定 1%-噪声验证集上算 presence F1，patience=12(=60ep) 早停，保存最佳
三模型（与 Baselines 节严格对应）：
  TSRAM       : 残差 MLP 编码器 + 双流检索（标准两级 Sparsemax + refiner + 可学习温度）
  MLP         : 同残差 MLP 编码器 + dense K-way sigmoid(BCE) + softmax 丰度(MSE)，无检索
  Transformer : Transformer patch 编码器 + 与 TSRAM 完全相同的双流检索头（仅换编码器）
每个 K 在 干净(0%) 与 1% 噪声、各 3 测试集(3000) 评估 F1/P/R/cosine，
输出 kscale_v4_results.json + kscale_v4_scaling.png。
"""
import os, sys, json, time, copy, warnings
import numpy as np
from collections import Counter, defaultdict
from scipy.interpolate import interp1d
from scipy.signal import savgol_filter
import torch, torch.nn as nn, torch.nn.functional as F, torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import f1_score
warnings.filterwarnings('ignore')

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'rruff')
NWP, WMIN, WMAX, DIM, KMAX = 1024, 100.0, 1500.0, 1024, 1900
CWN = np.linspace(WMIN, WMAX, NWP)
KS = [int(x) for x in sys.argv[1:]] if len(sys.argv) > 1 else [20, 50, 100, 200, 500, 1000]
RES_PATH = 'kscale_v4_results.json'
MAX_EP, BATCH, N_TRAIN, N_VAL, LR = 600, 256, 50000, 10000, 8e-4
PATIENCE, VAL_EVERY = 12, 5          # 每 5 epoch 验证，连续 12 次(=60ep)无提升则停
DEV = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'Device {DEV} | k-scaling v4 (full-training + early-stop) | up to {MAX_EP}ep | {N_TRAIN} samples | K={KS}', flush=True)


def parse_raman(fp):
    name, lines = None, []
    with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if line.startswith('##NAMES='): name = line.split('=', 1)[1].strip()
            elif line and not line.startswith('#'): lines.append(line)
    if name is None or not lines: return None
    wn, it = [], []
    for l in lines:
        p = l.split(',')
        if len(p) >= 2:
            try: wn.append(float(p[0])); it.append(float(p[1]))
            except Exception: pass
    if len(wn) < 50: return None
    return name, np.array(wn, np.float32), np.array(it, np.float32)


def interp_spec(wn, it):
    m = (wn >= WMIN-50) & (wn <= WMAX+50)
    if m.sum() < 20: return None
    wn, it = wn[m], it[m]; o = np.argsort(wn); wn, it = wn[o], it[o]
    uw, idx = np.unique(wn, return_inverse=True)
    ui = np.array([it[idx == i].mean() for i in range(len(uw))])
    if len(uw) < 20: return None
    f = interp1d(uw, ui, kind='linear', bounds_error=False, fill_value=0.0); s = f(CWN)
    wl = min(15, len(s)//10); wl += (wl % 2 == 0)
    if wl >= 5: s = savgol_filter(s, wl, 2)
    lo, hi = s.min(), s.max()
    return None if hi-lo < 1e-8 else ((s-lo)/(hi-lo)).astype(np.float32)


print('building library...', flush=True)
ms = defaultdict(list)
for fn in os.listdir(DATA_DIR):
    if fn.endswith('.txt') and 'Processed' in fn:
        r = parse_raman(os.path.join(DATA_DIR, fn))
        if r:
            nm, wn, it = r; s = interp_spec(wn, it)
            if s is not None: ms[nm].append(s)
topK = [m for m, _ in Counter({m: len(v) for m, v in ms.items()}).most_common(KMAX)]
RALL = np.zeros((KMAX, NWP), np.float32)
for i, m in enumerate(topK):
    sp = np.array(ms[m]); ref = np.median(sp, 0) if len(sp) > 1 else sp[0]
    lo, hi = ref.min(), ref.max()
    RALL[i] = ((ref-lo)/(hi-lo+1e-12)).astype(np.float32) if hi-lo > 1e-8 else ref


def sparsemax(z, dim=-1):
    if dim < 0: dim = z.ndim + dim
    z = z - z.max(dim=dim, keepdim=True)[0]
    zs, _ = torch.sort(z, dim=dim, descending=True); zc = torch.cumsum(zs, dim=dim)
    k = torch.arange(1, z.shape[dim]+1, device=z.device, dtype=z.dtype).view(
        *[1 if i != dim else -1 for i in range(z.ndim)])
    km = (1+k*zs > zc).float().sum(dim=dim, keepdim=True).long() - 1
    km = km.clamp(min=0)
    return (z - ((zc.gather(dim, km)-1)/(km.float()+1))).clamp(min=0)


class MLPEnc(nn.Module):
    def __init__(s):
        super().__init__()
        s.fc1 = nn.Linear(NWP, DIM); s.bn1 = nn.BatchNorm1d(DIM)
        s.fc2 = nn.Linear(DIM, DIM); s.bn2 = nn.BatchNorm1d(DIM); s.fc3 = nn.Linear(DIM, DIM)
    def forward(s, x):
        h = F.relu(s.bn1(s.fc1(x))); h = F.relu(s.bn2(s.fc2(h))) + h; h = s.fc3(h) + h
        return F.normalize(h, p=2, dim=-1)


class TransformerEnc(nn.Module):
    def __init__(s, n_patches=32, d_model=256, nhead=4, nlayers=3):
        super().__init__()
        s.ps = NWP // n_patches; s.np = n_patches
        s.patch = nn.Linear(s.ps, d_model)
        s.pos = nn.Parameter(torch.randn(1, n_patches, d_model)*0.02)
        layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=nhead, dim_feedforward=512,
                                           dropout=0.1, batch_first=True, activation='gelu')
        s.tr = nn.TransformerEncoder(layer, num_layers=nlayers)
        s.proj = nn.Linear(d_model, DIM)
    def forward(s, x):
        B = x.shape[0]
        p = x.view(B, s.np, s.ps); h = s.patch(p) + s.pos
        h = s.tr(h).mean(dim=1); h = s.proj(h)
        return F.normalize(h, p=2, dim=-1)


class RetrievalNet(nn.Module):
    def __init__(s, K, encoder):
        super().__init__(); s.K = K; s.encoder = encoder
        s.register_buffer('ref_feat', torch.zeros(K, DIM))
        s.log_Tp = nn.Parameter(torch.tensor(np.log(4.0)))
        s.pres_head = nn.Sequential(nn.Linear(DIM*2, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(.3),
            nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(.2), nn.Linear(256, K))
        s.log_Ta = nn.Parameter(torch.tensor(np.log(3.0))); s.log_ss = nn.Parameter(torch.tensor(np.log(5.0)))
        s.refiner = nn.Sequential(nn.Linear(DIM*3, DIM), nn.BatchNorm1d(DIM), nn.ReLU(), nn.Dropout(.2),
            nn.Linear(DIM, DIM//2), nn.BatchNorm1d(DIM//2), nn.ReLU(), nn.Dropout(.1), nn.Linear(DIM//2, K))
    @torch.no_grad()
    def update_ref(s, ref):
        s.eval()
        for i in range(0, s.K, 512):
            s.ref_feat[i:i+512] = s.encoder(ref[i:i+512].to(s.ref_feat.device))
    def forward(s, x):
        Q = s.encoder(x); sim = Q @ s.ref_feat.T
        Tp = torch.exp(s.log_Tp).clamp(min=.1); Ta = torch.exp(s.log_Ta).clamp(min=.1); ss = torch.exp(s.log_ss)
        Ap = F.softmax(sim/Tp, -1); wp = Ap @ s.ref_feat
        pl = s.pres_head(torch.cat([Q, wp], -1))
        Ai = sparsemax(sim/Ta, -1); wi = Ai @ s.ref_feat
        al = s.refiner(torch.cat([Q, wi, Q-wi], -1)); comb = sim*ss + al
        ab = sparsemax(comb/Ta, -1)
        return pl, ab


class MLPDense(nn.Module):
    def __init__(s, K):
        super().__init__(); s.encoder = MLPEnc()
        s.pres_head = nn.Sequential(nn.Linear(256, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(.2),
            nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Linear(256, K))
        s.abun_head = nn.Linear(256, K)
        s._bridge = nn.Sequential(nn.Linear(DIM, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(.2),
            nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU())
    def forward(s, x):
        h = s._bridge(s.encoder(x))
        return s.pres_head(h), F.softmax(s.abun_head(h), -1)


def gen(n, K, seed0, aug=True, std=0.01):
    rng = np.random.RandomState(seed0)
    R = RALL[:K]
    X = np.zeros((n, NWP), np.float32); yp = np.zeros((n, K), np.float32); ya = np.zeros((n, K), np.float32)
    for i in range(n):
        nc = rng.randint(1, 3); ch = rng.choice(K, nc, replace=False)
        ra = rng.dirichlet(np.ones(nc)).astype(np.float32)
        if aug:
            u = rng.rand(); sigma = 0.0 if u < 0.15 else 0.002 + (u-0.15)/0.85*0.048
        else: sigma = std
        noise = rng.normal(0, sigma, NWP).astype(np.float32) if sigma > 0 else 0.0
        m = (R[ch]*ra[:, None]).sum(0) + noise
        lo, hi = m.min(), m.max(); m = (m-lo)/(hi-lo+1e-12)
        X[i] = m; yp[i, ch] = 1; ya[i, ch] = ra
    return X, yp, ya


class ContrastiveLoss(nn.Module):
    def __init__(s, T=.4): super().__init__(); s.T = T
    def forward(s, lo, t):
        z = lo-lo.max(-1, keepdim=True)[0].detach(); e = torch.exp(z/s.T)
        Z = e.sum(-1, keepdim=True).clamp(min=1e-8); lp = z/s.T - torch.log(Z)
        npos = t.sum(-1).clamp(min=1)
        return (-(t*lp).sum(-1)/npos).mean()


def make_model(name, K):
    if name == 'TSRAM': return RetrievalNet(K, MLPEnc()), 'contrast'
    if name == 'MLP': return MLPDense(K), 'bce'
    if name == 'Transformer': return RetrievalNet(K, TransformerEnc()), 'contrast'
    raise ValueError(name)


@torch.no_grad()
def val_f1(model, Xv, yv):
    model.eval(); P = []
    for j in range(0, len(Xv), 512):
        pl, _ = model(torch.from_numpy(Xv[j:j+512]).to(DEV))
        P.append((torch.sigmoid(pl) > .5).float().cpu().numpy())
    P = np.concatenate(P)
    return f1_score(yv, P, average='samples', zero_division=0)


def evaluate(model, K):
    model.eval(); out = {}
    for noise in [0.0, 0.01]:
        fs, ps, rs, cs = [], [], [], []
        for ti in range(3):
            Xt, yt, yat = gen(3000, K, 300+ti, aug=False, std=noise)
            P, AB = [], []
            with torch.no_grad():
                for j in range(0, len(Xt), 512):
                    pl, ab = model(torch.from_numpy(Xt[j:j+512]).to(DEV))
                    P.append((torch.sigmoid(pl) > .5).float().cpu().numpy()); AB.append(ab.cpu().numpy())
            P = np.concatenate(P); AB = np.concatenate(AB)
            fs.append(f1_score(yt, P, average='samples', zero_division=0))
            from sklearn.metrics import precision_score, recall_score
            ps.append(precision_score(yt, P, average='samples', zero_division=0))
            rs.append(recall_score(yt, P, average='samples', zero_division=0))
            cs.append(float(((AB*yat).sum(1)/np.maximum(np.linalg.norm(AB, axis=1)*np.linalg.norm(yat, axis=1), 1e-10)).mean()))
        out[f'noise_{noise:g}'] = {'F1': round(float(np.mean(fs)), 4), 'P': round(float(np.mean(ps)), 4),
                                   'R': round(float(np.mean(rs)), 4), 'cos': round(float(np.mean(cs)), 4)}
    return out


# 新增大库点 K=1500/1900 只跑 TSRAM vs MLP（Transformer 大K更差，已知，不补）
MODELS = ['TSRAM', 'MLP']
results = {}
if os.path.exists(RES_PATH):
    try:
        results = json.load(open(RES_PATH)); print(f'resume: loaded {RES_PATH}', flush=True)
    except Exception:
        results = {}
for K in KS:
    results.setdefault(str(K), {})
    todo = [n for n in MODELS if n not in results[str(K)]]
    if not todo:
        print(f'\n===== K={K} already complete, skip =====', flush=True); continue
    ref_t = torch.from_numpy(RALL[:K]).to(DEV)
    Xtr, yptr, yatr = gen(N_TRAIN, K, 1)
    Xva, ypva, _ = gen(N_VAL, K, 2, aug=False, std=0.01)     # 固定 1%-噪声验证集用于早停
    tr = DataLoader(TensorDataset(torch.from_numpy(Xtr), torch.from_numpy(yptr), torch.from_numpy(yatr)),
                    batch_size=BATCH, shuffle=True)
    for name in MODELS:
        if name in results[str(K)]:
            print(f'\n===== K={K}  {name} already done, skip =====', flush=True); continue
        print(f'\n===== K={K}  {name} =====', flush=True)
        torch.manual_seed(42); np.random.seed(42)
        model, kind = make_model(name, K); model.to(DEV)
        if hasattr(model, 'update_ref'): model.update_ref(ref_t)
        cont = ContrastiveLoss(); bce = nn.BCEWithLogitsLoss()
        opt = optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-4)
        sch = optim.lr_scheduler.CosineAnnealingLR(opt, T_max=MAX_EP)
        best_f1, best_state, wait, best_ep = -1.0, None, 0, 0
        t0 = time.time()
        for ep in range(MAX_EP):
            if hasattr(model, 'update_ref'): model.update_ref(ref_t)
            model.train()
            for xb, pb, ab_ in tr:
                xb, pb, ab_ = xb.to(DEV), pb.to(DEV), ab_.to(DEV)
                pl, ab = model(xb)
                loss = (cont(pl, pb) + F.mse_loss(ab, ab_)) if kind == 'contrast' else (bce(pl, pb) + F.mse_loss(ab, ab_))
                opt.zero_grad(); loss.backward(); opt.step()
            sch.step()
            if (ep+1) % VAL_EVERY == 0:
                if hasattr(model, 'update_ref'): model.update_ref(ref_t)
                f1v = val_f1(model, Xva, ypva)
                if f1v > best_f1 + 1e-4:
                    best_f1, wait, best_ep = f1v, 0, ep+1
                    best_state = {kk: vv.detach().cpu().clone() for kk, vv in model.state_dict().items()}
                else:
                    wait += 1
                print(f'  ep{ep+1:3d} valF1 {f1v:.4f} best {best_f1:.4f}@{best_ep} wait {wait}/{PATIENCE} {(time.time()-t0)/60:.1f}min', flush=True)
                if wait >= PATIENCE:
                    print(f'  early stop at ep{ep+1}', flush=True); break
        if best_state is not None:
            model.load_state_dict(best_state)
        if hasattr(model, 'update_ref'): model.update_ref(ref_t)
        metrics = evaluate(model, K)
        metrics['best_epoch'] = best_ep; metrics['train_min'] = round((time.time()-t0)/60, 1)
        results[str(K)][name] = metrics
        print(f"  -> best ep{best_ep} | clean F1 {metrics['noise_0']['F1']:.4f} | 1% F1 {metrics['noise_0.01']['F1']:.4f} | cos {metrics['noise_0.01']['cos']:.4f}", flush=True)
        json.dump(results, open('kscale_v4_results.json', 'w'), indent=2)

import matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
ALL_KS = [20, 50, 100, 200, 500, 1000, 1500, 1900]
complete = all(n in results.get(str(K), {}) for K in ALL_KS for n in MODELS)
if complete:
    plt.figure(figsize=(7, 5))
    for name, marker, color in [('TSRAM', 'o', '#C62828'), ('MLP', 's', '#1565C0'), ('Transformer', '^', '#2E7D32')]:
        xs, ys = [], []
        for K in ALL_KS:
            d = results.get(str(K), {}).get(name)
            if d is not None:
                xs.append(K); ys.append(d['noise_0.01']['F1'])
        plt.plot(xs, ys, marker=marker, label=name, color=color, linewidth=2)
    plt.xscale('log'); plt.xlabel('Library size $K$'); plt.ylabel('F1 score (1% noise)')
    plt.grid(alpha=.3); plt.legend(); plt.tight_layout()
    plt.savefig('kscale_v4_scaling.png', dpi=200)
    print('\nSAVED kscale_v4_results.json + kscale_v4_scaling.png', flush=True)
else:
    done = [(K, n) for K in ALL_KS for n in MODELS if n in results.get(str(K), {})]
    print(f'\nINCOMPLETE ({len(done)}/{len(ALL_KS)*len(MODELS)}); json updated, plot deferred until all K/models done.', flush=True)
