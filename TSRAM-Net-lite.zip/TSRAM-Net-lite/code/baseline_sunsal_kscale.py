# -*- coding: utf-8 -*-
"""
SUnSAL / FCLS 库缩放对照（Table 3 / Fig.2 同协议）—— 决定"开放库丰度稳定性"卖点是否为 TSRAM 独有。
在 kscale_experiment_v4.py 的同一 RALL 库、同一 gen、同一测试集（3×3000, 1% 噪声）下，对每个 K
跑 FCLS（全库非负 + sum-to-one）与 SUnSAL（非负 l1 ADMM），报 F1/cos/support/时间。

GPU 批量 ADMM：
  - FCLS = 在增广矩阵 [R; δ·1] 上的非负最小二乘（λ=0 的非负 ADMM），等价 scipy NNLS+ASC；
    在 K=1000 与 baseline_sunsal.json 的 scipy FCLS(F1=0.948/cos=0.992) 对齐验证。
  - SUnSAL = A=R.T 上非负 l1 ADMM，λ 在每个 K 的验证集上独立选择，丰度事后归一化 sum=1。
CPU 单样本时间在每个 K 采样 30 个样本（SUnSAL 固定 200 iter；FCLS 用 scipy NNLS），给随 K 缩放趋势。
"""
import io, json, time, os
import numpy as np
import torch
from scipy.optimize import nnls
from sklearn.metrics import f1_score, precision_score, recall_score

# ---------- 复用 kscale v4 的库/数据/gen（exec 到训练循环之前） ----------
p = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'kscale_experiment_v4.py')
lines = io.open(p, encoding='utf-8').read().split('\n')
cut = next(i for i, l in enumerate(lines) if l.startswith('MODELS ='))
ns = {}
exec(compile('\n'.join(lines[:cut]), p, 'exec'), ns)
RALL = ns['RALL']; gen = ns['gen']; NWP = ns['NWP']; KMAX = ns['KMAX']
DEV = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
KS = [20, 50, 100, 200, 500, 1000, 1500, 1900]
OUT = 'baseline_sunsal_kscale.json'
print(f'Device {DEV} | SUnSAL/FCLS K-scaling | KS={KS}', flush=True)

MU = 1.0; NITER = 200; BATCH = 2500; DELTA = 0.01
LAM_GRID = [0.0, 1e-4, 3e-4, 1e-3, 3e-3, 1e-2, 2e-2, 3e-2, 5e-2, 1e-1, 2e-1, 4e-1]


def norm_ab(a, eps=1e-12):
    return a / np.maximum(a.sum(1, keepdims=True), eps)


def admm_nn(Y, A, lam, mu=MU, niter=NITER, batch=BATCH, tol=1e-6):
    """批量非负 l1 ADMM。A:(L,K) torch, Y:(N,L) numpy；lam=0 即非负 NNLS（FCLS 增广后用）。返回 z。"""
    At = torch.tensor(A, dtype=torch.float32, device=DEV)
    ATA = At.T @ At
    Pinv = torch.inverse(ATA + mu * torch.eye(At.shape[1], device=DEV))
    outs = []
    for j in range(0, len(Y), batch):
        Yb = torch.tensor(Y[j:j+batch], dtype=torch.float32, device=DEV)
        AtY = Yb @ At
        x = torch.zeros_like(AtY); z = torch.zeros_like(AtY); u = torch.zeros_like(AtY)
        th = lam / mu
        for _ in range(niter):
            xp = x
            x = (AtY + mu * (z - u)) @ Pinv
            v = x + u
            z = torch.clamp(v - th, min=0.0)
            u = u + x - z
            if torch.max(torch.abs(x - xp)).item() < tol:
                break
        outs.append(z.cpu().numpy())
    return np.concatenate(outs)


def fcls_gpu(X, R):
    K = R.shape[0]
    A = np.vstack([R.T, DELTA * np.ones((1, K))])
    Ya = np.hstack([X, np.full((len(X), 1), DELTA)])
    z = admm_nn(Ya, A, 0.0)
    return norm_ab(z)


def sunsal_gpu(X, R, lam):
    return norm_ab(admm_nn(X, R.T, lam))


def scan_th(ab, yp, grid=np.arange(0.005, 0.20, 0.005)):
    bt, bf = 0.05, 0.0
    for t in grid:
        f = f1_score(yp, (ab > t).astype(float), average='samples', zero_division=0)
        if f > bf:
            bf, bt = float(f), float(t)
    return bt, bf


def metrics(ab, th, yp, ya):
    P = (ab > th).astype(float)
    cos = float(((ab*ya).sum(1) / np.maximum(np.linalg.norm(ab, axis=1)*np.linalg.norm(ya, axis=1), 1e-10)).mean())
    return {'F1': round(float(f1_score(yp, P, average='samples', zero_division=0)), 4),
            'P': round(float(precision_score(yp, P, average='samples', zero_division=0)), 4),
            'R': round(float(recall_score(yp, P, average='samples', zero_division=0)), 4),
            'cosine': round(cos, 4),
            'final_support': round(float((ab > 1e-2).sum(1).mean()), 2)}


def fcls_scipy_one(x, R, delta=DELTA):
    K = R.shape[0]
    A = np.vstack([R.T, delta * np.ones((1, K))]); b = np.concatenate([x, [delta]])
    w, _ = nnls(A, b); s = w.sum(); return w / s if s > 1e-8 else w


def sunsal_cpu_one(y, R, Pinv, lam, mu=MU, niter=NITER):
    At = R; AtY = At @ y; K = R.shape[0]
    x = np.zeros(K); z = np.zeros(K); u = np.zeros(K); th = lam / mu
    for _ in range(niter):
        x = Pinv @ (AtY + mu * (z - u)); v = x + u
        z = np.maximum(v - th, 0.0); u = u + x - z
    return z


summary = json.load(open(OUT, encoding='utf-8')) if os.path.exists(OUT) else {}
for K in KS:
    sk = str(K)
    summary.setdefault(sk, {})
    R = RALL[:K]
    # 验证集（固定 1% 噪声，seed=2，与 v4 早停验证一致）
    Xva, ypva, _ = gen(10000, K, 2, aug=False, std=0.01)
    # 测试 3×3000（与 v4 evaluate 完全一致）
    Xt, ypt, yat = [], [], []
    for ti in range(3):
        Xb, yb, ab = gen(3000, K, 300 + ti, aug=False, std=0.01)
        Xt.append(Xb); ypt.append(yb); yat.append(ab)
    Xt = np.concatenate(Xt); ypt = np.concatenate(ypt); yat = np.concatenate(yat)

    # ---- FCLS（GPU ADMM；K=1000 与 scipy 对齐） ----
    if 'fcls' not in summary[sk]:
        abv = fcls_gpu(Xva, R); fth, fvf1 = scan_th(abv, ypva)
        abt = fcls_gpu(Xt, R)
        summary[sk]['fcls'] = {'threshold': fth, **metrics(abt, fth, ypt, yat)}
        # CPU 采样时间
        ncn = 30
        t0 = time.time()
        for i in range(ncn):
            fcls_scipy_one(Xt[i], R)
        summary[sk]['fcls']['cpu_ms_per_sample'] = round((time.time() - t0) / ncn * 1000, 2)
        print(f'K={K:5d} FCLS F1 {summary[sk]["fcls"]["F1"]:.4f} cos {summary[sk]["fcls"]["cosine"]:.4f} '
              f'cpu {summary[sk]["fcls"]["cpu_ms_per_sample"]:.1f}ms', flush=True)
        json.dump(summary, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

    # ---- SUnSAL（每 K 验证集选 λ） ----
    if 'sunsal' not in summary[sk]:
        best = None
        for lam in LAM_GRID:
            ab = sunsal_gpu(Xva, R, lam); th, f1 = scan_th(ab, ypva)
            if best is None or f1 > best[2]:
                best = (lam, th, f1)
        lam, sth, svf1 = best
        abt = sunsal_gpu(Xt, R, lam)
        summary[sk]['sunsal'] = {'lambda': lam, 'threshold': sth, 'val_f1': round(svf1, 4),
                                 **metrics(abt, sth, ypt, yat)}
        # CPU 采样时间：A=R.T (L,K), ATA=A.T@A=R@R.T (K,K)
        Pinv = np.linalg.inv(R @ R.T + MU * np.eye(K))
        ncn = 30 if K <= 1000 else 15
        t0 = time.time()
        for i in range(ncn):
            sunsal_cpu_one(Xt[i], R, Pinv, lam)
        summary[sk]['sunsal']['cpu_ms_per_sample'] = round((time.time() - t0) / ncn * 1000, 2)
        print(f'K={K:5d} SUnSAL λ={lam:.0e} F1 {summary[sk]["sunsal"]["F1"]:.4f} cos '
              f'{summary[sk]["sunsal"]["cosine"]:.4f} cpu {summary[sk]["sunsal"]["cpu_ms_per_sample"]:.1f}ms', flush=True)
        json.dump(summary, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

print('\n==== K-SCALING SUMMARY ====', flush=True)
for K in KS:
    for m in ('fcls', 'sunsal'):
        d = summary[str(K)].get(m)
        if d:
            print(f'K={K:5d} {m:7s} F1 {d["F1"]:.4f} cos {d["cosine"]:.4f} support {d["final_support"]} '
                  f'cpu {d.get("cpu_ms_per_sample")}ms', flush=True)
print('SAVED', OUT, flush=True)
