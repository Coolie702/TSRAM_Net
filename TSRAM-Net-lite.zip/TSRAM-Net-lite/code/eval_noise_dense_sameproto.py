# -*- coding: utf-8 -*-
"""
Protocol-matched noise comparison: TSRAM-Net vs a dense K-way head on the
same encoder, evaluated through the Fig. 3 pipeline of eval_noise_final.py
(test set gen(3000,123), noise rng 456, per-sample renormalisation after
noise, presence threshold 0.5).

Why this exists: the S-XV sweep used the K-scaling harness (test seeds
300-302), so its absolute numbers cannot be quoted next to Fig. 3. This run
puts both heads on the Fig. 3 protocol so the main text can cite matched
numbers.
"""
import os
import io, sys, json
import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import f1_score

PAPER = 'eval_noise_final.py'
V4 = 'kscale_experiment_v4.py'


def prelude(path, cutpat):
    lines = io.open(path, encoding='utf-8').read().split('\n')
    cut = next(i for i, l in enumerate(lines) if l.startswith(cutpat))
    ns = {}
    _a = sys.argv[:]
    sys.argv = [path]
    exec(compile('\n'.join(lines[:cut]), path, 'exec'), ns)
    sys.argv = _a
    return ns


A = prelude(PAPER, 'model=Net()')      # R, gen, Net, LEVELS, DEV, K, NWP
B = prelude(V4, 'MODELS =')            # MLPEnc, MLPDense
print('libraries:', A['R'].shape, B['RALL'].shape,
      'max|R-RALL[:K]| =', float(np.abs(A['R'] - B['RALL'][:A['K']]).max()), flush=True)

R, gen, Net = A['R'], A['gen'], A['Net']
MLPDense = B['MLPDense']
DEV, K = A['DEV'], A['K']
LEVELS = [0.0, 0.01, 0.05, 0.10, 0.20]
LABS = ['0%', '1%', '5%', '10%', '20%']

tsram = Net().to(DEV)
tsram.load_state_dict(torch.load('tsram_final_v2_best_model.pth', map_location=DEV))
tsram.update_ref(torch.from_numpy(R).to(DEV))
tsram.eval()

dense = MLPDense(K).to(DEV)
dense.load_state_dict(torch.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'checkpoints', '_ckpt_MLPDense_K1000.pt'), map_location=DEV))
dense.eval()
print('both models loaded', flush=True)

Xc, ypt, yat = gen(3000, 123)
res = {'levels': LEVELS, 'labels': LABS, 'tsram_f1': [], 'tsram_cos': [],
       'dense_f1': [], 'dense_cos': [], 'tsram_P': [], 'dense_P': [],
       'tsram_R': [], 'dense_R': []}

for std, lab in zip(LEVELS, LABS):
    rng = np.random.RandomState(456)
    Xn = Xc + (rng.normal(0, std, Xc.shape).astype(np.float32) if std > 0 else 0)
    for i in range(len(Xn)):
        lo, hi = Xn[i].min(), Xn[i].max()
        Xn[i] = (Xn[i] - lo) / (hi - lo + 1e-12)

    row = {}
    with torch.no_grad():
        for name, model in (('tsram', tsram), ('dense', dense)):
            P, AB = [], []
            for j in range(0, len(Xn), 512):
                out = model(torch.from_numpy(Xn[j:j + 512]).to(DEV))
                pl, ab = out[0], out[1]
                P.append((torch.sigmoid(pl) > .5).float().cpu().numpy())
                AB.append(ab.cpu().numpy())
            P = np.concatenate(P)
            AB = np.concatenate(AB)
            f1 = f1_score(ypt, P, average='samples', zero_division=0)
            tp = float((ypt * P).sum() / max(P.sum(), 1e-9))
            tr = float((ypt * P).sum() / max(ypt.sum(), 1e-9))
            cs = float(((AB * yat).sum(1) / np.maximum(
                np.linalg.norm(AB, axis=1) * np.linalg.norm(yat, axis=1), 1e-10)).mean())
            row[name] = (f1, cs, tp, tr)

    for name in ('tsram', 'dense'):
        f1, cs, tp, tr = row[name]
        res[f'{name}_f1'].append(round(float(f1), 4))
        res[f'{name}_cos'].append(round(cs, 4))
        res[f'{name}_P'].append(round(tp, 4))
        res[f'{name}_R'].append(round(tr, 4))
    print(f"{lab:>4}  TSRAM F1 {row['tsram'][0]:.3f} cos {row['tsram'][1]:.3f} | "
          f"dense F1 {row['dense'][0]:.3f} cos {row['dense'][1]:.3f}", flush=True)

json.dump(res, open('noise_dense_sameproto.json', 'w'), indent=2)
print('SAVED noise_dense_sameproto.json', flush=True)
