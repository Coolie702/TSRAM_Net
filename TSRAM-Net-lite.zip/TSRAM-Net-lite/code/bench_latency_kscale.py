# -*- coding: utf-8 -*-
"""
Latency of the learned forward pass against library size K.

Timing does not depend on weight values, so each K is instantiated with the
same architecture; the K=1000 instance is then overwritten with the trained
checkpoint to anchor the curve. A component breakdown at K=1000 and K=1900
shows where the K-dependent cost actually sits.
"""
import os
import json, time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

NWP, DIM = 1024, 1024
KS = [20, 50, 100, 200, 500, 1000, 1500, 1900, 5000, 10000]
torch.set_num_threads(1)


def sparsemax(z, dim=-1):
    if dim < 0:
        dim = z.ndim + dim
    z = z - z.max(dim=dim, keepdim=True)[0]
    zs, _ = torch.sort(z, dim=dim, descending=True)
    zc = torch.cumsum(zs, dim=dim)
    k = torch.arange(1, z.shape[dim] + 1, dtype=z.dtype).view(
        *[1 if i != dim else -1 for i in range(z.ndim)])
    km = (1 + k * zs > zc).float().sum(dim=dim, keepdim=True).long() - 1
    km = km.clamp(min=0)
    tau = (zc.gather(dim, km) - 1) / (km.float() + 1)
    return (z - tau).clamp(min=0)


class Enc(nn.Module):
    def __init__(s):
        super().__init__()
        s.fc1 = nn.Linear(NWP, DIM); s.bn1 = nn.BatchNorm1d(DIM)
        s.fc2 = nn.Linear(DIM, DIM); s.bn2 = nn.BatchNorm1d(DIM); s.fc3 = nn.Linear(DIM, DIM)

    def forward(s, x):
        h = F.relu(s.bn1(s.fc1(x)))
        h = F.relu(s.bn2(s.fc2(h))) + h
        h = s.fc3(h) + h
        return F.normalize(h, p=2, dim=-1)


class Net(nn.Module):
    def __init__(s, K):
        super().__init__()
        s.encoder = Enc()
        s.register_buffer('ref_feat', torch.zeros(K, DIM))
        s.log_Tp = nn.Parameter(torch.tensor(np.log(582.0)))
        s.pres_head = nn.Sequential(nn.Linear(DIM * 2, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(.3),
                                    nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(.2),
                                    nn.Linear(256, K))
        s.log_Ta = nn.Parameter(torch.tensor(np.log(5.1)))
        s.log_ss = nn.Parameter(torch.tensor(np.log(13.4)))
        s.refiner = nn.Sequential(nn.Linear(DIM * 3, DIM), nn.BatchNorm1d(DIM), nn.ReLU(), nn.Dropout(.2),
                                  nn.Linear(DIM, DIM // 2), nn.BatchNorm1d(DIM // 2), nn.ReLU(), nn.Dropout(.1),
                                  nn.Linear(DIM // 2, K))

    def forward(s, x):
        Q = s.encoder(x); sim = Q @ s.ref_feat.T
        Tp = torch.exp(s.log_Tp).clamp(min=.1); Ta = torch.exp(s.log_Ta).clamp(min=.1)
        ss = torch.exp(s.log_ss)
        Ap = F.softmax(sim / Tp, -1); wp = Ap @ s.ref_feat
        pl = s.pres_head(torch.cat([Q, wp], -1))
        Ai = sparsemax(sim / Ta, -1); wi = Ai @ s.ref_feat
        al = s.refiner(torch.cat([Q, wi, Q - wi], -1))
        ab = sparsemax((sim * ss + al) / Ta, -1)
        return pl, ab, Ap, Ai


def timeit(fn, n=300, reps=3):
    with torch.no_grad():
        for _ in range(30):
            fn()
        out = []
        for _ in range(reps):
            t0 = time.perf_counter()
            for _ in range(n):
                fn()
            out.append((time.perf_counter() - t0) / n * 1000)
    return float(np.median(out)), min(out), max(out)


x = torch.randn(1, NWP)
out = {'K': KS, 'ms': []}
for K in KS:
    m = Net(K).eval()
    m.ref_feat.copy_(F.normalize(torch.randn(K, DIM), p=2, dim=-1))
    if K == 1000:
        sd = torch.load('tsram_final_v2_best_model.pth', map_location='cpu')
        m.load_state_dict(sd)
        print('  (K=1000 uses the trained checkpoint)', flush=True)
    ms, lo, hi = timeit(lambda: m(x))
    out['ms'].append(round(ms, 3))
    print(f'K={K:5d}  {ms:.3f} ms  ({lo:.3f}-{hi:.3f})', flush=True)

json.dump(out, open('latency_kscale.json', 'w'), indent=2)

# ---- component breakdown at K=1000 and 1900 ----
print('\ncomponent breakdown (ms):')
bd = {}
for K in (1000, 1900):
    m = Net(K).eval()
    m.ref_feat.copy_(F.normalize(torch.randn(K, DIM), p=2, dim=-1))
    with torch.no_grad():
        Q = m.encoder(x)
    parts = {}
    parts['encoder'] = timeit(lambda: m.encoder(x))[0]
    parts['sim  Q@ref.T'] = timeit(lambda: Q @ m.ref_feat.T)[0]
    sim = Q @ m.ref_feat.T
    parts['softmax(K)'] = timeit(lambda: F.softmax(sim / 582.0, -1))[0]
    Ap = F.softmax(sim / 582.0, -1)
    parts['wp  Ap@ref'] = timeit(lambda: Ap @ m.ref_feat)[0]
    wp = Ap @ m.ref_feat
    parts['pres_head'] = timeit(lambda: m.pres_head(torch.cat([Q, wp], -1)))[0]
    parts['sparsemax(K)'] = timeit(lambda: sparsemax(sim / 5.1, -1))[0]
    Ai = sparsemax(sim / 5.1, -1)
    parts['wi  Ai@ref'] = timeit(lambda: Ai @ m.ref_feat)[0]
    wi = Ai @ m.ref_feat
    parts['refiner'] = timeit(lambda: m.refiner(torch.cat([Q, wi, Q - wi], -1)))[0]
    bd[K] = {k: round(v, 3) for k, v in parts.items()}
    print(f' K={K}: ' + ', '.join(f'{k} {v:.3f}' for k, v in parts.items()), flush=True)
json.dump(bd, open('latency_breakdown.json', 'w'), indent=2)
print('SAVED latency_kscale.json, latency_breakdown.json')
