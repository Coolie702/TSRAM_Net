"""
TSRAM-Net v2 全量组件消融（Table 5）================================================================================
与 v2 主模型同规模：K=1000、50k 训练 / 10k 验证、450 epoch、batch256、相同随机噪声增强。
相比 30k/300ep 的 ablation_components_v2.py，本脚本训练充分，用于最终入表的组件贡献结论。

变体：
  full           完整模型（标准sparsemax粗检索 + refiner + sparsemax丰度 + 可学习温度 + 每epoch刷新）
  no_refiner     去掉精修MLP，comb 只用 ss·sim
  ab_softmax     最终丰度改 softmax（对照 sparsemax 精确零）
  ai_softmax     粗检索 Ai 改 softmax（对照粗检索稀疏压缩）
  fixed_temp     温度 Tp/Ta/ss 固定不学习
  no_refresh     记忆矩阵仅初始化一次、训练中不刷新
  abundance_only 仅 abundance 流（无 presence head，存在性由丰度阈值给出）

评估（干净0% 与 1%噪声，各3×4000测试集）：
  整体 F1/P/R/cosine、粗检索|Ai|、最终丰度非零数；
  以及【次要端元丰度分层 recall】——双流 presence 宽召回价值的关键证据：
  对双端元样本取真实丰度较低的端元，按其丰度分 low[5%,15%)/mid[15%,35%)/high[35%,50%]，
  统计该次要端元被检出的 recall；单端元样本单列 single。
用法：
  python ablation_full_v3.py full abundance_only   # 只跑指定变体（断点续跑，已完成自动跳过）
  python ablation_full_v3.py                        # 跑全部未完成变体
输出：ablation_full_v3.json
"""
import os, sys, json, time, warnings
import numpy as np
from collections import Counter, defaultdict
from scipy.interpolate import interp1d
from scipy.signal import savgol_filter
import torch, torch.nn as nn, torch.nn.functional as F, torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import f1_score, precision_score, recall_score
warnings.filterwarnings('ignore')
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'rruff')
NWP, WMIN, WMAX, DIM, K = 1024, 100.0, 1500.0, 1024, 1000
CWN = np.linspace(WMIN, WMAX, NWP)
N_EPOCHS, BATCH, N_TRAIN, N_VAL, LR = 450, 256, 50000, 10000, 8e-4
OUT = 'ablation_full_v3.json'
ALL_VARIANTS = ['full', 'no_refiner', 'ab_softmax', 'ai_softmax', 'fixed_temp', 'no_refresh', 'abundance_only']
VARIANTS = sys.argv[1:] if len(sys.argv) > 1 else ALL_VARIANTS
DEV = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'Device {DEV} | FULL component ablation | {N_EPOCHS}ep | {N_TRAIN} samples | variants={VARIANTS}', flush=True)

def parse_raman(fp):
    name, lines = None, []
    with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if line.startswith('##NAMES='): name = line.split('=', 1)[1].strip()
            elif line and not line.startswith('#'): lines.append(line)
    if name is None or not lines: return None
    wn, it = [], []
    for l in lines:
        p = l.split(',')
        if len(p) >= 2:
            try: wn.append(float(p[0])); it.append(float(p[1]))
            except Exception: pass
    if len(wn) < 50: return None
    return name, np.array(wn, np.float32), np.array(it, np.float32)

def interp_spec(wn, it):
    m = (wn >= WMIN - 50) & (wn <= WMAX + 50)
    if m.sum() < 20: return None
    wn, it = wn[m], it[m]; o = np.argsort(wn); wn, it = wn[o], it[o]
    uw, idx = np.unique(wn, return_inverse=True)
    ui = np.array([it[idx == i].mean() for i in range(len(uw))])
    if len(uw) < 20: return None
    f = interp1d(uw, ui, kind='linear', bounds_error=False, fill_value=0.0); s = f(CWN)
    wl = min(15, len(s) // 10); wl += (wl % 2 == 0)
    if wl >= 5: s = savgol_filter(s, wl, 2)
    lo, hi = s.min(), s.max()
    return None if hi - lo < 1e-8 else ((s - lo) / (hi - lo)).astype(np.float32)

print('building library...', flush=True)
ms = defaultdict(list)
for fn in os.listdir(DATA_DIR):
    if fn.endswith('.txt') and 'Processed' in fn:
        r = parse_raman(os.path.join(DATA_DIR, fn))
        if r:
            nm, wn, it = r; s = interp_spec(wn, it)
            if s is not None: ms[nm].append(s)
topK = [m for m, _ in Counter({m: len(v) for m, v in ms.items()}).most_common(K)]
R = np.zeros((K, NWP), np.float32)
for i, m in enumerate(topK):
    sp = np.array(ms[m]); ref = np.median(sp, 0) if len(sp) > 1 else sp[0]
    lo, hi = ref.min(), ref.max()
    R[i] = ((ref - lo) / (hi - lo + 1e-12)).astype(np.float32) if hi - lo > 1e-8 else ref

def sparsemax(z, dim=-1):
    if dim < 0: dim = z.ndim + dim
    z = z - z.max(dim=dim, keepdim=True)[0]
    zs, _ = torch.sort(z, dim=dim, descending=True); zc = torch.cumsum(zs, dim=dim)
    k = torch.arange(1, z.shape[dim] + 1, device=z.device, dtype=z.dtype).view(*[1 if i != dim else -1 for i in range(z.ndim)])
    km = (1 + k * zs > zc).float().sum(dim=dim, keepdim=True).long() - 1
    km = km.clamp(min=0)
    return (z - ((zc.gather(dim, km) - 1) / (km.float() + 1))).clamp(min=0)

class Enc(nn.Module):
    def __init__(s):
        super().__init__(); s.fc1 = nn.Linear(NWP, DIM); s.bn1 = nn.BatchNorm1d(DIM)
        s.fc2 = nn.Linear(DIM, DIM); s.bn2 = nn.BatchNorm1d(DIM); s.fc3 = nn.Linear(DIM, DIM)
    def forward(s, x):
        h = F.relu(s.bn1(s.fc1(x))); h = F.relu(s.bn2(s.fc2(h))) + h; h = s.fc3(h) + h
        return F.normalize(h, p=2, dim=-1)

class Net(nn.Module):
    def __init__(s, variant='full'):
        super().__init__(); s.v = variant
        s.encoder = Enc(); s.register_buffer('ref_feat', torch.zeros(K, DIM))
        if variant != 'abundance_only':
            s.log_Tp = nn.Parameter(torch.tensor(np.log(4.0)))
            s.pres_head = nn.Sequential(nn.Linear(DIM * 2, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(.3),
                nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(.2), nn.Linear(256, K))
        if variant != 'presence_only':
            if variant == 'fixed_temp':
                s.register_buffer('Tp_b', torch.tensor(4.0)); s.register_buffer('Ta_b', torch.tensor(3.0)); s.register_buffer('ss_b', torch.tensor(5.0))
            else:
                s.log_Ta = nn.Parameter(torch.tensor(np.log(3.0))); s.log_ss = nn.Parameter(torch.tensor(np.log(5.0)))
                if variant == 'abundance_only': s.log_Tp = nn.Parameter(torch.tensor(np.log(4.0)))
            if variant != 'no_refiner':
                s.refiner = nn.Sequential(nn.Linear(DIM * 3, DIM), nn.BatchNorm1d(DIM), nn.ReLU(), nn.Dropout(.2),
                    nn.Linear(DIM, DIM // 2), nn.BatchNorm1d(DIM // 2), nn.ReLU(), nn.Dropout(.1), nn.Linear(DIM // 2, K))
    @torch.no_grad()
    def update_ref(s, ref):
        s.eval()
        for i in range(0, K, 512): s.ref_feat[i:i + 512] = s.encoder(ref[i:i + 512].to(s.ref_feat.device))
    def temps(s):
        if s.v == 'fixed_temp': return s.Tp_b, s.Ta_b, s.ss_b
        dev = s.ref_feat.device
        Tp = torch.exp(getattr(s, 'log_Tp', torch.tensor(np.log(4.0), device=dev))).clamp(min=.1)
        if hasattr(s, 'log_Ta'):
            Ta = torch.exp(s.log_Ta).clamp(min=.1); ss = torch.exp(s.log_ss)
        else:
            Ta = torch.tensor(1.0, device=dev); ss = torch.tensor(1.0, device=dev)
        return Tp, Ta, ss
    def forward(s, x):
        Q = s.encoder(x); sim = Q @ s.ref_feat.T; v = s.v
        pl = None; ab = None; Ap = None; Ai = None
        if v != 'abundance_only':
            Tp, _, _ = s.temps()
            Ap = F.softmax(sim / Tp, -1); wp = Ap @ s.ref_feat; pl = s.pres_head(torch.cat([Q, wp], -1))
        if v != 'presence_only':
            _, Ta, ss = s.temps()
            Ai = (F.softmax(sim / Ta, -1) if v == 'ai_softmax' else sparsemax(sim / Ta, -1))
            wi = Ai @ s.ref_feat
            if v == 'no_refiner':
                comb = sim * ss
            else:
                al = s.refiner(torch.cat([Q, wi, Q - wi], -1)); comb = sim * ss + al
            ab = (F.softmax(comb / Ta, -1) if v == 'ab_softmax' else sparsemax(comb / Ta, -1))
        return pl, ab, Ap, Ai

class ContrastiveLoss(nn.Module):
    def __init__(s, T=.4):
        super().__init__(); s.T = T
    def forward(s, lo, t):
        z = lo - lo.max(-1, keepdim=True)[0].detach(); e = torch.exp(z / s.T)
        Z = e.sum(-1, keepdim=True).clamp(min=1e-8); lp = z / s.T - torch.log(Z)
        npos = t.sum(-1).clamp(min=1)
        return (-(t * lp).sum(-1) / npos).mean()

def gen(n, seed0, aug=True, std=0.01):
    rng = np.random.RandomState(seed0)
    X = np.zeros((n, NWP), np.float32); yp = np.zeros((n, K), np.float32); ya = np.zeros((n, K), np.float32)
    for i in range(n):
        nc = rng.randint(1, 3); ch = rng.choice(K, nc, replace=False)
        ra = rng.dirichlet(np.ones(nc)).astype(np.float32)
        if aug:
            u = rng.rand(); sigma = 0.0 if u < 0.15 else 0.002 + (u - 0.15) / 0.85 * 0.048
        else:
            sigma = std
        noise = rng.normal(0, sigma, NWP).astype(np.float32) if sigma > 0 else 0.0
        m = (R[ch] * ra[:, None]).sum(0) + noise
        lo, hi = m.min(), m.max(); m = (m - lo) / (hi - lo + 1e-12)
        X[i] = m; yp[i, ch] = 1; ya[i, ch] = ra
    return X, yp, ya

ref_t = torch.from_numpy(R).to(DEV)
Xtr, yptr, yatr = gen(N_TRAIN, 1); Xva, ypva, _ = gen(N_VAL, 2)
tr = DataLoader(TensorDataset(torch.from_numpy(Xtr), torch.from_numpy(yptr), torch.from_numpy(yatr)), batch_size=BATCH, shuffle=True)

def presence_pred(model, X):
    P = []; AB = []; AI = []
    model.eval()
    with torch.no_grad():
        for j in range(0, len(X), 512):
            pl, ab, Ap, Ai = model(torch.from_numpy(X[j:j + 512]).to(DEV))
            if model.v == 'abundance_only':
                P.append((ab > 0.05).float().cpu().numpy())
            else:
                P.append((torch.sigmoid(pl) > .5).float().cpu().numpy())
            if ab is not None: AB.append(ab.cpu().numpy())
            if Ai is not None: AI.append((Ai > 0).sum(-1).cpu().numpy())
    P = np.concatenate(P)
    AB = np.concatenate(AB) if AB else None
    AI = np.concatenate(AI) if AI else None
    return P, AB, AI

def stratified_minor_recall(P, yat):
    """双端元样本中，按【次要端元真实丰度】分层统计其次要端元的检出 recall。"""
    bins = {'single': [], 'low': [], 'mid': [], 'high': []}
    for i in range(P.shape[0]):
        pos = np.where(yat[i] > 0.01)[0]
        if len(pos) == 1:
            bins['single'].append(float(P[i, pos[0]] > 0.5))
        elif len(pos) >= 2:
            fracs = yat[i, pos]
            minor = pos[int(np.argmin(fracs))]; mf = float(fracs.min())
            hit = float(P[i, minor] > 0.5)
            if mf < 0.15: bins['low'].append(hit)
            elif mf < 0.35: bins['mid'].append(hit)
            else: bins['high'].append(hit)
    out = {}
    for key, v in bins.items():
        v = np.array(v, dtype=np.float64)
        out[key] = {'n': int(len(v)), 'recall': round(float(v.mean()), 4) if len(v) else None}
    return out

results = json.load(open(OUT)) if os.path.exists(OUT) else {}
for v in VARIANTS:
    if v in results and isinstance(results[v], dict) and 'conditions' in results[v]:
        print(f'skip {v} (already done)', flush=True); continue
    print(f'\n===== variant: {v} =====', flush=True)
    torch.manual_seed(42); np.random.seed(42)
    m = Net(v).to(DEV); m.update_ref(ref_t)
    crit = ContrastiveLoss(); opt = optim.AdamW(m.parameters(), lr=LR, weight_decay=1e-4)
    sch = optim.lr_scheduler.CosineAnnealingLR(opt, T_max=N_EPOCHS)
    t0 = time.time(); best = 0.0
    for ep in range(N_EPOCHS):
        if v != 'no_refresh': m.update_ref(ref_t)
        m.train(); tot = 0.0; nb = 0
        for xb, pb, ab_ in tr:
            xb, pb, ab_ = xb.to(DEV), pb.to(DEV), ab_.to(DEV)
            pl, ab, _, _ = m(xb)
            if v == 'presence_only': loss = crit(pl, pb)
            elif v == 'abundance_only': loss = F.mse_loss(ab, ab_)
            else: loss = crit(pl, pb) + F.mse_loss(ab, ab_)
            opt.zero_grad(); loss.backward(); opt.step()
            tot += loss.item(); nb += 1
        sch.step()
        if (ep + 1) % 50 == 0 or ep == N_EPOCHS - 1:
            Pv, _, _ = presence_pred(m, Xva); f = f1_score(ypva, Pv, average='samples', zero_division=0)
            if f > best: best = f
            print(f'  ep{ep+1:3d} loss{tot/nb:.4f} valF1 {f:.4f}(best {best:.4f}) {((time.time()-t0)/60):.1f}min', flush=True)
    # ===== 评估：干净 / 1%噪声，各 3×4000 =====
    m.update_ref(ref_t); m.eval(); cond = {}
    for noise in [0.0, 0.01]:
        Ps, yps, yats, ABs, AIs = [], [], [], [], []
        for ti in range(3):
            Xt, yt, yat = gen(4000, 300 + ti, aug=False, std=noise)
            P, AB, AI = presence_pred(m, Xt)
            Ps.append(P); yps.append(yt); yats.append(yat)
            if AB is not None: ABs.append(AB)
            if AI is not None: AIs.append(AI)
        P = np.concatenate(Ps); yp = np.concatenate(yps); yat = np.concatenate(yats)
        f1 = f1_score(yp, P, average='samples', zero_division=0)
        pr = precision_score(yp, P, average='samples', zero_division=0)
        rc = recall_score(yp, P, average='samples', zero_division=0)
        entry = {'F1': round(float(f1), 4), 'P': round(float(pr), 4), 'R': round(float(rc), 4)}
        if ABs:
            AB = np.concatenate(ABs)
            cos = float(((AB * yat).sum(1) / np.maximum(np.linalg.norm(AB, axis=1) * np.linalg.norm(yat, axis=1), 1e-10)).mean())
            entry['cos'] = round(cos, 4)
            entry['final_ab_nonzero'] = round(float((AB > 1e-4).sum(1).mean()), 2)
        if AIs:
            AI = np.concatenate(AIs); entry['Ai_nonzero'] = round(float(AI.mean()), 1)
        entry['minor_strata'] = stratified_minor_recall(P, yat)
        cond[f'noise_{noise:g}'] = entry
    results[v] = {'best_val_f1': round(float(best), 4), 'conditions': cond, 'train_min': round((time.time() - t0) / 60, 1)}
    json.dump(results, open(OUT, 'w'), indent=2)
    c0, c1 = cond['noise_0'], cond['noise_0.01']
    print(f'  -> clean F1 {c0["F1"]:.4f} | 1% F1 {c1["F1"]:.4f} | low-minor recall full/ab check below', flush=True)
    print(f'     minor-recall@1% single={c1["minor_strata"]["single"]["recall"]} '
          f'low={c1["minor_strata"]["low"]["recall"]} mid={c1["minor_strata"]["mid"]["recall"]} '
          f'high={c1["minor_strata"]["high"]["recall"]}', flush=True)

print('\n==== FULL ABLATION SUMMARY (noise 1%) ====', flush=True)
for v in VARIANTS:
    if v not in results: continue
    c1 = results[v]['conditions']['noise_0.01']; ms_ = c1.get('minor_strata', {})
    low = ms_.get('low', {}).get('recall'); mid = ms_.get('mid', {}).get('recall')
    print(f'  {v:15s} F1 {c1["F1"]:.4f} cos {c1.get("cos","--")} Ai {c1.get("Ai_nonzero","--")} '
          f'abNZ {c1.get("final_ab_nonzero","--")} | minorR low {low} mid {mid}', flush=True)
print('\nDone.')
