# -*- coding: utf-8 -*-
"""
Architecture vs. noise-augmentation: where does the robustness come from?
========================================================================
All four models are trained under the IDENTICAL v4 protocol (same library, same
gen(), same 50k/10k split, same noise augmentation, AdamW 8e-4, 600-ep cap,
early stop on the fixed 1%-noise validation set).  They are then evaluated at
FIVE noise levels, not just 0/1%, because 1% is the regime where every model is
close and the paper's robustness claim is invisible.

  TSRAM      : residual MLP encoder + two-stage retrieval head (paper's model)
  MLPDense   : residual MLP encoder + dense K-way sigmoid head (control: same
               backbone, same augmentation, different head)
  TransDense : Transformer encoder + dense head
  CNNDenseV2 : 1D CNN encoder + dense head

Reading: if TSRAM degrades more slowly than MLPDense at 5-20% noise, robustness
is architectural. If all four fall together, robustness is a property of the
noise augmentation, not of the retrieval head -- which changes what the paper
may claim.

Usage: python highnoise_arch.py <K> [MODEL ...]
"""
import io, os, sys, json, time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
import torch.optim as optim
from sklearn.metrics import f1_score, precision_score, recall_score

P = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'kscale_experiment_v4.py')
lines = io.open(P, encoding='utf-8').read().split('\n')
cut = next(i for i, l in enumerate(lines) if l.startswith('MODELS ='))
ns = {}
_saved = sys.argv[:]
sys.argv = [P]
exec(compile('\n'.join(lines[:cut]), P, 'exec'), ns)
sys.argv = _saved

RALL = ns['RALL']; gen = ns['gen']; DEV = ns['DEV']; DIM = ns['DIM']
MAX_EP, BATCH, N_TRAIN, N_VAL, LR = ns['MAX_EP'], ns['BATCH'], ns['N_TRAIN'], ns['N_VAL'], ns['LR']
PATIENCE, VAL_EVERY = ns['PATIENCE'], ns['VAL_EVERY']
RetrievalNet = ns['RetrievalNet']; MLPEnc = ns['MLPEnc']
TransformerEnc = ns['TransformerEnc']; MLPDense = ns['MLPDense']
ContrastiveLoss = ns['ContrastiveLoss']; val_f1 = ns['val_f1']

OUT = 'highnoise_results.json'
NOISES = (0.0, 0.01, 0.05, 0.10, 0.20)


class CNNEncV2(nn.Module):
    def __init__(s):
        super().__init__()
        def blk(i, o, k, st, d=1):
            return nn.Sequential(nn.Conv1d(i, o, k, st, k // 2, dilation=d),
                                 nn.BatchNorm1d(o), nn.ReLU(inplace=True))
        s.net = nn.Sequential(blk(1, 64, 7, 2), blk(64, 128, 7, 2), blk(128, 256, 7, 2),
                              blk(256, 256, 5, 1), blk(256, 256, 5, 1, d=2))
        s.fc1 = nn.Linear(512, DIM); s.bn1 = nn.BatchNorm1d(DIM); s.fc2 = nn.Linear(DIM, DIM)

    def forward(s, x):
        h = s.net(x.unsqueeze(1))
        h = torch.cat([h.mean(-1), h.amax(-1)], -1)
        h = F.relu(s.bn1(s.fc1(h)))
        return F.normalize(s.fc2(h) + h, p=2, dim=-1)


class DenseNet(nn.Module):
    def __init__(s, K, encoder):
        super().__init__()
        s.encoder = encoder
        s._bridge = nn.Sequential(nn.Linear(DIM, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(.2),
                                  nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU())
        s.pres_head = nn.Sequential(nn.Linear(256, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(.2),
                                    nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Linear(256, K))
        s.abun_head = nn.Linear(256, K)

    def forward(s, x):
        h = s._bridge(s.encoder(x))
        return s.pres_head(h), F.softmax(s.abun_head(h), -1)


def make(name, K):
    return {
        'TSRAM':      lambda: (RetrievalNet(K, MLPEnc()), 'contrast'),
        'MLPDense':   lambda: (MLPDense(K), 'bce'),
        'TransDense': lambda: (DenseNet(K, TransformerEnc()), 'bce'),
        'CNNDenseV2': lambda: (DenseNet(K, CNNEncV2()), 'bce'),
    }[name]()


@torch.no_grad()
def evaluate_noise(model, K):
    model.eval(); out = {}
    for noise in NOISES:
        fs, ps, rs, cs = [], [], [], []
        for ti in range(3):
            Xt, yt, yat = gen(3000, K, 300 + ti, aug=False, std=noise)
            P_, AB = [], []
            for j in range(0, len(Xt), 512):
                pl, ab = model(torch.from_numpy(Xt[j:j + 512]).to(DEV))
                P_.append((torch.sigmoid(pl) > .5).float().cpu().numpy())
                AB.append(ab.cpu().numpy())
            P_ = np.concatenate(P_); AB = np.concatenate(AB)
            fs.append(f1_score(yt, P_, average='samples', zero_division=0))
            ps.append(precision_score(yt, P_, average='samples', zero_division=0))
            rs.append(recall_score(yt, P_, average='samples', zero_division=0))
            cs.append(float(((AB * yat).sum(1) / np.maximum(
                np.linalg.norm(AB, axis=1) * np.linalg.norm(yat, axis=1), 1e-10)).mean()))
        out[f'{noise:g}'] = {'F1': round(float(np.mean(fs)), 4), 'P': round(float(np.mean(ps)), 4),
                             'R': round(float(np.mean(rs)), 4), 'cos': round(float(np.mean(cs)), 4)}
    return out


if __name__ == '__main__':
    K = int(sys.argv[1])
    names = sys.argv[2:] or ['TSRAM', 'MLPDense', 'TransDense', 'CNNDenseV2']
    res = json.load(open(OUT)) if os.path.exists(OUT) else {}
    res.setdefault(str(K), {})
    print(f'Device {DEV} | K={K} | {names} | noises={NOISES}', flush=True)

    Xtr, yptr, yatr = gen(N_TRAIN, K, 1)
    Xva, ypva, _ = gen(N_VAL, K, 2, aug=False, std=0.01)
    ref_t = torch.from_numpy(RALL[:K]).to(DEV)
    tr = DataLoader(TensorDataset(torch.from_numpy(Xtr), torch.from_numpy(yptr), torch.from_numpy(yatr)),
                    batch_size=BATCH, shuffle=True)
    print('data ready', flush=True)

    for name in names:
        if name in res[str(K)]:
            print(f'  {name} done, skip', flush=True); continue
        print(f'\n===== K={K}  {name} =====', flush=True)
        torch.manual_seed(42); np.random.seed(42)
        model, kind = make(name, K); model.to(DEV)
        if hasattr(model, 'update_ref'): model.update_ref(ref_t)
        bce = nn.BCEWithLogitsLoss(); cont = ContrastiveLoss()
        opt = optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-4)
        sch = optim.lr_scheduler.CosineAnnealingLR(opt, T_max=MAX_EP)
        best_f1, best_state, wait, best_ep = -1.0, None, 0, 0
        t0 = time.time()
        for ep in range(MAX_EP):
            if hasattr(model, 'update_ref'): model.update_ref(ref_t)
            model.train()
            for xb, pb, ab_ in tr:
                xb, pb, ab_ = xb.to(DEV), pb.to(DEV), ab_.to(DEV)
                pl, ab = model(xb)
                loss = (cont(pl, pb) if kind == 'contrast' else bce(pl, pb)) + F.mse_loss(ab, ab_)
                opt.zero_grad(); loss.backward(); opt.step()
            sch.step()
            if (ep + 1) % VAL_EVERY == 0:
                if hasattr(model, 'update_ref'): model.update_ref(ref_t)
                f1v = val_f1(model, Xva, ypva)
                if f1v > best_f1 + 1e-4:
                    best_f1, wait, best_ep = f1v, 0, ep + 1
                    best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
                else:
                    wait += 1
                if wait >= PATIENCE:
                    print(f'  early stop ep{ep+1} best {best_f1:.4f}@{best_ep} '
                          f'{(time.time()-t0)/60:.1f}min', flush=True); break
        if best_state is not None:
            model.load_state_dict(best_state)
        if hasattr(model, 'update_ref'): model.update_ref(ref_t)
        torch.save(best_state, f'_ckpt_{name}_K{K}.pt')
        met = evaluate_noise(model, K)
        met['best_epoch'] = best_ep; met['train_min'] = round((time.time() - t0) / 60, 1)
        met['params'] = sum(p.numel() for p in model.parameters())
        res[str(K)][name] = met
        print(f"  -> {name}: " + " | ".join(
            f"{n}: F1 {met[n]['F1']:.3f} cos {met[n]['cos']:.3f}" for n in [f'{x:g}' for x in NOISES]), flush=True)
        json.dump(res, open(OUT, 'w'), indent=2)
    print('\nDONE', flush=True)
