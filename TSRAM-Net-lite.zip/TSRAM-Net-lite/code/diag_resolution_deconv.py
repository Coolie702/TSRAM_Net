"""分辨率损失能否在推理时反卷积救回？

对照组：add=0 干净、add 展宽未处理、add 展宽 + 已知 PSF 的 Richardson-Lucy 反卷积。
若反卷积把 F1 拉回接近干净值，说明分辨率损失是"可校准误差"（代价为若干次卷积）；
若谱形误差恢复但 F1 不恢复，说明检索依赖的是被抹掉的细节结构。

用法: python diag_resolution_deconv.py [ckpt_prefix] [N]
"""
import os
import numpy as np, torch, sys, json
from scipy.ndimage import gaussian_filter1d, convolve1d
from sklearn.metrics import f1_score

CKPT = sys.argv[1] if len(sys.argv) > 1 else 'drift600_base'
N = int(sys.argv[2]) if len(sys.argv) > 2 else 3000
DEV = 'cuda' if torch.cuda.is_available() else 'cpu'

src = open('train_drift_full.py', encoding='utf-8').read()
head = src.split("class ContrastiveLoss")[0].replace(
    "print('[1/4] building library...',flush=True)", "")
_a = sys.argv; sys.argv = ['x', 'base']
ns = {}; exec(compile(head, 'head', 'exec'), ns); sys.argv = _a
TSRAMNet, gen = ns['TSRAMNet'], ns['gen']
R = np.load('_scratch/lib_R_v2.npy')
NWP, WMIN, WMAX = ns['NWP'], ns['WMIN'], ns['WMAX']
BIN = (WMAX - WMIN) / (NWP - 1)

model = TSRAMNet().to(DEV)
model.load_state_dict(torch.load(f'{CKPT}_best_model.pth', map_location=DEV))
model.update_ref(torch.from_numpy(R).to(DEV)); model.eval()

X, Y, A = gen(N, 100, aug=False, std=0.01)
Y = Y.astype(int)


def norm(Z):
    lo = Z.min(1, keepdims=True); hi = Z.max(1, keepdims=True)
    return ((Z - lo) / (hi - lo + 1e-12)).astype(np.float32)


def blur(Xa, fwhm):
    if fwhm <= 0: return Xa.copy()
    return norm(gaussian_filter1d(Xa.astype(np.float64),
                                  fwhm / 2.354820045 / BIN, axis=1, mode='nearest'))


def rl(Yb, fwhm, it=40):
    sig = fwhm / 2.354820045 / BIN
    h = int(np.ceil(4 * sig)) + 1
    psf = np.exp(-0.5 * (np.arange(-h, h + 1) / sig) ** 2).astype(np.float32); psf /= psf.sum()
    x = np.full_like(Yb, 0.5, dtype=np.float32)
    for _ in range(it):
        est = np.maximum(convolve1d(x, psf, axis=1, mode='nearest'), 1e-6)
        x = np.maximum(x * convolve1d(Yb / est, psf[::-1].copy(), axis=1, mode='nearest'), 0)
    return norm(x)


@torch.no_grad()
def evaluate(Xa):
    pl, ab, _, _ = model(torch.from_numpy(Xa).to(DEV))
    p = (torch.sigmoid(pl) > .5).float().cpu().numpy()
    abn = ab.cpu().numpy()
    cos = float(((abn * A).sum(1) / np.maximum(
        np.linalg.norm(abn, axis=1) * np.linalg.norm(A, axis=1), 1e-10)).mean())
    return f1_score(Y, p, average='samples', zero_division=0), cos


LEVELS = [0, 8, 16, 24, 32]
res = {'ckpt': CKPT, 'N': N, 'levels': LEVELS, 'rows': {}}

f0, c0 = evaluate(X)
print(f'ckpt={CKPT} N={N} | 干净 F1={f0:.4f} cos={c0:.4f}')
print(f'{"add":>5} {"模糊F1":>8} {"反卷积F1":>10} {"恢复%":>7} | {"模糊cos":>8} {"反卷积cos":>10}')

for f in LEVELS:
    if f == 0:
        res['rows']['0'] = {'blur': [round(f0, 4), round(c0, 4)], 'deconv': None}
        print(f'{0:>5} {f0:>8.4f} {"—":>10} {"—":>7} | {c0:>8.4f} {"—":>10}')
        continue
    Xb = blur(X, f)
    fb, cb = evaluate(Xb)
    Xr = rl(Xb, f)
    fr, cr = evaluate(Xr)
    rec = (fr - fb) / (f0 - fb) * 100 if (f0 - fb) > 1e-6 else float('nan')
    res['rows'][str(f)] = {'blur': [round(fb, 4), round(cb, 4)],
                           'deconv': [round(fr, 4), round(cr, 4)],
                           'recovery_pct': round(float(rec), 1)}
    print(f'{f:>5} {fb:>8.4f} {fr:>10.4f} {rec:>6.0f}% | {cb:>8.4f} {cr:>10.4f}')

json.dump(res, open(f'_scratch/resolution_deconv_{CKPT}.json', 'w'), indent=1)
print(f'\nSAVED _scratch/resolution_deconv_{CKPT}.json')
