# -*- coding: utf-8 -*-
"""仪器误差预算图（双栏，两面板）：instrument_budget.png

(a) 波数轴失准的容差曲线：不补偿 / 逐谱对齐 / 漂移增强
(b) 光谱分辨率的容差曲线：库展宽 / 样本展宽 / 两者匹配 / 反卷积

两面板等高，共用 7.0x2.55 in 画布，相对单列两图不额外占版面。
"""
import os
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ---------- (a) 波数轴 ----------
D = json.load(open('_scratch/drift_tolerance.json'))
BIN = D['bin_cm']
cm = np.array(D['grid']) * BIN
base = np.array(D['base_raw']); alig = np.array(D['base_aligned']); aug = np.array(D['aug_raw'])

# ---------- (b) 分辨率 ----------
A = json.load(open('_scratch/resolution_drift600_base.json'))
B = json.load(open('_scratch/resolution_deconv_drift600_base.json'))
lv = [int(k) for k in A['levels']]
tot = np.array([A['curves'][str(f)]['total_fwhm'] for f in lv])
sa = np.array([A['curves'][str(f)]['A_sample_only'][0] for f in lv])
lb = np.array([A['curves'][str(f)]['B_library_only'][0] for f in lv])
mt = np.array([A['curves'][str(f)]['C_matched'][0] for f in lv])
dl = [int(k) for k in B['rows'] if B['rows'][k]['deconv']]
db = np.array([B['rows'][str(f)]['blur'][0] for f in dl])
dd = np.array([B['rows'][str(f)]['deconv'][0] for f in dl])
tot_d = np.array([A['curves'][str(f)]['total_fwhm'] for f in dl])
clean = B['rows']['0']['blur'][0]

plt.rcParams.update({'font.size': 8.0, 'axes.linewidth': 0.7,
                     'xtick.major.width': 0.7, 'ytick.major.width': 0.7,
                     'xtick.major.size': 2.8, 'ytick.major.size': 2.8,
                     'xtick.labelsize': 7.5, 'ytick.labelsize': 7.5,
                     'mathtext.fontset': 'dejavusans',
                     'pdf.fonttype': 42,
                     'font.family': 'Arial'})

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.16, 1.62),
                               gridspec_kw={'wspace': 0.22})
fig.subplots_adjust(left=0.072, right=0.988, bottom=0.275, top=0.880)

# ===== (a) 波数轴 =====
clean_d = base[np.array(D['grid']) == 0][0]
tol = 0.99 * clean_d
# 只用非负半轴（曲线对称），且必须含 0 点，否则 np.interp 会截断在 1 bin
sel = np.array(D['grid']) >= 0
xs = cm[sel]; ys = base[sel]
cross = float(np.interp(tol, ys[::-1], xs[::-1]))
ax1.axhline(tol, color='#7f8c8d', lw=0.6, ls=':', zorder=1)
ax1.axvline(cross, color='#7f8c8d', lw=0.6, ls=':', zorder=1)
ax1.plot(cm, base, '-o', ms=3.4, lw=1.3, color='#c0392b', label='no compensation', zorder=4)
ax1.plot(cm, alig, '--s', ms=3.0, lw=1.2, color='#1f6f8b', label='label-free', zorder=5)
ax1.plot(cm, aug, '-^', ms=2.9, lw=1.1, color='#e08e0b', label='augmented', zorder=3)
# 直接标注，避免图例遮挡陡升的红线
ax1.legend(loc='lower center', fontsize=7.2, frameon=True, framealpha=0.95,
           edgecolor='none', handlelength=1.6, borderaxespad=0.30, labelspacing=0.26)
ax1.text(cross+0.35, 0.905, '$\\pm$%.1f' % cross, fontsize=7.2, color='#5d6d7e',
         ha='left', va='bottom')
ax1.set_xlim(-9.8, 9.8); ax1.set_ylim(0.0, 1.06)
ax1.set_xlabel('axis offset (cm$^{-1}$)')
ax1.set_ylabel('presence F1')
ax1.set_title('(a) wavenumber-axis drift', fontsize=8.5, pad=3)
for s in ['top', 'right']:
    ax1.spines[s].set_visible(False)

# ===== (b) 分辨率 =====
ax2.axhline(clean, color='#7f8c8d', lw=0.6, ls=':', zorder=1)
ax2.plot(tot, lb, '-^', ms=3.5, lw=1.1, color='#2e8b57',
         label='library broadened', zorder=3)
ax2.plot(tot, mt, '--s', ms=2.9, lw=4.2, color='#8e44ad', alpha=0.40,
         label='both (matched)', zorder=2)
ax2.plot(tot_d, db, '-o', ms=2.6, lw=1.1, color='#c0392b',
         label='sample broadened', zorder=5)
ax2.plot(tot_d, dd, '-D', ms=3.1, lw=1.2, color='#1f6f8b',
         label='sample + deconv.', zorder=4)
ax2.set_xlim(15, 38.5); ax2.set_ylim(0.40, 0.945)
ax2.set_xlabel('sample FWHM (cm$^{-1}$)')
ax2.set_ylabel('presence F1')
ax2.set_title('(b) spectral resolution', fontsize=8.5, pad=3)
ax2.legend(loc='lower left', fontsize=7.2, frameon=False,
           handlelength=1.7, borderaxespad=0.25, labelspacing=0.26)
ax2.text(15.5, clean - 0.030, 'clean library', fontsize=7.2, color='#5d6d7e', ha='left', va='top')
for s in ['top', 'right']:
    ax2.spines[s].set_visible(False)

fig.savefig('fig_budget_final.pdf')
fig.savefig('fig_budget_final.png', dpi=600)
print('SAVED fig_budget_final.pdf/.png')
print('drift tol %.2f cm-1 | res clean %.4f lib %.4f sample %.4f deconv %.4f'
      % (cross, clean, lb[-1], sa[-1], dd[-1]))
