# -*- coding: utf-8 -*-
"""
在实测波数漂移分布下评估已训练模型（base / aug 两个 checkpoint 通用）。

漂移分布来自 _scratch/empirical_shift_cm.npy：RRUFF 中同矿物、532nm、不同样品的
1143 对谱，经互相关对齐得到的峰位偏移（cm-1）。取绝对值、随机正负号后换算成 bin
(1 bin = 1.3685 cm-1)，用线性插值实现亚 bin 平移。

用法: python eval_empirical_drift.py drift600_base
"""
import sys, os, json
import numpy as np

CKPT = sys.argv[1] if len(sys.argv) > 1 else 'drift600_base'
N_TEST = int(os.environ.get('N_TEST', 5000))
CACHE = '_scratch/lib_R_v2.npy'

# ---- 复用 train_drift_full.py 的库构建/模型/生成函数，保证完全一致 ----
src = open('train_drift_full.py', encoding='utf-8').read()
head = src.split("class ContrastiveLoss")[0]
head = head.replace("print('[1/4] building library...',flush=True)", "")
_argv = sys.argv; sys.argv = ['train_drift_full.py', 'base']
ns = {}
exec(compile(head, 'head', 'exec'), ns)
sys.argv = _argv

if os.path.exists(CACHE):
    R = np.load(CACHE)
    print(f'载入缓存库 {CACHE} {R.shape}', flush=True)
else:
    R = ns['R']
    np.save(CACHE, R)
    print(f'构建并缓存库 {R.shape}', flush=True)

NWP = ns['NWP']; K = ns['K']; CWN = ns['CWN']
BIN = float(CWN[1] - CWN[0])
print(f'1 bin = {BIN:.4f} cm-1', flush=True)

gen = ns['gen']; _renorm = ns['_renorm']
TSRAMNet = ns['TSRAMNet']; shift_bins = ns['shift_bins']; stretch_axis = ns['stretch_axis']

import torch, torch.nn.functional as F
from sklearn.metrics import f1_score
DEV = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

model = TSRAMNet().to(DEV)
sd = torch.load(f'{CKPT}_best_model.pth', map_location=DEV)
model.load_state_dict(sd)
ref_t = torch.from_numpy(R).to(DEV)
model.update_ref(ref_t)
model.eval()                      # 必须在 update_ref 之后（update_ref 末尾会置 train）

Xd, ypd, yad = gen(N_TEST, 100, aug=False, std=0.01)

def shift_frac(X, b):
    """亚 bin 平移：out[i] = X[i-b]，b 可为小数，越界补零。"""
    n = len(X); b = np.asarray(b, np.float64)
    idx = np.arange(NWP)[None, :] - b[:, None]
    i0 = np.floor(idx); i1 = i0 + 1.0
    w = (idx - i0).astype(np.float32)
    r = np.arange(n)[:, None]
    v0 = (i0 >= 0) & (i0 < NWP); v1 = (i1 >= 0) & (i1 < NWP)
    X0 = np.where(v0, X[r, np.clip(i0, 0, NWP-1).astype(int)], 0.0)
    X1 = np.where(v1, X[r, np.clip(i1, 0, NWP-1).astype(int)], 0.0)
    return _renorm((X0*(1-w) + X1*w).astype(np.float32))

def evaluate(X):
    P = []; AB = []
    with torch.no_grad():
        for j in range(0, len(X), 512):
            pl, ab, _, _ = model(torch.from_numpy(X[j:j+512]).to(DEV))
            P.append((torch.sigmoid(pl) > .5).float().cpu().numpy()); AB.append(ab.cpu().numpy())
    P, AB = np.concatenate(P), np.concatenate(AB)
    f1 = float(f1_score(ypd, P, average='samples', zero_division=0))
    cos = float(((AB*yad).sum(1) / np.maximum(np.linalg.norm(AB, axis=1)*np.linalg.norm(yad, axis=1), 1e-10)).mean())
    return f1, cos

print('\n=== 确定性扰动 ===', flush=True)
conds = [('clean', Xd),
         ('shift 1', shift_bins(Xd, np.full(len(Xd), 1))),
         ('shift 2', shift_bins(Xd, np.full(len(Xd), 2))),
         ('shift 3', shift_bins(Xd, np.full(len(Xd), 3))),
         ('shift 5', shift_bins(Xd, np.full(len(Xd), 5))),
         ('stretch 0.5%', stretch_axis(Xd, np.full(len(Xd), 0.005))),
         ('stretch 1%', stretch_axis(Xd, np.full(len(Xd), 0.010)))]
det = {}
base = None
for name, Xc in conds:
    f1, cos = evaluate(Xc)
    if base is None: base = (f1, cos)
    det[name] = {'F1': round(f1, 4), 'cosine': round(cos, 4), 'dF1': round(f1-base[0], 4), 'dcos': round(cos-base[1], 4)}
    print(f'  {name:<14s} F1 {f1:.4f} ({det[name]["dF1"]:+.4f})  cos {cos:.4f} ({det[name]["dcos"]:+.4f})', flush=True)

print('\n=== 实测漂移分布下（绝对值 + 随机正负号，亚 bin）===', flush=True)
emp = np.load('_scratch/empirical_shift_cm.npy')
emp = np.abs(emp)
rng = np.random.RandomState(7)
reps = []
for k in range(3):
    d = emp[rng.randint(0, len(emp), N_TEST)] * rng.choice([-1.0, 1.0], N_TEST)
    b = d / BIN
    f1, cos = evaluate(shift_frac(Xd, b))
    reps.append((f1, cos))
    print(f'  第{k+1}次采样: F1 {f1:.4f}  cos {cos:.4f}', flush=True)
f1e, cose = float(np.mean([r[0] for r in reps])), float(np.mean([r[1] for r in reps]))
print(f'  实测分布平均: F1 {f1e:.4f} (Δ{f1e-base[0]:+.4f})  cos {cose:.4f} (Δ{cose-base[1]:+.4f})', flush=True)

out = {'ckpt': CKPT, 'bin_cm': round(BIN, 4), 'deterministic': det,
       'empirical': {'F1': round(f1e, 4), 'cosine': round(cose, 4),
                     'dF1': round(f1e-base[0], 4), 'dcos': round(cose-base[1], 4),
                     'reps': [[round(a, 4), round(b_, 4)] for a, b_ in reps]},
       'n_pairs': int(len(emp))}
json.dump(out, open(f'_scratch/drift_eval_{CKPT}.json', 'w'), indent=2)
print(f'\nSAVED _scratch/drift_eval_{CKPT}.json')
