"""
TSRAM-Net architecture figure, v9.

Design constraint: drawn at the FINAL printed size (7.16 x 2.95 in = \\textwidth),
so every label is a true 7 pt on paper.  v7 was drawn on a 13-in canvas at 9 pt
and then scaled by 0.36, which put its labels at 2.5-3.3 pt -- unreadable.

Fixes over v7:
  * shared encoder is one tall block straddling both inputs (v7 drew two separate boxes)
  * the two streams get distinct colours (v7 used the same lavender for both)
  * no floating annotations: temperatures live in the retrieval box, refiner in its head
  * right-hand column shows support size K -> 145 -> 1-2, which is the actual mechanism
"""
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from matplotlib.patches import Rectangle, FancyArrowPatch

plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
    'font.size': 8,
    'mathtext.fontset': 'dejavusans',
    'pdf.fonttype': 42,
    'svg.fonttype': 'none',
})

W, H = 7.16, 2.57
fig = plt.figure(figsize=(W, H))
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, W)
ax.set_ylim(0.03, 2.60)
ax.axis('off')

EDGE = '#37474F'
C_IN = '#E9EFF7'
C_ENC = '#E4EFE7'
C_RET = '#FBEFE0'
C_P = '#DCE9F6'
C_A = '#FAE2DA'
C_TXT = '#16232A'
STROKE = [pe.withStroke(linewidth=2.2, foreground='white')]


def box(x, y, w, h, fc, lw=0.8, ls='-', z=2):
    ax.add_patch(Rectangle((x, y), w, h, facecolor=fc, edgecolor=EDGE,
                           linewidth=lw, linestyle=ls, zorder=z))


def txt(x, y, s, fs=8, w='normal', c=C_TXT, ha='center', va='center', z=6, stroke=False):
    t = ax.text(x, y, s, fontsize=fs, fontweight=w, color=c, ha=ha, va=va,
                zorder=z, linespacing=1.5)
    if stroke:
        t.set_path_effects(STROKE)


def arr(x1, y1, x2, y2, lw=0.9, ls='-', c=EDGE):
    ax.add_patch(FancyArrowPatch(
        (x1, y1), (x2, y2),
        arrowstyle='-|>,head_width=0.22,head_length=0.42',
        color=c, linewidth=lw, linestyle=ls,
        mutation_scale=6, shrinkA=0, shrinkB=0, zorder=3))


# ---------------- inputs ----------------
box(0.05, 1.90, 0.86, 0.56, C_IN)
txt(0.48, 2.18, 'Mixture\n$x\\in\\mathbb{R}^{1024}$')

box(0.05, 0.50, 0.86, 0.56, C_IN)
txt(0.48, 0.78, 'Library\n$R\\in\\mathbb{R}^{K\\times1024}$')

arr(0.91, 2.18, 1.09, 2.18)
arr(0.91, 0.78, 1.09, 0.78)

# ---------------- shared encoder ----------------
box(1.09, 0.42, 1.08, 2.12, C_ENC)
txt(1.63, 2.02, 'Shared encoder', 8, 'bold')
txt(1.63, 1.66, '$f_\\theta$', 8)
txt(1.63, 1.30, '3$\\times$ residual block', 7.5)
txt(1.63, 0.94, 'L2-normalised', 7.5)

# encoder -> retrieval
arr(2.17, 2.18, 2.38, 1.76)
arr(2.17, 0.78, 2.38, 1.20)
txt(2.24, 2.27, '$q$', 8, ha='left', stroke=True)
txt(2.24, 0.70, '$M$', 8, ha='left', stroke=True)

# ---------------- retrieval ----------------
box(2.38, 1.02, 1.46, 0.92, C_RET, lw=1.0)
txt(3.11, 1.72, '$s=q^{\\top}M\\in\\mathbb{R}^{K}$', 8)
txt(3.11, 1.46, '$\\alpha^{p}=\\mathrm{Softmax}(s/T_p)$', 8)
txt(3.11, 1.20, '$\\alpha^{i}=\\mathrm{Sparsemax}(s/T_a)$', 8)

# retrieval -> heads
arr(3.84, 1.72, 4.06, 2.09)
arr(3.84, 1.24, 4.06, 0.75)
txt(3.89, 1.94, '$\\alpha^{p}$', 8, ha='left', stroke=True)
txt(3.89, 0.96, '$\\alpha^{i}$', 8, ha='left', stroke=True)

# ---------------- presence stream ----------------
box(4.06, 1.62, 1.26, 0.94, C_P)
txt(4.69, 2.36, 'Presence head', 8, 'bold')
txt(4.69, 2.18, '$c_p=M^{\\top}\\alpha^{p}$', 8)
txt(4.69, 2.00, '$[q;\\,c_p]\\to$ MLP', 8)
txt(4.69, 1.82, '$\\hat{p}\\in[0,1]^{K}$', 8)

# ---------------- abundance stream ----------------
box(4.06, 0.28, 1.26, 0.94, C_A)
txt(4.69, 1.01, 'Refiner $g$', 8, 'bold')
txt(4.69, 0.83, '$\\delta=g([q;c_i;q-c_i])$', 8)
txt(4.69, 0.65, '$z_a=s_s s+\\delta$', 8)
txt(4.69, 0.47, '$a=\\mathrm{Sparsemax}(z_a/T_a)$', 8)

# ---------------- support-size column ----------------
box(5.40, 0.74, 1.70, 1.56, '#FFFFFF', lw=0.6, ls=(0, (3, 2)), z=1)
txt(6.25, 2.42, 'output support', 8, 'bold')

N = 30
GAP = 0.006
BX, BW = 5.74, 0.82


def spark(y, lit, color, label, value):
    cw = (BW - GAP * (N - 1)) / N
    for i in range(N):
        fc = color if i < lit else '#F0F2F4'
        ax.add_patch(Rectangle((BX + i * (cw + GAP), y), cw, 0.11,
                               facecolor=fc, edgecolor='none', zorder=4))
    ax.add_patch(Rectangle((BX, y), BW, 0.11, facecolor='none',
                           edgecolor='#B0BEC5', linewidth=0.5, zorder=5))
    txt(5.68, y + 0.055, label, 8.5, ha='right')
    txt(6.60, y + 0.055, value, 8.5, ha='left')


spark(2.03, 30, '#7FA8CC', '$\\hat{p}$', 'dense')
spark(1.45, 5, '#E0A98E', '$\\alpha^{i}$', '145')
spark(0.87, 1, '#C9563B', '$a$', '1--2')

# ---------------- training note ----------------
txt(0.05, 0.12,
    'Training:  $\\mathcal{L}_{\\mathrm{cont}}$ on $\\hat{p}$  $+$  $\\|a-a^{*}\\|^{2}$ on $a$'
    '        $\\rightarrow$  fixed non-negative $\\ell_1$ refinement (training-free)',
    7.5, c='#455A64', ha='left')

fig.savefig('architecture_figure_v9.pdf')
fig.savefig('architecture_figure_v9.png', dpi=600)
print('saved architecture_figure_v9.pdf / .png  (%.2f x %.2f in)' % (W, H))
