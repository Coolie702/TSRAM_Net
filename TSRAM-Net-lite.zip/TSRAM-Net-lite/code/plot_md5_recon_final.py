"""
Fig.5 生成（v4bg 版）：MD5 真实二元混合的谱重建对比（measured / FCLS / TSRAM-Net v4bg）
- 归一化空间、相同参考谱与散射系数（md5v4bg_scatter_coeffs.npy），三方同口径。
- TSRAM-Net v4bg：BackgroundNet 显式估计荧光/散射背景；检索与丰度在背景校正谱上进行。
  图中 TSRAM 完整重建 = 线性部分 (ab @ scatter_ref) + 估计背景 (bg_net)，展示显式背景建模的收益。
- FCLS：相同散射加权参考谱上的全库 NNLS（无背景建模）。
- 次要组分约 5% / 20% / 50% 三条代表性二元混合。
输出：md5_spectral_reconstruction_fcls.png（覆盖论文 Fig.5）
"""
import os
import io, json
import numpy as np
import pandas as pd
import torch
from scipy.interpolate import interp1d
from scipy.signal import savgol_filter
from scipy.optimize import nnls as nnls_fn
import matplotlib
matplotlib.use('Agg')
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
import matplotlib.pyplot as plt

DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
print('Device:', DEVICE)

# ---- 复用 train_md5_v4_bg.py 的数据准备 + 模型类（含 BackgroundNet）----
path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'train_md5_v4_bg.py')
lines = io.open(path, encoding='utf-8').read().split('\n')
ns = {}
exec(compile('\n'.join(lines[:486]), path, 'exec'), ns)
WMIN, WMAX, NPT = ns['WAVENUMBER_MIN'], ns['WAVENUMBER_MAX'], ns['N_WAVENUMBER_POINTS']
COMMON = ns['COMMON_WAVENUMBER']

model = ns['TwoStreamRetrievalModelV2'](
    ns['N_MINERALS'], ns['FEATURE_DIM'], ns['TEMPERATURE_INIT'],
    ns['TEMPERATURE_INIT'] * 0.75, scatter_coeffs=ns['SCATTER_COEFFS']).to(DEVICE)
model.load_state_dict(torch.load(ns['OUT_PREFIX'] + '_best_model.pth', map_location=DEVICE))
model.eval()
with torch.no_grad():
    model.update_ref_features(ns['reference_tensor'].to(DEVICE))
model.eval()

TH = json.load(open('md5v4bg_authoritative.json', encoding='utf-8'))['presence_threshold']
print('presence threshold =', TH)

X = ns['X_real']; MINERALS = ns['MINERALS']
y_abun = ns['y_abun_real']
SCAT = np.load('md5v4bg_scatter_coeffs.npy').astype(np.float32)
ref = ns['reference_spectra'].astype(np.float32)
scatter_ref = (SCAT[:, None] * ref).astype(np.float32)

# TSRAM 推理（BN eval）+ 背景估计
with torch.no_grad():
    pl, ab, _, _ = model(torch.from_numpy(X).to(DEVICE))
    bg = model.bg_net(torch.from_numpy(X).to(DEVICE)).cpu().numpy()
probs = torch.sigmoid(pl).cpu().numpy(); tsram_ab = ab.cpu().numpy()
pres = (probs > TH).astype(float)
for i in np.where(pres.sum(1) >= 2)[0]:
    det = pres[i] > .5; mass = tsram_ab[i, det]
    if mass.sum() > 1e-8:
        tsram_ab[i] = 0.0; tsram_ab[i, det] = mass / mass.sum()

# FCLS（相同散射加权参考谱，归一化空间全库 NNLS）
fcls_ab = np.zeros((len(X), len(MINERALS)))
for i in range(len(X)):
    c, _ = nnls_fn(scatter_ref.T, X[i]); t = c.sum()
    if t > 1e-12: fcls_ab[i] = c / t

n_comp = (y_abun > 0).sum(1)
mix_idx = np.where(n_comp >= 2)[0]
minor = np.full(len(X), np.nan)
for i in mix_idx:
    v = y_abun[i][y_abun[i] > 0]; minor[i] = v.min() * 100.0


def mm(v):
    lo, hi = v.min(), v.max()
    return (v - lo) / (hi - lo + 1e-12)


picks = []
for target in [5, 20, 50]:
    cand = mix_idx[np.nanargmin(np.abs(minor[mix_idx] - target))]
    picks.append(int(cand))

fig, axes = plt.subplots(1, 3, figsize=(5.87, 1.80), sharey=True)
for ax, idx in zip(axes, picks):
    active = np.where(y_abun[idx] > 0)[0]
    names = [f'{MINERALS[k]} {int(round(y_abun[idx, k]*100))}%' for k in active]
    measured = X[idx]
    fcls_rec = mm(fcls_ab[idx] @ scatter_ref)
    # v4bg：显式背景 + 线性部分 = 完整重建
    lin = tsram_ab[idx] @ scatter_ref
    tsram_rec = mm(lin + bg[idx])
    ax.plot(COMMON, measured, color='black', lw=0.9, label='Measured')
    ax.plot(COMMON, fcls_rec, color='#d95f02', ls='--', lw=0.8, label='FCLS')
    ax.plot(COMMON, tsram_rec, color='#1b9e77', ls='--', lw=0.8,
            label='TSRAM-Net (linear + bg)')
    rf = np.sqrt(np.mean((fcls_rec - measured) ** 2))
    rt = np.sqrt(np.mean((tsram_rec - measured) ** 2))
    nF = int((fcls_ab[idx] > 0.01).sum()); nT = int((tsram_ab[idx] > 0.01).sum())
    ax.set_title(' + '.join(names), fontsize=6.0, pad=2.0)
    print('  panel %s: FCLS RMSE %.3f (%d em), TSRAM RMSE %.3f (%d em), true %d'
          % ('+'.join(names), rf, nF, rt, nT, len(active)))
    ax.set_xlabel('Raman shift (cm$^{-1}$)', fontsize=6.5, labelpad=1.5)
    ax.tick_params(labelsize=5.8, length=2, width=0.5)
    ax.grid(alpha=.3, lw=0.4)
axes[0].set_ylabel('Normalized intensity (offset)', fontsize=6.5, labelpad=1.5)
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc='upper center', ncol=3, fontsize=5.8, frameon=False,
           handlelength=1.5, columnspacing=1.4, handletextpad=0.4,
           bbox_to_anchor=(0.5, 0.995))
fig.subplots_adjust(left=0.072, right=0.995, bottom=0.215, top=0.795, wspace=0.075)
fig.savefig('fig_md5_recon_final.pdf')
fig.savefig('fig_md5_recon_final.png', dpi=600)
print('已保存 fig_md5_recon_final.pdf | picks =', picks,
      '| minor =', [int(round(minor[i])) for i in picks],
      '| FCLS endmembers >1%:', [int((fcls_ab[i] > 0.01).sum()) for i in picks])
