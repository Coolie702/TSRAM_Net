# -*- coding: utf-8 -*-
"""
Deep-backbone + dense-head baselines (reviewer-driven experiment)
=================================================================
Question: is the failure of dense K-way heads caused by the HEAD or by the
weak MLP backbone?  TSRAM-Net vs MLPDense confounds the two.

This script holds the dense head FIXED (identical to MLPDense in
kscale_experiment_v4.py) and swaps only the encoder:

  CNNDense   : 1D CNN encoder (4 conv stages, ~1.3M params) + dense K-way head
  TransDense : Transformer patch encoder (same as v4) + dense K-way head

Everything else is byte-identical to the v4 protocol: same RALL library, same
gen(), 50k train / 10k val, AdamW 8e-4, 600-epoch cap, early stop on the fixed
1%-noise validation set (patience 12 x 5ep), same 3x3000 test sets, same
threshold-0.5 metric code (evaluate()).

Usage:  python baseline_deep_dense.py <K> <MODEL> [<MODEL> ...]
        python baseline_deep_dense.py 1000 CNNDense TransDense
"""
import io, os, sys, json, time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
import torch.optim as optim

# ---- reuse the v4 harness verbatim (data, gen, encoders, evaluate, protocol) ----
P = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'kscale_experiment_v4.py')
lines = io.open(P, encoding='utf-8').read().split('\n')
cut = next(i for i, l in enumerate(lines) if l.startswith('MODELS ='))
ns = {}
_saved_argv = sys.argv[:]
sys.argv = [P]          # v4 parses sys.argv for KS; hide our own arguments from it
exec(compile('\n'.join(lines[:cut]), P, 'exec'), ns)
sys.argv = _saved_argv

RALL = ns['RALL']; gen = ns['gen']; evaluate = ns['evaluate']; val_f1 = ns['val_f1']
MLPEnc = ns['MLPEnc']; TransformerEnc = ns['TransformerEnc']; MLPDense = ns['MLPDense']
DEV = ns['DEV']; NWP = ns['NWP']; DIM = ns['DIM']
MAX_EP, BATCH, N_TRAIN, N_VAL, LR = ns['MAX_EP'], ns['BATCH'], ns['N_TRAIN'], ns['N_VAL'], ns['LR']
PATIENCE, VAL_EVERY = ns['PATIENCE'], ns['VAL_EVERY']

OUT = 'baseline_deep_dense.json'


class CNNEnc(nn.Module):
    """1D CNN over the 1024-point spectrum. Same output contract as MLPEnc:
    L2-normalised DIM-d embedding. Deliberately given >= MLPEnc capacity."""
    def __init__(s):
        super().__init__()
        def blk(i, o, k=9, st=2):
            return nn.Sequential(nn.Conv1d(i, o, k, st, k // 2), nn.BatchNorm1d(o), nn.ReLU(inplace=True))
        s.net = nn.Sequential(
            blk(1, 64), blk(64, 128), blk(128, 128), blk(128, 256),
            blk(256, 256, 5, 1), blk(256, 256, 5, 1),
            nn.AdaptiveAvgPool1d(1),
        )
        s.proj = nn.Linear(256, DIM)

    def forward(s, x):
        h = s.net(x.unsqueeze(1)).squeeze(-1)
        return F.normalize(s.proj(h), p=2, dim=-1)


class DenseNet(nn.Module):
    """Identical dense head to MLPDense, encoder is a constructor argument."""
    def __init__(s, K, encoder):
        super().__init__()
        s.encoder = encoder
        s._bridge = nn.Sequential(nn.Linear(DIM, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(.2),
                                  nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU())
        s.pres_head = nn.Sequential(nn.Linear(256, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(.2),
                                    nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Linear(256, K))
        s.abun_head = nn.Linear(256, K)

    def forward(s, x):
        h = s._bridge(s.encoder(x))
        return s.pres_head(h), F.softmax(s.abun_head(h), -1)


class CNNEncV2(nn.Module):
    """Fair CNN encoder. v1 failed (cos 0.875) because global average pooling
    discarded peak POSITION, which is the whole fingerprint. v2 keeps more
    spatial resolution, pools with avg+max, and adds a residual MLP head so its
    capacity matches MLPEnc (~3.1M)."""
    def __init__(s):
        super().__init__()
        def blk(i, o, k, st, d=1):
            return nn.Sequential(nn.Conv1d(i, o, k, st, k // 2, dilation=d),
                                 nn.BatchNorm1d(o), nn.ReLU(inplace=True))
        s.net = nn.Sequential(
            blk(1, 64, 7, 2), blk(64, 128, 7, 2), blk(128, 256, 7, 2),   # 1024 -> 128
            blk(256, 256, 5, 1), blk(256, 256, 5, 1, d=2),                # keep 128, widen RF
        )
        s.fc1 = nn.Linear(512, DIM); s.bn1 = nn.BatchNorm1d(DIM)
        s.fc2 = nn.Linear(DIM, DIM)

    def forward(s, x):
        h = s.net(x.unsqueeze(1))
        h = torch.cat([h.mean(-1), h.amax(-1)], -1)          # avg + max: keeps "a peak like this exists"
        h = F.relu(s.bn1(s.fc1(h)))
        h = s.fc2(h) + h
        return F.normalize(h, p=2, dim=-1)


def make(name, K):
    if name == 'CNNDense':
        return DenseNet(K, CNNEnc()), 'bce'
    if name == 'CNNDenseV2':
        return DenseNet(K, CNNEncV2()), 'bce'
    if name == 'TransDense':
        return DenseNet(K, TransformerEnc()), 'bce'
    if name == 'CNNRet':
        return ns['RetrievalNet'](K, CNNEncV2()), 'contrast'
    if name == 'MLPDense':
        return MLPDense(K), 'bce'
    raise ValueError(name)


def count(m):
    return sum(p.numel() for p in m.parameters())


if __name__ == '__main__':
    K = int(sys.argv[1])
    names = sys.argv[2:]
    res = json.load(open(OUT)) if os.path.exists(OUT) else {}
    res.setdefault(str(K), {})
    print(f'Device {DEV} | K={K} | models={names}', flush=True)

    Xtr, yptr, yatr = gen(N_TRAIN, K, 1)
    Xva, ypva, _ = gen(N_VAL, K, 2, aug=False, std=0.01)
    ref_t = torch.from_numpy(RALL[:K]).to(DEV)
    tr = DataLoader(TensorDataset(torch.from_numpy(Xtr), torch.from_numpy(yptr), torch.from_numpy(yatr)),
                    batch_size=BATCH, shuffle=True)
    print(f'data ready: train {Xtr.shape} val {Xva.shape}', flush=True)

    for name in names:
        if name in res[str(K)]:
            print(f'  {name} already done, skip', flush=True); continue
        print(f'\n===== K={K}  {name} =====', flush=True)
        torch.manual_seed(42); np.random.seed(42)
        model, kind = make(name, K); model.to(DEV)
        if hasattr(model, 'update_ref'): model.update_ref(ref_t)
        print(f'  params {count(model):,}', flush=True)
        bce = nn.BCEWithLogitsLoss(); cont = ns['ContrastiveLoss']()
        opt = optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-4)
        sch = optim.lr_scheduler.CosineAnnealingLR(opt, T_max=MAX_EP)
        best_f1, best_state, wait, best_ep = -1.0, None, 0, 0
        t0 = time.time()
        for ep in range(MAX_EP):
            if hasattr(model, 'update_ref'): model.update_ref(ref_t)
            model.train()
            for xb, pb, ab_ in tr:
                xb, pb, ab_ = xb.to(DEV), pb.to(DEV), ab_.to(DEV)
                pl, ab = model(xb)
                loss = (cont(pl, pb) if kind == 'contrast' else bce(pl, pb)) + F.mse_loss(ab, ab_)
                opt.zero_grad(); loss.backward(); opt.step()
            sch.step()
            if (ep + 1) % VAL_EVERY == 0:
                if hasattr(model, 'update_ref'): model.update_ref(ref_t)
                f1v = val_f1(model, Xva, ypva)
                if f1v > best_f1 + 1e-4:
                    best_f1, wait, best_ep = f1v, 0, ep + 1
                    best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
                else:
                    wait += 1
                print(f'  ep{ep+1:3d} valF1 {f1v:.4f} best {best_f1:.4f}@{best_ep} '
                      f'wait {wait}/{PATIENCE} {(time.time()-t0)/60:.1f}min', flush=True)
                if wait >= PATIENCE:
                    print(f'  early stop at ep{ep+1}', flush=True); break
        if best_state is not None:
            model.load_state_dict(best_state)
        if hasattr(model, 'update_ref'): model.update_ref(ref_t)
        met = evaluate(model, K)
        met['best_epoch'] = best_ep
        met['train_min'] = round((time.time() - t0) / 60, 1)
        met['params'] = count(model)
        res[str(K)][name] = met
        print(f"  -> {name} K={K} | clean F1 {met['noise_0']['F1']:.4f} "
              f"| 1% F1 {met['noise_0.01']['F1']:.4f} | cos {met['noise_0.01']['cos']:.4f}", flush=True)
        json.dump(res, open(OUT, 'w'), indent=2)
    print('\nDONE', flush=True)
