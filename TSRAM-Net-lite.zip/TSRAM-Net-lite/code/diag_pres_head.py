# -*- coding: utf-8 -*-
"""
Diagnostic: is the *presence branch* the weak link, or is retrieval itself weak?

The paper's presence branch is `pres_head([Q, Ap @ ref])` -> K logits, i.e. a dense
K-way classifier on a single globally pooled vector. The abundance branch, by contrast,
is per-candidate (coarse retrieval -> refiner -> sparsemax). This script asks whether
that asymmetry explains why detection F1 degrades with K while abundance cosine does not.

Protocol: encoder frozen from _ckpt_TSRAM_K1000.pt (so both variants see identical
features), K=1900, same train/val/test seeds and noise as kscale_experiment_v4.py.
Two presence heads are trained on the cached features with the identical contrastive
loss and schedule:

  A  pooled    : [Q, softmax(Q ref^T / Tp) @ ref] -> MLP -> K logits   (current design)
  B  retrieval : (Q W) @ ref^T * s                                     (per-candidate)

If B >> A, the presence branch -- not the retrieval idea -- is what costs detection.
"""
import os
import io, sys, json, time
import numpy as np
import torch, torch.nn as nn, torch.nn.functional as F, torch.optim as optim
from sklearn.metrics import f1_score, average_precision_score

V4 = 'kscale_experiment_v4.py'
CKPT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'checkpoints', '_ckpt_TSRAM_K1000.pt')
K = 1900
MAXEP, PAT, VALEVERY, BATCH, LR = 200, 20, 5, 256, 8e-4


def prelude(path, cutpat):
    lines = io.open(path, encoding='utf-8').read().split('\n')
    cut = next(i for i, l in enumerate(lines) if l.startswith(cutpat))
    ns = {}
    a = sys.argv[:]; sys.argv = [path]
    exec(compile('\n'.join(lines[:cut]), path, 'exec'), ns)
    sys.argv = a
    return ns


print('loading v4 prelude (parses the reference library) ...', flush=True)
ns = prelude(V4, 'MODELS =')
RALL, gen = ns['RALL'], ns['gen']
MLPEnc, ContrastiveLoss, DIM = ns['MLPEnc'], ns['ContrastiveLoss'], ns['DIM']
DEV = torch.device('cpu')

ck = torch.load(CKPT, map_location='cpu')
enc = MLPEnc()
enc.load_state_dict({k[len('encoder.'):]: v for k, v in ck.items() if k.startswith('encoder.')})
enc.eval()
for p in enc.parameters():
    p.requires_grad_(False)
Tp = float(torch.exp(ck['log_Tp']))
print('encoder loaded, Tp=%.3f' % Tp, flush=True)


@torch.no_grad()
def feat(X):
    out = []
    for j in range(0, len(X), 1024):
        out.append(enc(torch.from_numpy(np.ascontiguousarray(X[j:j + 1024]))))
    return torch.cat(out)


t0 = time.time()
ref = feat(RALL[:K])
Xtr, yptr, _ = gen(ns['N_TRAIN'], K, 1)
Xva, ypva, _ = gen(ns['N_VAL'], K, 2, aug=False, std=0.01)
Qtr, Qva = feat(Xtr), feat(Xva)
TESTS = []
for ti in range(3):
    Xt, yt, _ = gen(3000, K, 300 + ti, aug=False, std=0.01)
    TESTS.append((feat(Xt), yt))
ytr_t = torch.from_numpy(yptr)
yva_t = torch.from_numpy(ypva)
print('features cached in %.0fs  Qtr %s  ref %s' % (time.time() - t0, tuple(Qtr.shape), tuple(ref.shape)), flush=True)


class Pooled(nn.Module):
    """Current design: global softmax-pooled context, dense K-way output."""
    def __init__(s, K, d=DIM):
        super().__init__()
        s.ref = ref
        s.Tp = Tp
        s.h = nn.Sequential(nn.Linear(2 * d, 512), nn.BatchNorm1d(512), nn.ReLU(), nn.Dropout(.3),
                            nn.Linear(512, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(.2),
                            nn.Linear(256, K))

    def forward(s, q):
        wp = torch.softmax((q @ s.ref.T) / s.Tp, -1) @ s.ref
        return s.h(torch.cat([q, wp], -1))


class Retrieval(nn.Module):
    """Per-candidate: learn a query projection, score every reference by inner product."""
    def __init__(s, ref, d=DIM):
        super().__init__()
        s.ref = ref
        s.W = nn.Linear(d, d, bias=False)
        nn.init.eye_(s.W.weight)
        s.scale = nn.Parameter(torch.tensor(10.0))

    def forward(s, q):
        z = F.normalize(s.W(q), p=2, dim=-1)
        return (z @ s.ref.T) * s.scale


@torch.no_grad()
def f1_of(model, Q, y):
    model.eval()
    P = torch.cat([model(Q[j:j + 1024]) for j in range(0, len(Q), 1024)])
    return f1_score(y, (torch.sigmoid(P) > .5).numpy(), average='samples', zero_division=0)


@torch.no_grad()
def ap_of(model, Q, y):
    """Threshold-free ranking quality, used for model selection so that a head whose
    logits are offset (as a pure inner-product head is) is not penalised twice."""
    model.eval()
    P = torch.cat([model(Q[j:j + 1024]) for j in range(0, len(Q), 1024)])
    return average_precision_score(y.ravel(), torch.sigmoid(P).numpy().ravel())


@torch.no_grad()
def logits_of(model, Q):
    model.eval()
    return torch.cat([model(Q[j:j + 1024]) for j in range(0, len(Q), 1024)])


def f1_at(prob, y, thr):
    return f1_score(y, (prob > thr), average='samples', zero_division=0)


def tune_thr(prob, y):
    """Pick the decision threshold on the validation split; the contrastive loss is
    invariant to a constant shift of the logits, so the 0.5 cut is not learned."""
    flat = prob.ravel()
    rs = np.random.RandomState(0)
    idx = rs.choice(len(flat), size=min(2_000_000, len(flat)), replace=False)
    cands = [0.5] + [float(q) for q in np.quantile(flat[idx], np.linspace(0.80, 0.999, 60))]
    best, bt = -1.0, 0.5
    for t in cands:
        v = f1_at(prob, y, t)
        if v > best:
            best, bt = v, t
    return bt, best


def train(model, tag):
    opt = optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-4)
    sch = optim.lr_scheduler.CosineAnnealingLR(opt, T_max=MAXEP)
    cont = ContrastiveLoss()
    best, bs, wait = -1.0, None, 0
    for ep in range(MAXEP):
        model.train()
        perm = torch.randperm(len(Qtr))
        for j in range(0, len(Qtr), BATCH):
            idx = perm[j:j + BATCH]
            if len(idx) < 8:
                continue
            loss = cont(model(Qtr[idx]), ytr_t[idx])
            opt.zero_grad(); loss.backward(); opt.step()
        sch.step()
        if (ep + 1) % VALEVERY == 0:
            ap = ap_of(model, Qva, ypva)
            f1 = f1_of(model, Qva, ypva)
            print('  [%s] ep %3d  valAP %.4f  valF1@0.5 %.4f  bestAP %.4f  %.0fs'
                  % (tag, ep + 1, ap, f1, best, time.time() - T0), flush=True)
            if ap > best + 1e-4:
                best, bs, wait = ap, {k: v.clone() for k, v in model.state_dict().items()}, 0
            else:
                wait += 1
                if wait >= PAT // VALEVERY:
                    break
    if bs:
        model.load_state_dict(bs)
    return best


res = {'K': K, 'Tp': Tp, 'val_ap': {}, 'test_f1': {}, 'test_f1_sets': {},
       'thr': {}, 'test_f1_tuned': {}, 'test_f1_tuned_sets': {}, 'logit_stats': {}}
T0 = time.time()
for name, ctor in [('A_pooled', lambda: Pooled(K)), ('B_retrieval', lambda: Retrieval(ref))]:
    t = time.time()
    m = ctor()
    v = train(m, name)
    Pva = torch.sigmoid(logits_of(m, Qva)).numpy()
    thr, v_tuned = tune_thr(Pva, ypva)
    fs = [f1_at(torch.sigmoid(logits_of(m, Q)).numpy(), y, 0.5) for Q, y in TESTS]
    fs_t = [f1_at(torch.sigmoid(logits_of(m, Q)).numpy(), y, thr) for Q, y in TESTS]
    res['val_ap'][name] = float(v)
    res['test_f1'][name] = float(np.mean(fs))
    res['test_f1_sets'][name] = [float(x) for x in fs]
    res['thr'][name] = float(thr)
    res['test_f1_tuned'][name] = float(np.mean(fs_t))
    res['test_f1_tuned_sets'][name] = [float(x) for x in fs_t]
    res['logit_stats'][name] = [float(Pva.mean()), float(Pva.std()),
                                float(Pva.min()), float(Pva.max())]
    print('%-12s valAP %.4f | F1@0.5 %.4f | thr %.3f -> F1 %.4f | %s | %.0fs'
          % (name, v, np.mean(fs), thr, np.mean(fs_t), np.round(fs_t, 4), time.time() - t),
          flush=True)
    torch.save(m.state_dict(), 'diag_%s.pt' % name)

json.dump(res, open('diag_pres_head.json', 'w'), indent=2)
print('saved diag_pres_head.json')
