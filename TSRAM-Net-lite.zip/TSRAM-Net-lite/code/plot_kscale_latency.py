# -*- coding: utf-8 -*-
"""
Fig. 2 (library-size scaling) with a third panel: single-sample CPU cost.

Panels (a) and (b) are unchanged from plot_figs_final.py. Panel (c) adds the
measured forward-pass latency against K (bench_latency_kscale.py) alongside the
two convex solvers (baseline_sunsal_kscale.json), on a log axis.
"""
import os
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams

rcParams.update({
    "font.family": "Arial",
    "font.size": 8.0,
    "axes.linewidth": 0.7,
    "xtick.major.width": 0.7,
    "ytick.major.width": 0.7,
    "xtick.major.size": 2.8,
    "ytick.major.size": 2.8,
    "xtick.labelsize": 7.5,
    "ytick.labelsize": 7.5,
    "legend.fontsize": 7.5,
    "axes.labelsize": 8.0,
    "axes.titlesize": 8.5,
    "mathtext.fontset": "dejavusans",
    "pdf.fonttype": 42,
    "svg.fonttype": "none",
})

C_TSRAM = "#d62728"
C_MLP = "#7f7f7f"
C_SUN = "#2ca02c"
C_FCLS = "#1f77b4"
W, H = 7.16, 1.50
STY = dict(lw=1.05, ms=3.2, mew=0.0)

kconv = json.load(open("baseline_sunsal_kscale.json", encoding="utf-8"))
klearn = json.load(open("kscale_v4_results.json", encoding="utf-8"))
klat = json.load(open("latency_kscale.json", encoding="utf-8"))

Ks = [20, 50, 100, 200, 500, 1000, 1500, 1900]
x = list(range(len(Ks)))


def learned(metric, model):
    return [klearn[str(k)][model]["noise_0.01"][metric] for k in Ks]


fig, (a1, a2, a3) = plt.subplots(1, 3, figsize=(W, H))
fig.subplots_adjust(left=0.058, right=0.995, bottom=0.225, top=0.895, wspace=0.30)

# ---- (a) detection F1
a1.plot(x, learned("F1", "TSRAM"), "-o", color=C_TSRAM, label="TSRAM-Net (learned)", **STY)
a1.plot(x, learned("F1", "MLP"), "--s", color=C_MLP, label="Dense MLP (learned)", **STY)
a1.plot(x, [kconv[str(k)]["sunsal"]["F1"] for k in Ks], "-^", color=C_SUN,
        label="SUnSAL (convex)", **STY)
a1.plot(x, [kconv[str(k)]["fcls"]["F1"] for k in Ks], "--D", color=C_FCLS,
        label="FCLS (convex)", **STY)
a1.set_xticks(x); a1.set_xticklabels([str(k) for k in Ks], fontsize=6.4)
a1.set_xlabel("Library size $K$", labelpad=1.5)
a1.set_ylabel("Presence F1", labelpad=1.5)
a1.set_title("(a) Detection F1", pad=2.5)
a1.set_ylim(0.70, 1.005)
a1.grid(True, ls=":", lw=0.5, alpha=0.6)
a1.legend(loc="lower left", frameon=True, framealpha=0.92, borderpad=0.25,
          labelspacing=0.2, handlelength=1.4, handletextpad=0.35, fontsize=7.2)

# ---- (b) abundance cosine
a2.plot(x, learned("cos", "TSRAM"), "-o", color=C_TSRAM, **STY)
a2.plot(x, learned("cos", "MLP"), "--s", color=C_MLP, **STY)
a2.plot(x, [kconv[str(k)]["sunsal"]["cosine"] for k in Ks], "-^", color=C_SUN, **STY)
a2.plot(x, [kconv[str(k)]["fcls"]["cosine"] for k in Ks], "--D", color=C_FCLS, **STY)
a2.set_xticks(x); a2.set_xticklabels([str(k) for k in Ks], fontsize=6.4)
a2.set_xlabel("Library size $K$", labelpad=1.5)
a2.set_ylabel("Abundance cosine", labelpad=1.5)
a2.set_title("(b) Abundance cosine", pad=2.5)
a2.set_ylim(0.85, 1.005)
a2.grid(True, ls=":", lw=0.5, alpha=0.6)

# ---- (c) single-sample CPU cost
lat = dict(zip(klat["K"], klat["ms_scaled"]))
a3.plot(x, [lat[k] for k in Ks], "-o", color=C_TSRAM, label="TSRAM-Net", **STY)
a3.plot(x, [kconv[str(k)]["sunsal"]["cpu_ms_per_sample"] for k in Ks], "-^",
        color=C_SUN, label="SUnSAL", **STY)
a3.plot(x, [kconv[str(k)]["fcls"]["cpu_ms_per_sample"] for k in Ks], "--D",
        color=C_FCLS, label="FCLS", **STY)
a3.set_yscale("log")
a3.set_xticks(x); a3.set_xticklabels([str(k) for k in Ks], fontsize=6.4)
a3.set_xlabel("Library size $K$", labelpad=1.5)
a3.set_ylabel("CPU time (ms)", labelpad=1.5)
a3.set_title("(c) Inference cost", pad=2.5)
a3.set_ylim(0.1, 600)
a3.grid(True, ls=":", lw=0.5, alpha=0.6, which="both")
a3.legend(loc="upper left", frameon=True, framealpha=0.92, borderpad=0.25,
          labelspacing=0.2, handlelength=1.4, handletextpad=0.35, fontsize=7.2)

fig.savefig("fig_kscale_final.pdf")
fig.savefig("fig_kscale_final.png", dpi=600)
plt.close(fig)
print("saved fig_kscale_final.pdf")
