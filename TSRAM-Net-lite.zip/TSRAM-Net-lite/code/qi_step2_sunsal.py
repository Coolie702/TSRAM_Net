# -*- coding: utf-8 -*-
"""
Qi Step2：14 条真实三元 + 1 月壤，零样本（不微调）在 K=1000 RRUFF 全库上解混。
  - FCLS（无超参，全库 NNLS+sum-to-one）
  - SUnSAL（非负 l1 ADMM，固定 λ=0.1，即论文合成基线已公布值；另报 0.03/0.3 敏感性）
检测：类别聚合（Fsp/Ol/Aug），看每类是否召回、有无误选族外矿物。
定量：类别丰度 vs 论文 Table2 的 wt%，报 cosine/MAE/排序；并给 σ 校正（Fsp:Ol:Aug=1.4:2.4:1）。
"""
import io, os, json
import numpy as np
import torch
from scipy.optimize import nnls

P = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ablation_full_v3.py')
lines = io.open(P, encoding='utf-8').read().split('\n')
cut = next(i for i, l in enumerate(lines) if l.startswith('ref_t ='))
ns = {}
exec(compile('\n'.join(lines[:cut]), P, 'exec'), ns)
R = ns['R']; K = ns['K']; topK = ns['topK']
DEV = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'Device {DEV} K={K}')

# 核心族（id 由 step1 打印确认）
Fsp = [17, 19, 30, 45]                      # Anorthite, Albite, Microcline, Orthoclase
Ol  = [6, 74]                               # Forsterite, Fayalite
Aug = [8, 12, 87, 95, 543, 779]             # Diopside, Enstatite, Augite, Hedenbergite, Ferrosilite, Clinoenstatite
GROUPS = [('Fsp', Fsp), ('Ol', Ol), ('Aug', Aug)]
GROUP_OF = {}
for c, ids in GROUPS:
    for i in ids:
        GROUP_OF[i] = c
SIGMA = {'Fsp': 1.4, 'Ol': 2.4, 'Aug': 1.0}

z = np.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'qi', 'qi_aligned.npz'), allow_pickle=True)
X, names = z['X'], list(z['names'])
Y, Ynames = z['Y'], list(z['Ynames'])
xmoon = z['xmoon']
print('ternary', X.shape, 'with truth', len(Ynames))

# ---------------- FCLS ----------------
def fcls_full(x, delta=0.01):
    A = np.vstack([R.T, delta * np.ones((1, K))])
    b = np.concatenate([x, [delta]])
    a, _ = nnls(A, b)
    s = a.sum()
    return a / s if s > 1e-8 else a

# ---------------- SUnSAL (GPU) ----------------
A = torch.tensor(R.T, dtype=torch.float32, device=DEV)
ATA = A.T @ A
MU = 1.0
Pinv = torch.inverse(ATA + MU * torch.eye(K, device=DEV))

def sunsal(Y, lam, mu=MU, niter=300):
    Yb = torch.tensor(Y, dtype=torch.float32, device=DEV)
    AtY = Yb @ A
    x = torch.zeros_like(AtY); z = torch.zeros_like(AtY); u = torch.zeros_like(AtY); th = lam / mu
    for _ in range(niter):
        x = (AtY + mu * (z - u)) @ Pinv
        v = x + u; z = torch.clamp(v - th, min=0.0); u = u + x - z
    return z.cpu().numpy()

def cat_abund(a):
    """族内聚合，返回归一化类别丰度 (Fsp,Ol,Aug,other) 与归一化三类（和=1）。"""
    g = {c: float(a[ids].sum()) for c, ids in GROUPS}
    inside = sum(g.values())
    other = 1.0 - inside
    return g, other

def report(tag, AB):
    """AB: (N,K) 丰度（sum-to-one）。逐样本打印。"""
    print(f'\n================ {tag} ================')
    recall = {c: 0 for c in ['Fsp', 'Ol', 'Aug']}; extraneous = []
    pred3 = []
    for i, nm in enumerate(names):
        a = AB[i]
        g, other = cat_abund(a)
        # 归一化三类（用于和 wt% 比）
        s3 = sum(g.values())
        g3 = {c: g[c] / max(s3, 1e-12) for c in ['Fsp', 'Ol', 'Aug']}
        # σ 校正 -> wt% 估计
        w = {c: g3[c] / SIGMA[c] for c in g3}
        sw = sum(w.values()); w = {c: w[c] / max(sw, 1e-12) for c in w}
        for c in recall:
            if g3[c] > 0.05:
                recall[c] += 1
        # 族外 top 矿物
        ordr = np.argsort(a)[::-1]
        out = [f"{topK[j]}({a[j]:.2f})" for j in ordr[:6] if j not in GROUP_OF][:2]
        in3 = [f"{c}:{g3[c]:.2f}->wt{w[c]:.2f}" for c in ['Fsp', 'Ol', 'Aug']]
        truth = ''
        if nm in Ynames:
            t = Y[Ynames.index(nm)]; truth = f" truth F/O/A={t[0]:.0f}/{t[1]:.0f}/{t[2]:.0f}"
        print(f'{nm}: ' + ' '.join(in3) + truth + (f' | 族外:{out}' if out else ''))
        pred3.append((g3, w))
    print(f'类别召回(>5%): ' + ', '.join(f'{c} {recall[c]}/14' for c in recall))
    # 定量（仅 12 条有真值）
    rows = []
    for i, nm in enumerate(names):
        if nm in Ynames:
            t = Y[Ynames.index(nm)] / 100.0
            g3, w = pred3[i]
            rows.append((nm, g3, w, t))
    def metrics(idx_in_row, key):
        P = np.array([[r[1]['Fsp'], r[1]['Ol'], r[1]['Aug']] if key == 'raw' else
                      [r[2]['Fsp'], r[2]['Ol'], r[2]['Aug']] for r in rows])
        T = np.array([r[3] for r in rows])
        cos = float(((P * T).sum(1) / np.maximum(np.linalg.norm(P, axis=1) * np.linalg.norm(T, axis=1), 1e-10)).mean())
        mae = float(np.abs(P - T).mean())
        # 主导矿物正确率
        dom = float((P.argmax(1) == T.argmax(1)).mean())
        # per-component corr
        cc = [np.corrcoef(P[:, k], T[:, k])[0, 1] for k in range(3)]
        return cos, mae, dom, cc
    for key in ['raw', 'sig_corr']:
        cos, mae, dom, cc = metrics(0, key)
        label = '光谱丰度(未校正)' if key == 'raw' else 'σ校正后估wt%'
        print(f'  [{label}] cos={cos:.3f} MAE={mae:.3f} 主导正确率={dom:.2f} corr(F/O/A)=({cc[0]:.2f},{cc[1]:.2f},{cc[2]:.2f})')
    return pred3

# FCLS
ABf = np.stack([fcls_full(x) for x in X])
report('FCLS', ABf)

# SUnSAL 多个 λ
for lam in [0.03, 0.1, 0.3]:
    raw = sunsal(X, lam)
    ABs = raw / np.maximum(raw.sum(1, keepdims=True), 1e-12)
    report(f'SUnSAL lambda={lam}', ABs)

# 月壤（用 FCLS 与 SUnSAL λ=0.1）
am = fcls_full(xmoon)
gm, om = cat_abund(am)
s3 = sum(gm.values()); g3m = {c: gm[c] / max(s3, 1e-12) for c in ['Fsp', 'Ol', 'Aug']}
wm = {c: (g3m[c] / SIGMA[c]) for c in g3m}; sw = sum(wm.values()); wm = {c: wm[c] / sw for c in wm}
print('\n==== CE5C0600 月壤 FCLS ====')
print('  光谱占比 F/O/A = %.3f/%.3f/%.3f, 族外 %.3f' % (g3m['Fsp'], g3m['Ol'], g3m['Aug'], om))
print('  σ校正 wt%% F/O/A = %.3f/%.3f/%.3f  (论文报告 32.1/11.9/56.0 Fsp/Ol/Aug)' % (wm['Fsp'], wm['Ol'], wm['Aug']))
ordr = np.argsort(am)[::-1][:6]
print('  top 矿物:', [(topK[j], round(float(am[j]), 3)) for j in ordr])
rawm = sunsal(xmoon[None], 0.1); ams = rawm[0] / max(rawm[0].sum(), 1e-12)
gms, _ = cat_abund(ams); s3 = sum(gms.values()); g3s = {c: gms[c] / max(s3, 1e-12) for c in gms}
wms = {c: g3s[c] / SIGMA[c] for c in g3s}; sw = sum(wms.values()); wms = {c: wms[c] / sw for c in wms}
print('==== CE5C0600 月壤 SUnSAL λ=0.1 ====')
print('  光谱占比 F/O/A = %.3f/%.3f/%.3f' % (g3s['Fsp'], g3s['Ol'], g3s['Aug']))
print('  σ校正 wt%% F/O/A = %.3f/%.3f/%.3f' % (wms['Fsp'], wms['Ol'], wms['Aug']))
print('  top 矿物:', [(topK[j], round(float(ams[j]), 3)) for j in np.argsort(ams)[::-1][:6]])
print('\nDONE')
