# -*- coding: utf-8 -*-
"""
Qi Step3（修正版）：TSRAM-Net 在 14 条真实三元 + 月壤上零样本推理（K=1000，不微调）。
  - presence 双流检测头：sigmoid(pl)>0.5（论文检测主口径，宽召回）
  - 学习丰度头：sparsemax 丰度
  - 固定特征精修头：encoder 特征空间全库非负 l1 ADMM（λ=0.05）
检测/定量口径与 qi_step2 一致；cos 修正为逐样本 L2 归一化。
"""
import os
import io, json
import numpy as np
import torch

P = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ablation_full_v3.py')
lines = io.open(P, encoding='utf-8').read().split('\n')
cut = next(i for i, l in enumerate(lines) if l.startswith('Xtr, yptr'))
ns = {}
exec(compile('\n'.join(lines[:cut]), P, 'exec'), ns)
DEV = ns['DEV']; R = ns['R']; K = ns['K']; ref_t = ns['ref_t']; Net = ns['Net']; topK = ns['topK']
print(f'Device {DEV} K={K}')

Fsp = [17, 19, 30, 45]
Ol  = [6, 74]
Aug = [8, 12, 87, 95, 543, 779]
GROUPS = [('Fsp', Fsp), ('Ol', Ol), ('Aug', Aug)]
GROUP_OF = {i: c for c, ids in GROUPS for i in ids}
SIGMA = {'Fsp': 1.4, 'Ol': 2.4, 'Aug': 1.0}

z = np.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'qi', 'qi_aligned.npz'), allow_pickle=True)
X, names = z['X'], list(z['names'])
Y, Ynames = z['Y'], list(z['Ynames'])
xmoon = z['xmoon']

torch.manual_seed(42); np.random.seed(42)
net = Net('full').to(DEV)
net.load_state_dict(torch.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'checkpoints', 'refine_full_k1000.pth'), map_location=DEV))
net.update_ref(ref_t); net.eval()

A = net.ref_feat.to(DEV)
Pinv = torch.inverse(A @ A.T + torch.eye(K, device=DEV))
def feat_admm(Xq, lam=0.05, mu=1.0, T=128):
    Qs = []
    with torch.no_grad():
        for j in range(0, len(Xq), 512):
            Qs.append(net.encoder(torch.from_numpy(Xq[j:j + 512]).to(DEV)))
    Q = torch.cat(Qs)
    AtQ = Q @ A.T; th = lam / mu
    zz = torch.zeros_like(AtQ); u = torch.zeros_like(AtQ)
    for _ in range(T):
        x = (AtQ + mu * (zz - u)) @ Pinv
        v = x + u; zz = torch.clamp(v - th, min=0.0); u = u + x - zz
    return (zz / zz.sum(1, keepdim=True).clamp(min=1e-10)).cpu().numpy()

# 学习头：pl(presence logits) + ab(sparsemax)
PL, ABlearn = [], []
with torch.no_grad():
    for j in range(0, len(X), 512):
        pl, ab, Ap, Ai = net(torch.from_numpy(X[j:j + 512]).to(DEV))
        PL.append(torch.sigmoid(pl).cpu().numpy()); ABlearn.append(ab.cpu().numpy())
PL = np.concatenate(PL); ABlearn = np.concatenate(ABlearn)
ABfeat = feat_admm(X, 0.05)

def cat_g(a):
    g = {c: float(a[ids].sum()) for c, ids in GROUPS}
    other = 1.0 - sum(g.values())
    s3 = max(sum(g.values()), 1e-12)
    g3 = {c: g[c] / s3 for c in g}
    w = {c: g3[c] / SIGMA[c] for c in g3}; sw = sum(w.values())
    w = {c: w[c] / max(sw, 1e-12) for c in w}
    return g3, w, other

def presence_groups(plrow):
    hit = {c: int(any(plrow[i] > 0.5 for i in ids)) for c, ids in GROUPS}
    return hit

def quant(rows):
    out = {}
    for key in ('raw', 'sig'):
        P = np.array([[r[1]['Fsp'], r[1]['Ol'], r[1]['Aug']] if key == 'raw' else
                      [r[2]['Fsp'], r[2]['Ol'], r[2]['Aug']] for r in rows])
        T = np.array([r[3] for r in rows])
        den = np.maximum(np.linalg.norm(P, axis=1) * np.linalg.norm(T, axis=1), 1e-10)
        cos = float(((P * T).sum(1) / den).mean())
        mae = float(np.abs(P - T).mean()); dom = float((P.argmax(1) == T.argmax(1)).mean())
        cc = [np.corrcoef(P[:, k], T[:, k])[0, 1] for k in range(3)]
        out[key] = (cos, mae, dom, cc)
    return out

def report_ab(tag, AB):
    print(f'\n================ {tag} ================')
    rec = {c: 0 for c in ['Fsp', 'Ol', 'Aug']}; rows = []
    for i, nm in enumerate(names):
        g3, w, other = cat_g(AB[i])
        for c in rec:
            if g3[c] > 0.05: rec[c] += 1
        ordr = np.argsort(AB[i])[::-1]
        out = [f"{topK[j]}({AB[i][j]:.2f})" for j in ordr[:6] if j not in GROUP_OF][:2]
        truth = ''
        if nm in Ynames:
            t = Y[Ynames.index(nm)]; truth = f" truth F/O/A={t[0]:.0f}/{t[1]:.0f}/{t[2]:.0f}"
            rows.append((nm, g3, w, t / 100.0))
        print(f'{nm}: ' + ' '.join(f"{c}:{g3[c]:.2f}->wt{w[c]:.2f}" for c in ['Fsp','Ol','Aug']) +
              f"{truth} 族外{other:.2f}" + (f" |{out}" if out else ''))
    print('类别召回(>5%): ' + ', '.join(f'{c} {rec[c]}/14' for c in rec))
    q = quant(rows)
    for key, lab in [('raw', '光谱丰度'), ('sig', 'σ校正wt%')]:
        cos, mae, dom, cc = q[key]
        print(f'  [{lab}] cos={cos:.3f} MAE={mae:.3f} 主导正确率={dom:.2f} corr(F/O/A)=({cc[0]:.2f},{cc[1]:.2f},{cc[2]:.2f})')

# presence 双流检测头
print('\n================ TSRAM presence 双流检测头 (sigmoid>0.5) ================')
prec = {c: 0 for c in ['Fsp', 'Ol', 'Aug']}; ext = 0
for i, nm in enumerate(names):
    h = presence_groups(PL[i])
    for c in h:
        prec[c] += h[c]
    flagged = [topK[j] for j in range(K) if PL[i, j] > 0.5 and j not in GROUP_OF]
    ext += len(flagged)
    print(f'{nm}: 检出 F={h["Fsp"]} O={h["Ol"]} A={h["Aug"]}  族外检出({len(flagged)}):{flagged[:4]}')
print('presence 类别召回: ' + ', '.join(f'{c} {prec[c]}/14' for c in prec) + f' | 族外总检出={ext}')

report_ab('TSRAM 学习丰度头 sparsemax', ABlearn)
report_ab('TSRAM 固定特征精修头 (encoder+l1, λ=0.05)', ABfeat)

# 月壤
plm = None
with torch.no_grad():
    pl, ab, Ap, Ai = net(torch.from_numpy(xmoon[None]).to(DEV))
    plm = torch.sigmoid(pl).cpu().numpy()[0]
    am = ab.cpu().numpy()[0]
hm = presence_groups(plm)
af = feat_admm(xmoon[None], 0.05)[0]
for tag, a in [('学习头', am), ('特征精修头', af)]:
    g3, w, other = cat_g(a)
    print(f'\n==== 月壤 CE5C0600 {tag} ====')
    print('  光谱 F/O/A=%.3f/%.3f/%.3f 族外%.3f' % (g3['Fsp'], g3['Ol'], g3['Aug'], other))
    print('  σ校正wt%% F/O/A=%.3f/%.3f/%.3f (论文32.1/11.9/56.0)' % (w['Fsp'], w['Ol'], w['Aug']))
    print('  top:', [(topK[j], round(float(a[j]), 3)) for j in np.argsort(a)[::-1][:6]])
print(f'月壤 presence 检出 F={hm["Fsp"]} O={hm["Ol"]} A={hm["Aug"]}; '
      f'族外presence:{[topK[j] for j in range(K) if plm[j] > 0.5 and j not in GROUP_OF][:6]}')
print('\nDONE')
