# -*- coding: utf-8 -*-
"""
SUnSAL 高噪声鲁棒性（K=1000），与 noise_v2_fcls_vs_tsram 同协议、同种子
================================================================================
严格复用 eval_noise_final.py：同一参考库 R（同 parse 顺序）、同一干净测试集
Xc=gen(3000,seed=123)、同一噪声（rng=456，加噪后逐样本 min-max）。
只新增 SUnSAL（原始谱空间全库非负 ℓ1 ADMM，GPU 批量）一列，λ/阈值固定不随噪声调
（λ=0.1、检测阈值 0.08，与 1% 主基线 baseline_sunsal 一致），再合并现有
FCLS/TSRAM 列输出 noise_v3_three_methods.json，保证三方法完全可比。
"""
import os, json
import numpy as np
from collections import Counter, defaultdict
from scipy.interpolate import interp1d
from scipy.signal import savgol_filter
import torch
from sklearn.metrics import f1_score

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'rruff')
NWP, WMIN, WMAX, DIM, K, N_TEST = 1024, 100.0, 1500.0, 1024, 1000, 3000
CWN = np.linspace(WMIN, WMAX, NWP); DEV = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
LEVELS = [0.0, .005, .01, .02, .05, .1, .2]; LABS = ['0%', '0.5%', '1%', '2%', '5%', '10%', '20%']
LAM = 0.1; TH = 0.08; MU = 1.0; NITER = 200
print(f'Device {DEV} | SUnSAL noise robustness', flush=True)


def parse_raman(fp):
    name, lines = None, []
    with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if line.startswith('##NAMES='): name = line.split('=', 1)[1].strip()
            elif line and not line.startswith('#'): lines.append(line)
    if name is None or not lines: return None
    wn, it = [], []
    for l in lines:
        p = l.split(',')
        if len(p) >= 2:
            try: wn.append(float(p[0])); it.append(float(p[1]))
            except: pass
    if len(wn) < 50: return None
    return name, np.array(wn, np.float32), np.array(it, np.float32)


def interp_spec(wn, it):
    m = (wn >= WMIN - 50) & (wn <= WMAX + 50)
    if m.sum() < 20: return None
    wn, it = wn[m], it[m]; o = np.argsort(wn); wn, it = wn[o], it[o]
    uw, idx = np.unique(wn, return_inverse=True); ui = np.array([it[idx == i].mean() for i in range(len(uw))])
    if len(uw) < 20: return None
    try:
        f = interp1d(uw, ui, kind='linear', bounds_error=False, fill_value=0.0); s = f(CWN)
        wl = min(15, len(s) // 10); wl += (wl % 2 == 0)
        if wl >= 5: s = savgol_filter(s, wl, 2)
        lo, hi = s.min(), s.max()
        return None if hi - lo < 1e-8 else ((s - lo) / (hi - lo)).astype(np.float32)
    except: return None


print('building library...', flush=True)
ms = defaultdict(list)
for fn in os.listdir(DATA_DIR):
    if fn.endswith('.txt') and 'Processed' in fn:
        r = parse_raman(os.path.join(DATA_DIR, fn))
        if r:
            nm, wn, it = r; s = interp_spec(wn, it)
            if s is not None: ms[nm].append(s)
topK = [m for m, _ in Counter({m: len(v) for m, v in ms.items()}).most_common(K)]
R = np.zeros((K, NWP), np.float32)
for i, m in enumerate(topK):
    sp = np.array(ms[m]); ref = np.median(sp, 0) if len(sp) > 1 else sp[0]
    lo, hi = ref.min(), ref.max(); R[i] = ((ref - lo) / (hi - lo + 1e-12)).astype(np.float32) if hi - lo > 1e-8 else ref


def gen(n, seed):
    rng = np.random.RandomState(seed); X = np.zeros((n, NWP), np.float32)
    yp = np.zeros((n, K), np.float32); ya = np.zeros((n, K), np.float32)
    for i in range(n):
        nc = rng.randint(1, 3); ch = rng.choice(K, nc, replace=False); ra = rng.dirichlet(np.ones(nc)).astype(np.float32)
        m = (R[ch] * ra[:, None]).sum(0); lo, hi = m.min(), m.max(); m = (m - lo) / (hi - lo + 1e-12)
        X[i] = m; yp[i, ch] = 1; ya[i, ch] = ra
    return X, yp, ya


# 原始谱空间全库 SUnSAL 设计矩阵（GPU 批量）
A = torch.tensor(R.T, dtype=torch.float32, device=DEV)
Pinv = torch.inverse(A.T @ A + MU * torch.eye(K, device=DEV))


def sunsal_batch(Y, lam, mu=MU, niter=NITER, batch=2500):
    out = []
    for j in range(0, len(Y), batch):
        Yb = torch.tensor(Y[j:j + batch], dtype=torch.float32, device=DEV)
        AtY = Yb @ A; th = lam / mu
        z = torch.zeros_like(AtY); u = torch.zeros_like(AtY)
        for _ in range(niter):
            x = (AtY + mu * (z - u)) @ Pinv
            z = torch.clamp(x + u - th, min=0.0); u = u + x - z
        out.append(z.cpu().numpy())
    return np.concatenate(out)


def norm_ab(a):
    return a / np.maximum(a.sum(1, keepdims=True), 1e-12)


Xc, ypt, yat = gen(N_TEST, 123)
res = json.load(open('noise_v2_fcls_vs_tsram.json', encoding='utf-8'))
res['sunsal_f1'] = []; res['sunsal_cos'] = []; res['sunsal_th'] = TH; res['sunsal_lam'] = LAM
for std, lab in zip(LEVELS, LABS):
    rng = np.random.RandomState(456)
    Xn = Xc + (rng.normal(0, std, Xc.shape).astype(np.float32) if std > 0 else 0)
    for i in range(len(Xn)):
        lo, hi = Xn[i].min(), Xn[i].max(); Xn[i] = (Xn[i] - lo) / (hi - lo + 1e-12)
    raw = sunsal_batch(Xn, LAM); ab = norm_ab(raw)
    P = (ab > TH).astype(float)
    f1 = f1_score(ypt, P, average='samples', zero_division=0)
    cos = float(((ab * yat).sum(1) / np.maximum(np.linalg.norm(ab, axis=1) * np.linalg.norm(yat, axis=1), 1e-10)).mean())
    # 参考：该级最优阈值（oracle，仅作上限参考，不用于主口径）
    bf, bt = 0.0, TH
    for t in np.arange(0.005, 0.20, 0.005):
        f = f1_score(ypt, (ab > t).astype(float), average='samples', zero_division=0)
        if f > bf: bf, bt = f, float(t)
    res['sunsal_f1'].append(round(f1, 4)); res['sunsal_cos'].append(round(cos, 4))
    print(f'{lab:>4} SUnSAL F1 {f1:.3f} (fixed th{TH}) cos {cos:.3f} | oracle-th {bt:.3f} F1 {bf:.3f}', flush=True)
json.dump(res, open('noise_v3_three_methods.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print('\nnoise   FCLS_F1  SUnSAL_F1  TSRAM_F1  | FCLS_cos  SUnSAL_cos  TSRAM_cos')
for i, lab in enumerate(LABS):
    print(f'{lab:>5}  {res["fcls_f1"][i]:.3f}    {res["sunsal_f1"][i]:.3f}     {res["tsram_f1"][i]:.3f}   |  {res["fcls_cos"][i]:.3f}     {res["sunsal_cos"][i]:.3f}      {res["tsram_cos"][i]:.3f}')
print('SAVED noise_v3_three_methods.json')
