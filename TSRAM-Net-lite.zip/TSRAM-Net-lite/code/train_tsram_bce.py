"""
TSRAM-Net 主模型 —— presence 端改用 BCE（KS-v5 结论）
================================================================================
与 train_tsram_final_v2.py 唯一的差别：presence 损失由 ContrastiveLoss(softmax
over K, T=0.4) 换成 BCEWithLogitsLoss。其余（编码器、双流检索、丰度 sparsemax、
50k/10k、600 epoch、batch 256、AdamW 8e-4、余弦 LR）完全不变。

依据（kscale_v5 七变体实验，1% 噪声 F1）：
  K=1000: 对比损失 0.8835 -> BCE 0.8820（打平）
  K=1900: 对比损失 0.7833 -> BCE 0.8319（+4.86）
对比损失的 softmax 分母随 K 增大而稀释正样本梯度，BCE 逐类独立不受 K 影响。
"""
import os, json, time
import numpy as np
from collections import Counter, defaultdict
from scipy.interpolate import interp1d
from scipy.signal import savgol_filter
import torch, torch.nn as nn, torch.nn.functional as F, torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import f1_score, precision_score, recall_score
import warnings; warnings.filterwarnings('ignore')

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'rruff')
OUT_PREFIX = 'tsram_bce'
SEED = 42
np.random.seed(SEED); torch.manual_seed(SEED)
NWP, WMIN, WMAX, DIM, K = 1024, 100.0, 1500.0, 1024, 1000
CWN = np.linspace(WMIN, WMAX, NWP)
N_EPOCHS, BATCH_SIZE, N_TRAIN, N_VAL, LR = 600, 256, 50000, 10000, 8e-4
DEV = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'Device {DEV} | TSRAM-Net FINAL v2 (standard sparsemax + random noise augmentation) | K={K} | {N_EPOCHS}ep | {N_TRAIN} samples', flush=True)

# ---------- 数据 ----------
def parse_raman(fp):
    name, lines = None, []
    with open(fp,'r',encoding='utf-8',errors='ignore') as f:
        for line in f:
            line=line.strip()
            if line.startswith('##NAMES='): name=line.split('=',1)[1].strip()
            elif line and not line.startswith('#'): lines.append(line)
    if name is None or not lines: return None
    wn,it=[],[]
    for l in lines:
        p=l.split(',')
        if len(p)>=2:
            try: wn.append(float(p[0])); it.append(float(p[1]))
            except: pass
    if len(wn)<50: return None
    return name,np.array(wn,np.float32),np.array(it,np.float32)
def interp_spec(wn,it):
    m=(wn>=WMIN-50)&(wn<=WMAX+50)
    if m.sum()<20: return None
    wn,it=wn[m],it[m]; o=np.argsort(wn); wn,it=wn[o],it[o]
    uw,idx=np.unique(wn,return_inverse=True)
    ui=np.array([it[idx==i].mean() for i in range(len(uw))])
    if len(uw)<20: return None
    try:
        f=interp1d(uw,ui,kind='linear',bounds_error=False,fill_value=0.0); s=f(CWN)
        wl=min(15,len(s)//10); wl+=(wl%2==0)
        if wl>=5: s=savgol_filter(s,wl,2)
        lo,hi=s.min(),s.max()
        if hi-lo<1e-8: return None
        return ((s-lo)/(hi-lo)).astype(np.float32)
    except: return None
print('[1/4] building library...',flush=True)
ms=defaultdict(list)
for fn in os.listdir(DATA_DIR):
    if fn.endswith('.txt') and 'Processed' in fn:
        r=parse_raman(os.path.join(DATA_DIR,fn))
        if r:
            nm,wn,it=r; s=interp_spec(wn,it)
            if s is not None: ms[nm].append(s)
topK=[m for m,_ in Counter({m:len(v) for m,v in ms.items()}).most_common(K)]
R=np.zeros((K,NWP),np.float32)
for i,m in enumerate(topK):
    sp=np.array(ms[m]); ref=np.median(sp,0) if len(sp)>1 else sp[0]
    lo,hi=ref.min(),ref.max(); R[i]=((ref-lo)/(hi-lo+1e-12)).astype(np.float32) if hi-lo>1e-8 else ref
print(f'  library {R.shape}',flush=True)

# ---------- 标准 sparsemax（Martins & Astudillo 2016，不 clamp tau） ----------
def sparsemax(z,dim=-1):
    if dim<0: dim=z.ndim+dim
    z=z-z.max(dim=dim,keepdim=True)[0]
    zs,_=torch.sort(z,dim=dim,descending=True); zc=torch.cumsum(zs,dim=dim)
    k=torch.arange(1,z.shape[dim]+1,device=z.device,dtype=z.dtype).view(*[1 if i!=dim else -1 for i in range(z.ndim)])
    km=(1+k*zs>zc).float().sum(dim=dim,keepdim=True).long()-1; km=km.clamp(min=0)
    tau=(zc.gather(dim,km)-1)/(km.float()+1)          # 阈值可为负，禁止 clamp(min=0)
    return (z-tau).clamp(min=0)

class Enc(nn.Module):
    def __init__(s):
        super().__init__()
        s.fc1=nn.Linear(NWP,DIM); s.bn1=nn.BatchNorm1d(DIM)
        s.fc2=nn.Linear(DIM,DIM); s.bn2=nn.BatchNorm1d(DIM); s.fc3=nn.Linear(DIM,DIM)
    def forward(s,x):
        h=F.relu(s.bn1(s.fc1(x))); h=F.relu(s.bn2(s.fc2(h)))+h; h=s.fc3(h)+h
        return F.normalize(h,p=2,dim=-1)
class TSRAMNet(nn.Module):
    def __init__(s,n=K,dim=DIM):
        super().__init__(); s.n=n
        s.encoder=Enc()
        s.register_buffer('ref_feat',torch.zeros(n,dim))
        s.log_Tp=nn.Parameter(torch.tensor(np.log(4.0)))
        s.pres_head=nn.Sequential(nn.Linear(dim*2,512),nn.BatchNorm1d(512),nn.ReLU(),nn.Dropout(.3),
            nn.Linear(512,256),nn.BatchNorm1d(256),nn.ReLU(),nn.Dropout(.2),nn.Linear(256,n))
        s.log_Ta=nn.Parameter(torch.tensor(np.log(3.0)))
        s.log_ss=nn.Parameter(torch.tensor(np.log(5.0)))
        s.refiner=nn.Sequential(nn.Linear(dim*3,dim),nn.BatchNorm1d(dim),nn.ReLU(),nn.Dropout(.2),
            nn.Linear(dim,dim//2),nn.BatchNorm1d(dim//2),nn.ReLU(),nn.Dropout(.1),nn.Linear(dim//2,n))
    @torch.no_grad()
    def update_ref(s,ref):
        s.eval()
        for i in range(0,s.n,512): s.ref_feat[i:i+512]=s.encoder(ref[i:i+512].to(s.ref_feat.device))
        s.train()
    def forward(s,x):
        Q=s.encoder(x); sim=Q@s.ref_feat.T
        Tp=torch.exp(s.log_Tp).clamp(min=.1); Ta=torch.exp(s.log_Ta).clamp(min=.1); ss=torch.exp(s.log_ss)
        Ap=F.softmax(sim/Tp,-1); wp=Ap@s.ref_feat
        pl=s.pres_head(torch.cat([Q,wp],-1))
        Ai=sparsemax(sim/Ta,-1); wi=Ai@s.ref_feat                      # 粗检索（精确零）
        al=s.refiner(torch.cat([Q,wi,Q-wi],-1)); comb=sim*ss+al
        ab=sparsemax(comb/Ta,-1)                                        # 丰度：精确零稀疏输出
        return pl,ab,Ap,Ai

def gen(n,seed0=0,aug=True,std=0.01):
    # aug=True : 随机噪声增强——约15%干净样本 + 85%噪声std~Uniform(0.002,0.05)，
    #            使BatchNorm统计覆盖 干净→中噪 区间，保证0%真干净输入也能正确推理；
    # aug=False: 固定噪声std（标准测试条件，std=0.01对应训练基准、std=0为真干净）。
    rng=np.random.RandomState(seed0)
    X=np.zeros((n,NWP),np.float32); yp=np.zeros((n,K),np.float32); ya=np.zeros((n,K),np.float32)
    for i in range(n):
        nc=rng.randint(1,3); ch=rng.choice(K,nc,replace=False); ra=rng.dirichlet(np.ones(nc)).astype(np.float32)
        if aug:
            u=rng.rand(); sigma=0.0 if u<0.15 else 0.002+(u-0.15)/0.85*0.048
        else:
            sigma=std
        noise=rng.normal(0,sigma,NWP).astype(np.float32) if sigma>0 else 0.0
        m=(R[ch]*ra[:,None]).sum(0)+noise
        lo,hi=m.min(),m.max(); m=(m-lo)/(hi-lo+1e-12); X[i]=m; yp[i,ch]=1; ya[i,ch]=ra
    return X,yp,ya
class ContrastiveLoss(nn.Module):
    def __init__(s,T=.4): super().__init__(); s.T=T
    def forward(s,lo,t):
        z=lo-lo.max(-1,keepdim=True)[0].detach(); e=torch.exp(z/s.T); Z=e.sum(-1,keepdim=True).clamp(min=1e-8)
        lp=z/s.T-torch.log(Z); npos=t.sum(-1).clamp(min=1)
        return (-(t*lp).sum(-1)/npos).mean()

print('[2/4] model + data...',flush=True)
model=TSRAMNet().to(DEV)
print(f'  params {sum(p.numel() for p in model.parameters()):,}',flush=True)
ref_t=torch.from_numpy(R).to(DEV)
Xtr,yptr,yatr=gen(N_TRAIN,1); Xva,ypva,_=gen(N_VAL,2)
tr=DataLoader(TensorDataset(torch.from_numpy(Xtr),torch.from_numpy(yptr),torch.from_numpy(yatr)),batch_size=BATCH_SIZE,shuffle=True)
va=DataLoader(TensorDataset(torch.from_numpy(Xva),torch.from_numpy(ypva)),batch_size=BATCH_SIZE)
crit = nn.BCEWithLogitsLoss(); opt = optim.AdamW(model.parameters(),lr=LR,weight_decay=1e-4)
sch=optim.lr_scheduler.CosineAnnealingLR(opt,T_max=N_EPOCHS)

print(f'[3/4] training {N_EPOCHS} epochs...',flush=True)
best=0; t0=time.time()
for ep in range(N_EPOCHS):
    model.update_ref(ref_t); model.train(); tot=0; nb=0
    for xb,pb,ab_ in tr:
        xb,pb,ab_=xb.to(DEV),pb.to(DEV),ab_.to(DEV)
        pl,ab,_,_=model(xb); loss=crit(pl,pb)+F.mse_loss(ab,ab_)
        opt.zero_grad(); loss.backward(); opt.step(); tot+=loss.item(); nb+=1
    sch.step()
    if (ep+1)%10==0 or ep==N_EPOCHS-1:
        model.eval(); P=[]
        with torch.no_grad():
            for xb,pb in va:
                pl,_,_,_=model(xb.to(DEV)); P.append((torch.sigmoid(pl)>.5).float().cpu().numpy())
        f=f1_score(ypva,np.concatenate(P),average='samples',zero_division=0)
        if f>best: best=f; torch.save(model.state_dict(),f'{OUT_PREFIX}_best_model.pth')
        Tp=float(torch.exp(model.log_Tp)); Ta=float(torch.exp(model.log_Ta))
        print(f'  ep{ep+1:3d}/{N_EPOCHS} loss{tot/nb:.4f} valF1 {f:.4f}(best {best:.4f}) Tp{Tp:.1f} Ta{Ta:.2f} {((time.time()-t0)/60):.1f}min',flush=True)

# ---------- 5 测试集评估 ----------
print('[4/4] 5-test-set evaluation...',flush=True)
model.load_state_dict(torch.load(f'{OUT_PREFIX}_best_model.pth',map_location=DEV)); model.update_ref(ref_t); model.eval()
rows=[]; sup=None
for ts_i in range(5):
    Xt,ypt,yat=gen(5000,100+ts_i,aug=False,std=0.01)
    P=[];AB=[];AI=[];AP=[]
    with torch.no_grad():
        for j in range(0,len(Xt),512):
            xb=torch.from_numpy(Xt[j:j+512]).to(DEV)
            pl,ab,ap,ai=model(xb)
            P.append((torch.sigmoid(pl)>.5).float().cpu().numpy()); AB.append(ab.cpu().numpy())
            AI.append((ai>0).sum(-1).cpu().numpy()); AP.append((ap>1.0/K).sum(-1).cpu().numpy())
    P,AB,AI,AP=np.concatenate(P),np.concatenate(AB),np.concatenate(AI),np.concatenate(AP)
    f1=f1_score(ypt,P,average='samples',zero_division=0)
    pr=precision_score(ypt,P,average='samples',zero_division=0); rc=recall_score(ypt,P,average='samples',zero_division=0)
    cos=float(((AB*yat).sum(1)/np.maximum(np.linalg.norm(AB,1)*np.linalg.norm(yat,1),1e-10)).mean())
    rows.append(dict(F1=f1,P=pr,R=rc,cosine=cos))
    if ts_i==0:
        sup={'Ai_init_nonzero':round(float(AI.mean()),1),'final_abundance_nonzero':round(float((AB>1e-4).sum(1).mean()),1),
             'Ap_gt_uniform':round(float(AP.mean()),1)}
# 延迟
x=torch.randn(1,NWP,device=DEV)
with torch.no_grad():
    for _ in range(20): model(x)
if DEV.type=='cuda': torch.cuda.synchronize()
t=time.time()
with torch.no_grad():
    for _ in range(100): model(x)
if DEV.type=='cuda': torch.cuda.synchronize()
lat=(time.time()-t)/100*1000
res={'model':OUT_PREFIX,'K':K,'n_train':N_TRAIN,'epochs':N_EPOCHS,'best_val_f1':round(best,4),
     'F1_mean':round(float(np.mean([r['F1'] for r in rows])),4),'F1_std':round(float(np.std([r['F1'] for r in rows])),4),
     'P_mean':round(float(np.mean([r['P'] for r in rows])),4),'R_mean':round(float(np.mean([r['R'] for r in rows])),4),
     'cosine_mean':round(float(np.mean([r['cosine'] for r in rows])),4),
     'per_test':[{k:round(v,4) for k,v in r.items()} for r in rows],
     'learned_Tp':round(float(torch.exp(model.log_Tp)),2),'learned_Ta':round(float(torch.exp(model.log_Ta)),3),
     'learned_ss':round(float(torch.exp(model.log_ss)),2),'support':sup,'latency_ms':round(lat,3),
     'train_minutes':round((time.time()-t0)/60,1)}
json.dump(res,open(f'{OUT_PREFIX}_results.json','w'),indent=2)
print('\n==== FINAL ====',flush=True)
print(json.dumps(res,indent=2),flush=True)
print(f'SAVED {OUT_PREFIX}_best_model.pth / {OUT_PREFIX}_results.json',flush=True)
