"""光谱分辨率（仪器线型 FWHM）敏感性实验。

背景：库谱实测峰宽 FWHM 中位数 16.9 cm-1（原始 RRUFF，未平滑），而便携/野外拉曼
光谱仪典型 FWHM 为 4-10 cm-1。因此"库糊、仪器锐"是真实部署的常见情形，与直觉相反。

三个分支（add = 在各自原生线型上额外叠加的高斯展宽 FWHM，单位 cm-1）：
  A  仅样本展宽（库保持原生）      -> 失配
  B  仅库展宽（样本保持原生）      -> 反向失配
  C  两者同量展宽                  -> 匹配但更粗（= A 的分辨率匹配修复）

若 A ≈ C，说明失配本身不要紧、只要绝对分辨率够；若 A << C，说明失配昂贵，
把库按仪器线型展宽（一行预处理，无需重训）即可恢复。

用法: python diag_resolution.py [ckpt_prefix] [N]
"""
import numpy as np, torch, sys, json, os
import torch.nn.functional as F
from sklearn.metrics import f1_score
from scipy.ndimage import gaussian_filter1d

CKPT = sys.argv[1] if len(sys.argv) > 1 else 'drift600_base'
N = int(sys.argv[2]) if len(sys.argv) > 2 else 5000
DEV = 'cuda' if torch.cuda.is_available() else 'cpu'

# ---- 复用训练脚本的模型定义与数据生成（不执行主流程） ----
src = open('train_drift_full.py', encoding='utf-8').read()
head = src.split("class ContrastiveLoss")[0].replace(
    "print('[1/4] building library...',flush=True)", "")
_a = sys.argv; sys.argv = ['x', 'base']
ns = {}; exec(compile(head, 'head', 'exec'), ns); sys.argv = _a
TSRAMNet, gen = ns['TSRAMNet'], ns['gen']
R = np.load('_scratch/lib_R_v2.npy')
NWP, WMIN, WMAX = ns['NWP'], ns['WMIN'], ns['WMAX']
BIN = (WMAX - WMIN) / (NWP - 1)

model = TSRAMNet().to(DEV)
model.load_state_dict(torch.load(f'{CKPT}_best_model.pth', map_location=DEV))
model.update_ref(torch.from_numpy(R).to(DEV))
model.eval()

X, Y, A = gen(N, 100, aug=False, std=0.01)
Y = Y.astype(int)


def blur(Xa, fwhm_cm):
    """沿波数轴做高斯卷积，再按流水线口径 min-max 归一化。"""
    if fwhm_cm <= 0:
        return Xa.copy()
    sig = fwhm_cm / 2.354820045 / BIN          # FWHM -> sigma(bins)
    out = gaussian_filter1d(Xa.astype(np.float64), sig, axis=1, mode='nearest')
    lo = out.min(1, keepdims=True); hi = out.max(1, keepdims=True)
    return ((out - lo) / (hi - lo + 1e-12)).astype(np.float32)


_REF0 = model.ref_feat.clone()
_N0 = model.n


@torch.no_grad()
def evaluate(Xa, Ra):
    m = model
    if Ra is not None:
        m.ref_feat = torch.zeros(Ra.shape[0], ns['DIM'], device=DEV)
        m.n = Ra.shape[0]
        m.update_ref(torch.from_numpy(Ra).to(DEV))
        m.eval()
    pl, ab, Ap, Ai = m(torch.from_numpy(Xa).to(DEV))   # 用完整前向，丰度取精修后的 ab
    p = (torch.sigmoid(pl) > .5).float().cpu().numpy()
    abn = ab.cpu().numpy()
    cos = float(((abn * A).sum(1) /
                 np.maximum(np.linalg.norm(abn, axis=1) *
                            np.linalg.norm(A, axis=1), 1e-10)).mean())
    if Ra is not None:                       # 还原原生库，避免污染后续分支
        m.ref_feat = _REF0
        m.n = _N0
    return f1_score(Y, p, average='samples', zero_division=0), cos


LEVELS = [0, 2, 4, 6, 8, 12, 16, 24, 32]
res = {'ckpt': CKPT, 'N': N, 'bin_cm': round(float(BIN), 4),
       'native_fwhm_median': 16.87, 'levels': LEVELS, 'curves': {}}

# 预生成各展宽等级的样本谱
Xb = {f: blur(X, f) for f in LEVELS}
# 预生成各展宽等级的库
Rb = {f: blur(R, f) for f in LEVELS}

print(f'ckpt={CKPT}  N={N}  device={DEV}')
print(f'{"add FWHM":>9} {"总FWHM":>8} | {"A 仅样本":>16} | {"B 仅库":>16} | {"C 匹配":>16}')
print(f'{"cm-1":>9} {"cm-1":>8} | {"F1":>7} {"cos":>8} | {"F1":>7} {"cos":>8} | {"F1":>7} {"cos":>8}')

for f in LEVELS:
    tot = float(np.sqrt(16.87 ** 2 + f ** 2))
    fA, cA = evaluate(Xb[f], None)          # 库保持原生（model.ref_feat 未被改）
    fB, cB = evaluate(X, Rb[f])             # 仅库展宽
    fC, cC = evaluate(Xb[f], Rb[f])         # 两者匹配
    res['curves'][str(f)] = {'total_fwhm': round(tot, 2),
                             'A_sample_only': [round(fA, 4), round(cA, 4)],
                             'B_library_only': [round(fB, 4), round(cB, 4)],
                             'C_matched': [round(fC, 4), round(cC, 4)]}
    print(f'{f:>9} {tot:>8.1f} | {fA:>7.4f} {cA:>8.4f} | {fB:>7.4f} {cB:>8.4f} | {fC:>7.4f} {cC:>8.4f}')

# 恢复比例：(C - A) / (clean - A)  —— 匹配修复能补回多少失配损失
clean = res['curves']['0']['A_sample_only'][0]
print(f'\n干净基准 F1 = {clean:.4f}')
print(f'{"add":>5} {"A失配损失":>10} {"C匹配后损失":>11} {"匹配恢复":>9}')
for f in LEVELS[1:]:
    a = res['curves'][str(f)]['A_sample_only'][0]
    c = res['curves'][str(f)]['C_matched'][0]
    rec = (c - a) / (clean - a) * 100 if (clean - a) > 1e-6 else float('nan')
    res['curves'][str(f)]['recovery_pct'] = round(float(rec), 1)
    print(f'{f:>5} {clean-a:>10.4f} {clean-c:>11.4f} {rec:>8.1f}%')

# 1% 容差：A 曲线跌破 0.99*clean 的展宽量
xs = np.array(LEVELS, float)
ys = np.array([res['curves'][str(f)]['A_sample_only'][0] for f in LEVELS])
tol = 0.99 * clean
if ys.min() < tol:
    cross = float(np.interp(tol, ys[::-1], xs[::-1]))
    res['tolerance_1pct_cm'] = round(cross, 2)
    print(f'\n1% F1 预算下的分辨率失配容差 = {cross:.1f} cm-1 (附加展宽)')
else:
    res['tolerance_1pct_cm'] = None
    print('\n在 32 cm-1 附加展宽内未跌破 1% 预算')

json.dump(res, open(f'_scratch/resolution_{CKPT}.json', 'w'), indent=1)
print(f'\nSAVED _scratch/resolution_{CKPT}.json')
