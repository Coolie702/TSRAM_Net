# TSRAM-Net

Reference-anchored sparse retrieval for open-library Raman unmixing.

TSRAM-Net identifies the one to three phases present in an unknown Raman
spectrum and estimates their fractions against an open library of thousands of
reference spectra, in a single forward pass on one CPU thread. The analysis
layer is learnable at the front end and frozen at the physical solver, so the
same pipeline ports to a new instrument without re-deriving the solver.

This repository contains the code that produces every figure and table in the
manuscript.

> **Status.** Manuscript submitted to *IEEE Journal of Selected Topics in
> Quantum Electronics*, Special Issue on Advances in Multifunctional Optical
> Spectrometers.
>
> **This is the code-only archive.** The five trained checkpoints (121 MB) are
> not included, so that the archive stays inside the 25 MB per-file limit of the
> submission system. Every number in the manuscript is reproduced by training
> from scratch with `code/highnoise_arch.py`; see *Pre-trained checkpoints*
> below. The weights are deposited with the archival release of the article.

---

## Repository layout

```
.
├── code/                  # all scripts, flat; see the map below
├── data/
│   ├── md5/               # MD5 real binary mixtures (5 MB, included)
│   ├── qi/                # ternary + Chang'e-5 spectra and aligned arrays
│   └── rruff/             # RRUFF reference library -- YOU MUST PROVIDE THIS
├── checkpoints/           # empty; training scripts write the weights here
├── results/               # result JSONs that back the figures and tables
├── requirements.txt
└── LICENSE
```

---

## Environment

Tested with Python 3.13 and PyTorch 2.11 on CPU; a CUDA device is recommended
for the training scripts but not required.

```bash
pip install -r requirements.txt
```

Full training of the four Table I models takes several hours on one GPU. All
evaluation and plotting scripts run in minutes on CPU.

---

## Data preparation

### 1. RRUFF reference library (required, not included)

The reference library is built from the RRUFF Project Raman database at 532 nm.
Download the *Processed* spectra and place the `.txt` files flat in
`data/rruff/`:

<https://rruff.info/zipped_data_files/raman/>

Expected filename pattern (as distributed by RRUFF):

```
Abelsonite__R070007__Raman__532______Raman_Data_Processed__<hash>.txt
```

The loader keeps every file whose name contains `Processed`, resamples each
spectrum to 1024 points over 100--1500 cm-1, min-max normalizes it, and for each
mineral takes the median across its spectra. The library is then the 1900 most
frequently measured minerals, in descending order of measurement count. This
step is reproduced at the top of `code/kscale_experiment_v4.py`.

At least 1900 distinct minerals are needed to reproduce `K = 1900`. A smaller
download still runs, at a correspondingly smaller `K`.

Please cite the RRUFF Project when using these spectra:

> Lafuente B, Downs RT, Yang H, Stone N (2015) The power of databases: the RRUFF
> project. In: *Highlights in Mineralogical Crystallography*, 1--30.

### 2. MD5 mixtures (included)

`data/md5/` holds the 20-endmember binary-mixture benchmark from Carey et al.
(2016), including the 177 measured mixtures used for the five-fold protocol.

> Carey CJ, Boucher T, Mahadevan S, Bartholomew P, Dyar MD (2016) A
> standalone workflow for the automated creation and validation of quantitative
> models from Raman spectra. *Comput. Geosci.* 92, 1--8.

### 3. Ternary and Chang'e-5 lunar soil (included)

`data/qi/` holds the ternary mixture set and the Chang'e-5 lunar-soil spectrum
of Qi et al. (2023), together with `qi_aligned.npz`, the resampled array used by
the transfer scripts.

> Qi X, et al. (2023) The first ground truth for Chang'e-5 lunar soil:
> Raman spectroscopy. Science Data Bank, DOI 10.57760/sciencedb.06969.

---

## Quick start: reproduce Table I from scratch

Training writes the checkpoints and the raw metrics:

```bash
cd code
python highnoise_arch.py 1000              # all four models, K = 1000
python highnoise_arch.py 1000 TSRAM        # one model only
```

This produces `_ckpt_<MODEL>_K1000.pt` and `highnoise_results.json` **in the
current working directory**. Move the weights into `checkpoints/`, where the
evaluation scripts look for them:

```bash
mv _ckpt_*_K1000.pt ../checkpoints/
```

Then run the aligned evaluation used for the table:

```bash
python eval_noise_dense_sameproto.py       # four models, aligned protocol
```

It loads the four checkpoints from `checkpoints/` and writes
`noise_dense_sameproto.json` with presence F1 and abundance cosine at 0% and
20% noise.

If you already hold the released weights, drop them into `checkpoints/` and skip
straight to `eval_noise_dense_sameproto.py`.

---

## Script-to-figure map

| Manuscript element | Script(s) | Produces |
|---|---|---|
| Fig. 1, architecture | `gen_architecture_fig_v9.py` | `architecture_figure_v9.pdf` |
| Table I, RRUFF-1000 at 1% noise | `highnoise_arch.py` (train) + `eval_noise_dense_sameproto.py` (aligned eval) | `highnoise_results.json`, `noise_dense_sameproto.json` |
| Fig. 2, library-size scaling and latency | `kscale_experiment_v4.py` (learned) + `baseline_sunsal_kscale.py` (convex) + `bench_latency_kscale.py` + `plot_kscale_latency.py` | `kscale_v4_results.json`, `baseline_sunsal_kscale.json`, `latency_kscale.json` -> `fig_kscale_final.pdf` |
| Fig. 3, noise robustness | `eval_noise_sunsal.py` + `plot_figs_final.py` | `noise_v3_three_methods.json` |
| Fig. 4, instrument error budget | `train_drift_full.py`, `diag_resolution.py`, `diag_resolution_deconv.py`, `eval_empirical_drift.py`, `plot_instrument_budget_final.py` | `results/*.json` -> `fig_budget_final.pdf` |
| Table II, MD5 177 mixtures | `train_md5_v4_bg.py` + `eval_md5_authoritative_v4bg.py` | `md5v4bg_authoritative.json` |
| Sec. IV-H, ternary and lunar soil | `qi_step2_sunsal.py`, `qi_step3_tsram.py` | printed summary |
| Supp. S-XIII, contrastive vs BCE loss | `train_tsram_bce.py` | - |
| Supp. S-XV, presence-branch diagnosis | `diag_pres_head.py`, `diag_pres_head2.py` | `diag_pres_head.json` |
| Supp., weak-component reconstruction | `plot_weakmin_final.py` | `fig_weakmin_final.pdf` |
| Supp., component ablation | `ablation_full_v3.py` | - |

`plot_figs_final.py` and `plot_kscale_latency.py` both read result JSONs from
`results/` and write figure PDFs into the working directory. Run them from
`code/`, or copy the JSONs next to them.

The reference JSONs under `results/` were produced by these exact scripts and
are included so that the figures can be redrawn without retraining anything.

---

## Pre-trained checkpoints

Not shipped in this archive. The training scripts generate them in place:

| File | Model | Size when trained |
|---|---|---|
| `_ckpt_TSRAM_K1000.pt` | TSRAM-Net, two-stage retrieval head | 39 MB |
| `_ckpt_MLPDense_K1000.pt` | residual MLP encoder + dense sigmoid head | 18 MB |
| `_ckpt_CNNDenseV2_K1000.pt` | 1D CNN encoder + dense head | 16 MB |
| `_ckpt_TransDense_K1000.pt` | Transformer encoder + dense head | 13 MB |
| `refine_full_k1000.pth` | TSRAM-Net used for the ternary / lunar-soil transfer | 39 MB |

All four Table I models were trained under an identical protocol: the same
library, the same 50k/10k split, the same noise augmentation, AdamW at 8e-4, a
600-epoch cap, and early stopping on a fixed 1%-noise validation set.

`refine_full_k1000.pth` shares the TSRAM-Net architecture with
`_ckpt_TSRAM_K1000.pt` but is a separate training run, kept under its own name
because `qi_step3_tsram.py` loads it by that filename. No script in this archive
emits that exact file: to run the transfer experiment without the archival
weights, train TSRAM-Net with `highnoise_arch.py 1000 TSRAM` and copy
`_ckpt_TSRAM_K1000.pt` to `refine_full_k1000.pth`. The pipeline runs unchanged;
the absolute numbers in Sec. IV-H will differ from the manuscript because the
weights come from a different run.

---

## A note on code style

This is research code, published as it was run. Two conventions are worth
knowing before reading it:

1. **Scripts reuse each other by `exec`.** `highnoise_arch.py`,
   `baseline_deep_dense.py`, `baseline_sunsal_kscale.py` and `qi_step*.py` load
   the first part of a parent script (`kscale_experiment_v4.py` or
   `ablation_full_v3.py`) to inherit the library, the mixture generator, the
   model classes and the evaluation functions, rather than importing them as a
   module. The `exec` boundary is marked by a comment in each file. This keeps
   every experiment byte-identical to the protocol it was compared against; it
   is not how we would structure a library.
2. **Paths are relative to the script**, resolved through
   `os.path.dirname(os.path.abspath(__file__))`. Scripts can be run from any
   working directory, but result JSONs are still written to the current
   directory.

We deliberately did not refactor these scripts into a package: the numbers in
the manuscript were produced by exactly these files, and rewriting them would
break the correspondence between the released code and the published results.

---

## License

MIT. See `LICENSE`.

The RRUFF spectra are distributed under the RRUFF Project terms and are not
covered by this license; they must be obtained from <https://rruff.info>.

---

## Citation

```bibtex
@article{wang2026tsram,
  title   = {Computational Open-Library Raman Spectrometry for Handheld and
             Planetary Instruments: Coarse-to-Fine Retrieval With a Frozen
             Physical Refinement Stage},
  author  = {Wang, Zhen and Xu, Zhiqiang and Ba, Simiao and Gao, Tiantian and
             Wang, Yutianxin and Gao, Di and He, Jiajia and Chen, Shaohua and
             Mou, Taotao},
  journal = {IEEE Journal of Selected Topics in Quantum Electronics},
  year    = {2026},
  note    = {Submitted}
}
```
