# RRUFF reference library — you must download this

This folder is intentionally empty. The reference library is built from the
RRUFF Project Raman database and is **not redistributed here** (567 MB, and the
RRUFF terms ask that users obtain the data from the source).

## What to download

RRUFF Raman spectra at 532 nm excitation, *Processed* version:

<https://rruff.info/zipped_data_files/raman/>

The site distributes one archive per mineral. You need the `*Processed*.txt`
files, which carry the baseline-corrected spectrum.

## Where to put it

Unzip everything flat into this directory. The loader reads only files whose
name contains `Processed`, so raw files may sit alongside them without harm.

Expected filename pattern:

```
Abelsonite__R070007__Raman__532______Raman_Data_Processed__<hash>.txt
```

A file looks like this:

```
##NAMES= Abelsonite R070007
##RRUFFID= R070007
...
100.00, 1234.5
101.00, 1250.2
...
```

The first column is Raman shift in cm-1, the second is intensity.

## How much you need

- `K = 1900` (the manuscript's largest library) needs at least 1900 distinct
  minerals.
- Any smaller download still runs; `K` is simply capped by the number of
  minerals found. Pass a smaller `K` on the command line, e.g.
  `python kscale_experiment_v4.py 500`.
- Preprocessing keeps the 1900 most frequently measured minerals, so a partial
  download changes which minerals enter the library and therefore the exact
  numbers.

## Processing applied by the loader

See the top of `code/kscale_experiment_v4.py`:

1. Parse `##NAMES=` and the two-column numeric block.
2. Interpolate onto 1024 points spanning 100–1500 cm-1 (linear, zero outside).
3. Savitzky–Golay smooth (window 15 or less, order 2).
4. Min–max normalize each spectrum to [0, 1].
5. For minerals measured more than once, take the median spectrum.
6. Rank minerals by measurement count and keep the top `KMAX = 1900`.

## Citation

> Lafuente B, Downs RT, Yang H, Stone N (2015) The power of databases: the
> RRUFF project. In: *Highlights in Mineralogical Crystallography*, 1–30.
