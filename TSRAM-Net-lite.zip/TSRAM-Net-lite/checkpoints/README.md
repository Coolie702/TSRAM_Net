# Checkpoints are not included in this archive

This is the code-only archive, sized for a 25 MB per-file submission limit. The
five trained weights (121 MB total) are omitted and are deposited with the
archival release of the article.

## Regenerate them

```bash
cd ../code
python highnoise_arch.py 1000           # writes _ckpt_*_K1000.pt to the CWD
mv _ckpt_*_K1000.pt ../checkpoints/     # move them where the scripts look
```

Training the four Table I models takes several hours on one GPU. The protocol is
identical across models: same library, same 50k/10k split, same noise
augmentation, AdamW at 8e-4, 600-epoch cap, early stopping on a fixed 1%-noise
validation set.

## The transfer weight is a separate run

`refine_full_k1000.pth` is not written by any script here; it is the TSRAM-Net
run used for the ternary and Chang'e-5 transfer in Sec. IV-H. It has the same
architecture as `_ckpt_TSRAM_K1000.pt`. To exercise the transfer pipeline
without the archival weights:

```bash
cp _ckpt_TSRAM_K1000.pt refine_full_k1000.pth
```

The code runs unchanged, but the numbers will not match Sec. IV-H exactly,
because they come from a different training run.

## If you already have the weights

Copy them into this directory under their original names; every script resolves
them as `../checkpoints/<name>` relative to itself, so no path editing is
needed.
